import { useState, useEffect, useRef } from 'react';
import VideoList from './components/VideoList';
import VideoUploader from './components/VideoUploader';
import VideoPlayer from './components/VideoPlayer';
import ChatPanel from './components/ChatPanel';
import { Video } from './types';
import { videoApi } from './api';
import './App.css';

type ViewMode = 'list' | 'upload' | 'detail';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleVideoUploaded = async (videoId: string) => {
    // 上传成功后,获取视频详情并跳转到详情页
    try {
      const video = await videoApi.getVideoDetail(videoId);
      setCurrentVideo(video);
      // 修正视频URL为正确的静态文件路径
      const ext = video.filename.substring(video.filename.lastIndexOf('.'));
      setVideoUrl(`http://localhost:8000/static/videos/${videoId}${ext}`);
      setViewMode('detail');
    } catch (error) {
      console.error('获取视频详情失败:', error);
    }
  };

  const handleVideoSelect = async (videoId: string) => {
    // 从列表选择视频,获取详情并跳转到详情页
    try {
      const video = await videoApi.getVideoDetail(videoId);
      setCurrentVideo(video);
      const ext = video.filename.substring(video.filename.lastIndexOf('.'));
      const url = `http://localhost:8000/static/videos/${videoId}${ext}`;
      console.log('视频URL:', url);
      setVideoUrl(url);
      setViewMode('detail');
    } catch (error) {
      console.error('获取视频详情失败:', error);
    }
  };

  const handleBackToList = () => {
    setViewMode('list');
    setCurrentVideo(null);
    setVideoUrl('');
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <div className="header-left">
            {viewMode !== 'list' && (
              <button className="back-button" onClick={handleBackToList}>
                ← 返回列表
              </button>
            )}
            <h1>📐 MathTalkTV</h1>
          </div>
          {viewMode === 'list' && (
            <button
              className="upload-button"
              onClick={() => setViewMode('upload')}
            >
              + 上传视频
            </button>
          )}
        </div>
        <p className="header-subtitle">初中数学智能讲题平台</p>
      </header>

      <main className="app-main">
        {viewMode === 'list' && (
          <VideoList onVideoSelect={handleVideoSelect} />
        )}

        {viewMode === 'upload' && (
          <div className="upload-container">
            <VideoUploader onVideoUploaded={handleVideoUploaded} />
          </div>
        )}

        {viewMode === 'detail' && currentVideo && (
          <div className="main-content">
            <div className="video-section">
              <VideoPlayer videoUrl={videoUrl} videoId={currentVideo.id} videoRef={videoRef} />
            </div>
            <div className="chat-section">
              <ChatPanel videoId={currentVideo.id} videoRef={videoRef} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
