import { useEffect, useState } from 'react';
import { videoApi } from '../api';
import './VideoList.css';

interface VideoItem {
  id: string;
  filename: string;
  duration: number;
  status: string;
  nodes_count: number;
  created_at: string;
}

interface VideoListProps {
  onVideoSelect: (videoId: string) => void;
}

function VideoList({ onVideoSelect }: VideoListProps) {
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      setLoading(true);
      const data = await videoApi.getVideosList();
      setVideos(data.videos);
      setError(null);
    } catch (err) {
      console.error('加载视频列表失败:', err);
      setError('加载视频列表失败');
    } finally {
      setLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString('zh-CN');
  };

  const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
      'processing': '处理中',
      'ready_no_nodes': '就绪(无节点)',
      'ready': '就绪',
      'failed': '失败'
    };
    return statusMap[status] || status;
  };

  if (loading) {
    return <div className="video-list-loading">加载中...</div>;
  }

  if (error) {
    return <div className="video-list-error">{error}</div>;
  }

  if (videos.length === 0) {
    return (
      <div className="video-list-empty">
        <p>还没有上传任何视频</p>
        <p>点击右上角的"上传视频"按钮开始吧!</p>
      </div>
    );
  }

  return (
    <div className="video-list">
      <div className="video-grid">
        {videos.map((video) => (
          <div
            key={video.id}
            className="video-card"
            onClick={() => onVideoSelect(video.id)}
          >
            <div className="video-thumbnail">
              <div className="thumbnail-placeholder">📹</div>
              {video.duration > 0 && (
                <div className="video-duration">{formatDuration(video.duration)}</div>
              )}
            </div>
            <div className="video-info">
              <h3 className="video-title">{video.filename}</h3>
              <div className="video-meta">
                <span className="video-status">{getStatusText(video.status)}</span>
                <span className="video-nodes">{video.nodes_count} 个节点</span>
              </div>
              <div className="video-date">{formatDate(video.created_at)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default VideoList;
