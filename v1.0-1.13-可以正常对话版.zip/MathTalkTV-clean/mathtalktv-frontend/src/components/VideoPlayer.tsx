import { useState, useEffect, RefObject } from 'react';
import './VideoPlayer.css';

interface Props {
  videoUrl: string;
  videoId: string;
  videoRef: RefObject<HTMLVideoElement>;
}

const VideoPlayer = ({ videoUrl, videoRef }: Props) => {
  const [currentTime, setCurrentTime] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    console.log('VideoPlayer加载视频:', videoUrl);
    setError(null);
    setReady(false);
  }, [videoUrl]);

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    console.log('视频元数据加载成功');
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleCanPlay = () => {
    console.log('视频可以播放');
    setReady(true);
    setError(null);
  };

  const handleError = (e: any) => {
    console.error('视频加载失败:', e);
    setError('视频加载失败,请检查视频文件是否存在');
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="video-player-container">
      {error && (
        <div className="video-error">
          ❌ {error}
          <div className="error-details">
            <p>视频URL: {videoUrl}</p>
            <p>请尝试刷新页面或重新上传视频</p>
          </div>
        </div>
      )}

      <div className="player-wrapper">
        <video
          ref={videoRef}
          src={videoUrl}
          controls
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onCanPlay={handleCanPlay}
          onError={handleError}
          style={{ width: '100%', height: '100%', objectFit: 'contain' }}
        >
          您的浏览器不支持视频播放
        </video>
      </div>

      <div className="player-info">
        <span className="time-display">
          {ready ? `${formatTime(currentTime)} / ${formatTime(duration)}` : '加载中...'}
        </span>
      </div>
    </div>
  );
};

export default VideoPlayer;
