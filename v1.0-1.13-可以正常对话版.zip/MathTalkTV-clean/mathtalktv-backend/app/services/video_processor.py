"""
视频处理服务：处理视频上传、字幕提取、节点识别
"""
import uuid
import aiosqlite
from pathlib import Path
from typing import Optional, List, Dict
import ffmpeg
from openai import AsyncOpenAI

from app.core.config import settings
from app.models.schemas import Subtitle, Node, Video


class VideoProcessor:
    """视频处理器"""

    def __init__(self):
        # 初始化OpenAI客户端（用于Whisper）
        self.openai_client = AsyncOpenAI(
            api_key=settings.OPENAI_API_KEY,
            base_url=settings.OPENAI_BASE_URL
        )

    async def save_uploaded_file(self, file_content: bytes, filename: str) -> tuple[str, str]:
        """
        保存上传的视频文件

        Returns:
            (video_id, filepath)
        """
        video_id = str(uuid.uuid4())
        # 保持原始文件扩展名
        ext = Path(filename).suffix
        filepath = Path(settings.UPLOAD_DIR) / f"{video_id}{ext}"

        # 异步写入文件
        with open(filepath, "wb") as f:
            f.write(file_content)

        print(f"✅ 视频已保存: {filepath}")
        return video_id, str(filepath)

    async def extract_audio(self, video_path: str) -> str:
        """
        从视频中提取音频（转换为适合Whisper的格式）

        Returns:
            audio_path: 音频文件路径
        """
        audio_path = video_path.rsplit(".", 1)[0] + "_audio.mp3"

        try:
            # 使用ffmpeg提取音频
            stream = ffmpeg.input(video_path)
            stream = ffmpeg.output(stream, audio_path, acodec='libmp3lame', ac=1, ar='16000')
            ffmpeg.run(stream, overwrite_output=True, quiet=True)
            print(f"✅ 音频提取完成: {audio_path}")
            return audio_path
        except ffmpeg.Error as e:
            print(f"❌ FFmpeg错误: {e.stderr.decode() if e.stderr else str(e)}")
            raise Exception(f"音频提取失败: {str(e)}")

    async def get_video_duration(self, video_path: str) -> float:
        """获取视频时长（秒）"""
        try:
            probe = ffmpeg.probe(video_path)
            duration = float(probe['format']['duration'])
            return duration
        except Exception as e:
            print(f"⚠️ 无法获取视频时长: {e}")
            return 0.0

    async def whisper_extract(self, audio_path: str) -> List[Subtitle]:
        """
        使用Whisper API提取字幕（带时间戳）

        Returns:
            字幕列表
        """
        try:
            print("📝 正在调用Whisper API提取字幕...")

            # 打开音频文件
            with open(audio_path, "rb") as audio_file:
                # 调用Whisper API
                transcript = await self.openai_client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    response_format="verbose_json",  # 获取详细时间戳
                    language="zh"  # 指定中文
                )

            # 解析返回的字幕段落
            subtitles = []
            if hasattr(transcript, 'segments') and transcript.segments:
                for seg in transcript.segments:
                    subtitles.append(Subtitle(
                        text=seg['text'].strip(),
                        start_time=seg['start'],
                        end_time=seg['end']
                    ))
            else:
                # 如果没有segments，至少保存完整文本
                subtitles.append(Subtitle(
                    text=transcript.text,
                    start_time=0.0,
                    end_time=0.0
                ))

            print(f"✅ Whisper提取完成，共 {len(subtitles)} 段字幕")
            return subtitles

        except Exception as e:
            print(f"❌ Whisper提取失败: {str(e)}")
            raise Exception(f"字幕提取失败: {str(e)}")

    async def save_to_db(
        self,
        video_id: str,
        filename: str,
        filepath: str,
        duration: float,
        subtitles: List[Subtitle],
        status: str = "ready"
    ) -> None:
        """保存视频和字幕到数据库"""
        async with aiosqlite.connect(settings.DB_PATH) as db:
            # 更新视频信息（记录已存在）
            await db.execute("""
                UPDATE videos SET duration = ?, status = ?
                WHERE id = ?
            """, (duration, status, video_id))

            # 保存字幕
            for sub in subtitles:
                await db.execute("""
                    INSERT INTO subtitles (video_id, text, start_time, end_time)
                    VALUES (?, ?, ?, ?)
                """, (video_id, sub.text, sub.start_time, sub.end_time))

            await db.commit()
            print(f"✅ 视频信息已保存到数据库: {video_id}")

    async def update_video_status(self, video_id: str, status: str) -> None:
        """更新视频状态"""
        async with aiosqlite.connect(settings.DB_PATH) as db:
            await db.execute(
                "UPDATE videos SET status = ? WHERE id = ?",
                (status, video_id)
            )
            await db.commit()

    async def process_video(
        self,
        file_content: bytes,
        filename: str
    ) -> Dict:
        """
        完整的视频处理流程：保存视频 -> 提取音频 -> Whisper字幕提取

        Returns:
            处理结果字典
        """
        video_id = None
        audio_path = None
        try:
            # 1. 保存上传的视频
            video_id, filepath = await self.save_uploaded_file(file_content, filename)

            # 先在数据库中创建记录（状态为processing）
            async with aiosqlite.connect(settings.DB_PATH) as db:
                await db.execute("""
                    INSERT INTO videos (id, filename, filepath, status)
                    VALUES (?, ?, ?, 'processing')
                """, (video_id, filename, filepath))
                await db.commit()

            # 2. 获取视频时长
            try:
                duration = await self.get_video_duration(filepath)
            except Exception as e:
                print(f"⚠️ 无法获取视频时长: {e}")
                duration = 0.0

            # 3. 提取音频
            try:
                audio_path = await self.extract_audio(filepath)
            except Exception as e:
                print(f"❌ 音频提取失败: {e}")
                raise Exception("音频提取失败，请确保ffmpeg已安装")

            # 4. 使用Whisper提取字幕
            try:
                subtitles = await self.whisper_extract(audio_path)
            except Exception as e:
                print(f"❌ Whisper字幕提取失败: {e}")
                raise Exception("字幕提取失败，请检查OpenAI API配置")

            # 5. 保存到数据库（标记为ready_no_nodes，等待节点提取）
            await self.save_to_db(
                video_id=video_id,
                filename=filename,
                filepath=filepath,
                duration=duration,
                subtitles=subtitles,
                status="ready_no_nodes"
            )

            print(f"✅ 视频处理完成: {video_id}")

            return {
                "video_id": video_id,
                "status": "ready_no_nodes",
                "nodes_count": 0,
                "duration": duration,
                "subtitles_count": len(subtitles)
            }

        except Exception as e:
            print(f"❌ 视频处理失败: {str(e)}")
            if video_id:
                await self.update_video_status(video_id, "failed")
            raise e
        finally:
            # 清理临时音频文件
            if audio_path and Path(audio_path).exists():
                try:
                    Path(audio_path).unlink()
                    print(f"🗑️ 已删除临时音频文件: {audio_path}")
                except Exception as e:
                    print(f"⚠️ 清理音频文件失败: {e}")
