"""
RAG检索服务：基于语义相似度检索相关字幕片段
"""
import logging
from typing import List, Tuple
from openai import AsyncOpenAI
import numpy as np

from app.core.config import settings

logger = logging.getLogger(__name__)


class RAGRetriever:
    """RAG检索器 - 使用embedding进行语义检索"""

    def __init__(self):
        self.client = AsyncOpenAI(
            api_key=settings.UIUIAPI_KEY,
            base_url=settings.UIUIAPI_BASE_URL
        )
        self.embedding_model = "text-embedding-ada-002"

    async def get_embedding(self, text: str) -> List[float]:
        """获取文本的embedding向量"""
        try:
            response = await self.client.embeddings.create(
                model=self.embedding_model,
                input=text
            )
            return response.data[0].embedding
        except Exception as e:
            logger.error(f"获取embedding失败: {e}")
            return []

    def cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """计算余弦相似度"""
        if not vec1 or not vec2:
            return 0.0

        vec1_array = np.array(vec1)
        vec2_array = np.array(vec2)

        dot_product = np.dot(vec1_array, vec2_array)
        norm1 = np.linalg.norm(vec1_array)
        norm2 = np.linalg.norm(vec2_array)

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return float(dot_product / (norm1 * norm2))

    def chunk_text(self, text: str, chunk_size: int = 200, overlap: int = 50) -> List[str]:
        """将长文本分块"""
        if len(text) <= chunk_size:
            return [text]

        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]

            # 尽量在句号、问号、感叹号处断开
            if end < len(text):
                for punct in ['。', '！', '？', '.', '!', '?']:
                    last_punct = chunk.rfind(punct)
                    if last_punct > chunk_size // 2:  # 确保块不会太小
                        end = start + last_punct + 1
                        chunk = text[start:end]
                        break

            chunks.append(chunk.strip())
            start = end - overlap  # 重叠部分避免信息丢失

        return chunks

    async def retrieve_relevant_chunks(
        self,
        question: str,
        full_text: str,
        top_k: int = 3
    ) -> List[Tuple[str, float]]:
        """
        检索最相关的文本块

        Args:
            question: 用户问题
            full_text: 完整字幕文本
            top_k: 返回前K个最相关的块

        Returns:
            [(chunk_text, similarity_score), ...]
        """
        logger.info(f"🔍 RAG检索: 问题长度={len(question)}, 文本长度={len(full_text)}")

        # 1. 分块
        chunks = self.chunk_text(full_text, chunk_size=settings.RAG_CHUNK_SIZE)
        logger.info(f"📄 文本分块: {len(chunks)}个块")

        if not chunks:
            return []

        # 2. 获取问题的embedding
        question_embedding = await self.get_embedding(question)
        if not question_embedding:
            logger.warning("⚠️ 问题embedding获取失败，使用简单截取")
            # 降级到简单截取
            return [(full_text[:1000], 0.0)]

        # 3. 获取所有块的embedding并计算相似度
        chunk_scores = []
        for i, chunk in enumerate(chunks):
            chunk_embedding = await self.get_embedding(chunk)
            if chunk_embedding:
                similarity = self.cosine_similarity(question_embedding, chunk_embedding)
                chunk_scores.append((chunk, similarity))
                logger.debug(f"  块{i+1}: 相似度={similarity:.3f}, 长度={len(chunk)}")

        # 4. 按相似度排序并返回top_k
        chunk_scores.sort(key=lambda x: x[1], reverse=True)
        top_chunks = chunk_scores[:top_k]

        logger.info(f"✅ 检索完成: 返回{len(top_chunks)}个相关块")
        for i, (chunk, score) in enumerate(top_chunks):
            logger.info(f"  Top{i+1}: 相似度={score:.3f}, 内容预览={chunk[:50]}...")

        return top_chunks

    async def build_rag_context(
        self,
        question: str,
        full_text: str,
        top_k: int = 3
    ) -> str:
        """
        构建RAG上下文

        Returns:
            格式化的上下文文本
        """
        chunks = await self.retrieve_relevant_chunks(question, full_text, top_k)

        if not chunks:
            return "（暂无相关内容）"

        # 格式化上下文
        context_parts = []
        for i, (chunk, score) in enumerate(chunks, 1):
            context_parts.append(f"[相关片段{i}]（相似度: {score:.2f}）\n{chunk}")

        return "\n\n".join(context_parts)
