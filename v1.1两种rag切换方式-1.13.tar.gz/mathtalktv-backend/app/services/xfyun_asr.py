"""
讯飞语音识别（ASR）服务
使用讯飞实时语音转写API
"""
import asyncio
import websockets
import json
import base64
import hmac
import hashlib
from datetime import datetime
from time import mktime
from wsgiref.handlers import format_date_time
from urllib.parse import urlencode, urlparse
from typing import Callable, Optional
import logging

from app.core.config import settings

logger = logging.getLogger(__name__)


class XFYunASR:
    """讯飞实时语音识别"""

    # API配置
    HOST = "iat-api.xfyun.cn"
    URL = "wss://iat-api.xfyun.cn/v2/iat"

    # 音频参数
    AUDIO_FORMAT = "audio/L16;rate=16000"  # 16k采样率，16bit，单声道PCM

    # 状态码
    STATUS_FIRST_FRAME = 0  # 第一帧
    STATUS_CONTINUE_FRAME = 1  # 中间帧
    STATUS_LAST_FRAME = 2  # 最后一帧

    def __init__(self):
        self.app_id = settings.XFYUN_APP_ID
        self.api_key = settings.XFYUN_API_KEY
        self.api_secret = settings.XFYUN_API_SECRET

    def _generate_auth_url(self) -> str:
        """生成带鉴权参数的WebSocket URL"""
        # 生成RFC1123格式的时间戳
        now = datetime.now()
        date = format_date_time(mktime(now.timetuple()))

        # 拼接签名原文
        signature_origin = f"host: {self.HOST}\n"
        signature_origin += f"date: {date}\n"
        signature_origin += f"GET /v2/iat HTTP/1.1"

        # 使用hmac-sha256进行加密
        signature_sha = hmac.new(
            self.api_secret.encode('utf-8'),
            signature_origin.encode('utf-8'),
            digestmod=hashlib.sha256
        ).digest()

        # Base64编码
        signature_sha_base64 = base64.b64encode(signature_sha).decode('utf-8')

        # 拼接authorization
        authorization_origin = (
            f'api_key="{self.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature_sha_base64}"'
        )
        authorization = base64.b64encode(authorization_origin.encode('utf-8')).decode('utf-8')

        # 拼接URL参数
        params = {
            "authorization": authorization,
            "date": date,
            "host": self.HOST
        }

        return f"{self.URL}?{urlencode(params)}"

    async def recognize_stream(
        self,
        audio_stream,
        on_result: Callable[[str, bool], None],
        on_error: Optional[Callable[[str], None]] = None
    ):
        """
        实时语音识别（流式）

        Args:
            audio_stream: 音频数据流（异步迭代器，每次返回一个音频chunk）
            on_result: 识别结果回调 callback(text: str, is_final: bool)
            on_error: 错误回调 callback(error_msg: str)
        """
        url = self._generate_auth_url()

        try:
            async with websockets.connect(url) as ws:
                # 启动接收任务
                receive_task = asyncio.create_task(
                    self._receive_results(ws, on_result, on_error)
                )

                # 发送音频数据
                frame_id = 0
                async for audio_chunk in audio_stream:
                    status = self.STATUS_FIRST_FRAME if frame_id == 0 else self.STATUS_CONTINUE_FRAME

                    await self._send_audio_frame(ws, audio_chunk, status, frame_id)
                    frame_id += 1

                    # 控制发送速率（避免过快）
                    await asyncio.sleep(0.04)  # 40ms间隔，模拟实时音频

                # 发送结束帧
                await self._send_audio_frame(ws, b"", self.STATUS_LAST_FRAME, frame_id)

                # 等待接收任务完成
                await receive_task

        except Exception as e:
            logger.error(f"ASR识别失败: {e}")
            if on_error:
                on_error(str(e))

    async def _send_audio_frame(self, ws, audio_data: bytes, status: int, frame_id: int):
        """发送音频帧"""
        frame = {
            "common": {
                "app_id": self.app_id
            },
            "business": {
                "language": "zh_cn",  # 中文
                "domain": "iat",  # 通用领域
                "accent": "mandarin",  # 普通话
                "vad_eos": 2000,  # 静音超时时间（ms）
                "dwa": "wpgs"  # 动态修正
            },
            "data": {
                "status": status,
                "format": "audio/L16;rate=16000",
                "encoding": "raw",
                "audio": base64.b64encode(audio_data).decode('utf-8') if audio_data else ""
            }
        }

        # 只在第一帧发送business参数
        if status != self.STATUS_FIRST_FRAME:
            del frame["business"]

        await ws.send(json.dumps(frame))

    async def _receive_results(
        self,
        ws,
        on_result: Callable[[str, bool], None],
        on_error: Optional[Callable[[str], None]]
    ):
        """接收识别结果"""
        try:
            while True:
                message = await ws.recv()
                result = json.loads(message)

                code = result.get("code")
                if code != 0:
                    error_msg = f"ASR错误: code={code}, message={result.get('message')}"
                    logger.error(error_msg)
                    if on_error:
                        on_error(error_msg)
                    break

                # 解析识别结果
                data = result.get("data", {})
                status = data.get("status")

                if "result" in data:
                    # 提取识别文本
                    ws_list = data["result"]["ws"]
                    text = ""
                    for ws_item in ws_list:
                        for cw in ws_item["cw"]:
                            text += cw["w"]

                    # 判断是否为最终结果
                    is_final = (status == 2)

                    # 回调
                    if text:
                        on_result(text, is_final)

                # status=2表示识别结束
                if status == 2:
                    break

        except websockets.exceptions.ConnectionClosed:
            logger.info("ASR WebSocket连接已关闭")
        except Exception as e:
            logger.error(f"接收ASR结果失败: {e}")
            if on_error:
                on_error(str(e))


# 简单的测试函数
async def test_asr():
    """测试ASR功能（使用测试音频文件）"""
    asr = XFYunASR()

    # 模拟音频流
    async def audio_stream_generator():
        # 这里应该从麦克风或文件读取实际音频
        # 暂时返回空数据作为演示
        for i in range(5):
            yield b'\x00' * 1280  # 每帧640字节（40ms的16k采样率音频）

    def on_result(text, is_final):
        print(f"[{'最终' if is_final else '中间'}] {text}")

    def on_error(error_msg):
        print(f"错误: {error_msg}")

    await asr.recognize_stream(
        audio_stream_generator(),
        on_result=on_result,
        on_error=on_error
    )


if __name__ == "__main__":
    # 测试
    asyncio.run(test_asr())
