import aiosqlite
from app.core.config import settings


async def init_db():
    """初始化数据库表"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        # 创建 videos 表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS videos (
                id TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                filepath TEXT NOT NULL,
                duration REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'processing'
            )
        """)

        # 创建 nodes 表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS nodes (
                id TEXT PRIMARY KEY,
                video_id TEXT NOT NULL,
                order_num INTEGER NOT NULL,
                start_time REAL NOT NULL,
                end_time REAL NOT NULL,
                title TEXT,
                summary TEXT,
                FOREIGN KEY (video_id) REFERENCES videos(id)
            )
        """)

        # 创建 subtitles 表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS subtitles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT NOT NULL,
                text TEXT,
                start_time REAL,
                end_time REAL,
                FOREIGN KEY (video_id) REFERENCES videos(id)
            )
        """)

        await db.commit()
        print("✅ 数据库初始化完成")


async def get_db():
    """获取数据库连接（依赖注入用）"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        yield db
