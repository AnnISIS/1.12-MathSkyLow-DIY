// 视频信息
export interface Video {
  id: string;
  filename: string;
  duration?: number;
  nodes: Node[];
}

// 知识点节点
export interface Node {
  id: string;
  order_num: number;
  start_time: number;
  end_time: number;
  title: string;
  summary: string;
}

// 字幕
export interface Subtitle {
  text: string;
  start_time: number;
  end_time: number;
}

// 视频上传响应
export interface VideoUploadResponse {
  video_id: string;
  status: 'processing' | 'ready' | 'ready_no_nodes' | 'failed';
  nodes_count: number;
  duration?: number;
}

// 聊天消息
export interface ChatMessage {
  type: 'text' | 'latex' | 'status';
  content?: string;
  role?: 'user' | 'assistant';
  message?: string; // 用于status类型
}

// 倾听状态
export type ListeningState = 'idle' | 'listening' | 'processing' | 'speaking';
