"""
A/B测试框架 - 对比向量检索、BM25检索、混合检索

功能:
1. 定义测试查询集(包含ground truth)
2. 执行三种检索策略
3. 计算评估指标(准确率、MRR、NDCG)
4. 生成对比报告
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from hybrid_retriever import HybridRetriever
from typing import List, Dict, Any, Tuple
import time


class RetrievalEvaluator:
    """检索评估器"""

    def __init__(self):
        self.retriever = HybridRetriever()

    @staticmethod
    def calculate_precision_at_k(results: List[str], relevant: List[str], k: int = 3) -> float:
        """
        计算P@K (Precision at K)

        Args:
            results: 检索结果的chunk_id列表
            relevant: 相关文档的chunk_id列表
            k: 评估前K个结果

        Returns:
            精确率 (0-1)
        """
        if not results or not relevant:
            return 0.0

        top_k = results[:k]
        relevant_in_top_k = sum(1 for doc in top_k if doc in relevant)

        return relevant_in_top_k / k

    @staticmethod
    def calculate_mrr(results: List[str], relevant: List[str]) -> float:
        """
        计算MRR (Mean Reciprocal Rank)

        Returns:
            倒数排名 (0-1)
        """
        if not results or not relevant:
            return 0.0

        for rank, doc in enumerate(results, start=1):
            if doc in relevant:
                return 1.0 / rank

        return 0.0

    @staticmethod
    def calculate_recall_at_k(results: List[str], relevant: List[str], k: int = 10) -> float:
        """
        计算R@K (Recall at K)

        Returns:
            召回率 (0-1)
        """
        if not relevant:
            return 0.0

        top_k = results[:k]
        relevant_in_top_k = sum(1 for doc in top_k if doc in relevant)

        return relevant_in_top_k / len(relevant)

    def evaluate_query(self,
                       query: str,
                       relevant_chunks: List[str],
                       strategy: str = 'auto') -> Dict[str, Any]:
        """
        评估单个查询

        Args:
            query: 查询文本
            relevant_chunks: 相关文档的chunk_id列表(ground truth)
            strategy: 检索策略

        Returns:
            评估结果字典
        """
        # 执行检索
        start_time = time.time()
        results = self.retriever.hybrid_search(query, top_k=10, strategy=strategy)
        elapsed_time = time.time() - start_time

        # 提取chunk_id列表
        result_ids = [r['chunk_id'] for r in results]

        # 计算指标
        metrics = {
            'query': query,
            'strategy': strategy,
            'elapsed_time': elapsed_time,
            'p@1': self.calculate_precision_at_k(result_ids, relevant_chunks, k=1),
            'p@3': self.calculate_precision_at_k(result_ids, relevant_chunks, k=3),
            'p@5': self.calculate_precision_at_k(result_ids, relevant_chunks, k=5),
            'mrr': self.calculate_mrr(result_ids, relevant_chunks),
            'r@10': self.calculate_recall_at_k(result_ids, relevant_chunks, k=10),
            'top1_chunk': result_ids[0] if result_ids else None,
            'top1_correct': result_ids[0] in relevant_chunks if result_ids else False
        }

        return metrics


class ABTestSuite:
    """A/B测试套件"""

    # 测试查询集(包含ground truth)
    TEST_QUERIES = [
        {
            'query': '什么是一元二次方程?',
            'relevant': ['concept_01_definition'],  # 最相关的chunks
            'category': 'definition'
        },
        {
            'query': '判别式公式是什么?',
            'relevant': ['concept_08_discriminant', 'faq_03_discriminant_vs_vieta'],
            'category': 'formula'
        },
        {
            'query': '如何用配方法解方程?',
            'relevant': ['concept_05_completing_square', 'method_02_completing_square_steps', 'faq_01_why_completing_square'],
            'category': 'method'
        },
        {
            'query': '为什么要学配方法?',
            'relevant': ['faq_01_why_completing_square'],
            'category': 'why'
        },
        {
            'query': '韦达定理是什么?',
            'relevant': ['concept_09_vieta_theorem', 'faq_03_discriminant_vs_vieta'],
            'category': 'formula'
        },
        {
            'query': '判别式和韦达定理有什么区别?',
            'relevant': ['faq_03_discriminant_vs_vieta'],
            'category': 'comparison'
        },
        {
            'query': '增长率问题怎么做?',
            'relevant': ['faq_05_growth_rate'],
            'category': 'application'
        },
        {
            'query': '一元二次方程有几个根?',
            'relevant': ['faq_04_one_or_two_roots', 'concept_08_discriminant'],
            'category': 'concept'
        },
        {
            'query': '怎么选择解题方法?',
            'relevant': ['method_01_decision_tree', 'method_03_problem_recognition'],
            'category': 'method'
        },
        {
            'query': '公式法的步骤',
            'relevant': ['concept_06_quadratic_formula'],
            'category': 'method'
        }
    ]

    def __init__(self):
        self.evaluator = RetrievalEvaluator()

    def run_ab_test(self) -> Dict[str, Any]:
        """
        运行完整A/B测试

        Returns:
            对比结果字典
        """
        print("=" * 80)
        print("A/B测试: 向量检索 vs BM25检索 vs 混合检索")
        print("=" * 80)
        print(f"\n测试查询数: {len(self.TEST_QUERIES)}\n")

        strategies = ['vector', 'bm25', 'auto']
        strategy_names = {
            'vector': '向量检索',
            'bm25': 'BM25检索',
            'auto': '混合检索(Auto)'
        }

        results = {strategy: [] for strategy in strategies}

        # 对每个查询测试三种策略
        for i, test_case in enumerate(self.TEST_QUERIES, start=1):
            query = test_case['query']
            relevant = test_case['relevant']
            category = test_case['category']

            print(f"[{i}/{len(self.TEST_QUERIES)}] {query} (类型:{category})")

            for strategy in strategies:
                metrics = self.evaluator.evaluate_query(query, relevant, strategy=strategy)
                metrics['category'] = category
                results[strategy].append(metrics)

                # 显示Top1结果
                symbol = "✅" if metrics['top1_correct'] else "❌"
                print(f"  {strategy_names[strategy]}: {symbol} {metrics['top1_chunk']} (P@1={metrics['p@1']:.2f}, MRR={metrics['mrr']:.3f})")

            print()

        # 计算总体统计
        summary = self._calculate_summary(results, strategy_names)

        return {
            'detailed_results': results,
            'summary': summary
        }

    def _calculate_summary(self, results: Dict[str, List[Dict]], strategy_names: Dict[str, str]) -> Dict[str, Any]:
        """计算总体统计"""
        summary = {}

        for strategy, metrics_list in results.items():
            n = len(metrics_list)

            summary[strategy] = {
                'name': strategy_names[strategy],
                'avg_p@1': sum(m['p@1'] for m in metrics_list) / n,
                'avg_p@3': sum(m['p@3'] for m in metrics_list) / n,
                'avg_p@5': sum(m['p@5'] for m in metrics_list) / n,
                'avg_mrr': sum(m['mrr'] for m in metrics_list) / n,
                'avg_r@10': sum(m['r@10'] for m in metrics_list) / n,
                'avg_time': sum(m['elapsed_time'] for m in metrics_list) / n,
                'top1_accuracy': sum(1 for m in metrics_list if m['top1_correct']) / n
            }

        return summary

    def print_summary(self, summary: Dict[str, Any]):
        """打印对比报告"""
        print("\n" + "=" * 80)
        print("📊 A/B测试总结报告")
        print("=" * 80)

        # 表头
        print(f"\n{'策略':<15} {'P@1':<8} {'P@3':<8} {'P@5':<8} {'MRR':<8} {'R@10':<8} {'Top1准确率':<10} {'平均耗时(s)'}")
        print("-" * 80)

        # 每种策略的数据
        for strategy in ['vector', 'bm25', 'auto']:
            stats = summary[strategy]
            print(f"{stats['name']:<15} "
                  f"{stats['avg_p@1']:<8.3f} "
                  f"{stats['avg_p@3']:<8.3f} "
                  f"{stats['avg_p@5']:<8.3f} "
                  f"{stats['avg_mrr']:<8.3f} "
                  f"{stats['avg_r@10']:<8.3f} "
                  f"{stats['top1_accuracy']:<10.1%} "
                  f"{stats['avg_time']:.3f}")

        print("\n" + "=" * 80)

        # 找出最佳策略
        best_p1 = max(summary.values(), key=lambda x: x['avg_p@1'])
        best_mrr = max(summary.values(), key=lambda x: x['avg_mrr'])
        best_speed = min(summary.values(), key=lambda x: x['avg_time'])

        print("🏆 最佳表现:")
        print(f"  - 准确率最高 (P@1): {best_p1['name']} ({best_p1['avg_p@1']:.3f})")
        print(f"  - 排序质量最优 (MRR): {best_mrr['name']} ({best_mrr['avg_mrr']:.3f})")
        print(f"  - 速度最快: {best_speed['name']} ({best_speed['avg_time']:.3f}s)")

        print("\n" + "=" * 80)

        # 结论
        print("📝 结论:")

        hybrid_stats = summary['auto']
        vector_stats = summary['vector']
        bm25_stats = summary['bm25']

        p1_improvement_vs_vector = (hybrid_stats['avg_p@1'] - vector_stats['avg_p@1']) / vector_stats['avg_p@1'] * 100 if vector_stats['avg_p@1'] > 0 else 0
        p1_improvement_vs_bm25 = (hybrid_stats['avg_p@1'] - bm25_stats['avg_p@1']) / bm25_stats['avg_p@1'] * 100 if bm25_stats['avg_p@1'] > 0 else 0

        print(f"  1. 混合检索 P@1 相比纯向量检索提升: {p1_improvement_vs_vector:+.1f}%")
        print(f"  2. 混合检索 P@1 相比纯BM25检索提升: {p1_improvement_vs_bm25:+.1f}%")
        print(f"  3. 混合检索 Top1准确率: {hybrid_stats['top1_accuracy']:.1%}")

        if hybrid_stats['avg_p@1'] > vector_stats['avg_p@1'] and hybrid_stats['avg_p@1'] > bm25_stats['avg_p@1']:
            print("\n  ✅ 混合检索策略在准确率上优于单一检索方法!")
        elif hybrid_stats['avg_mrr'] > vector_stats['avg_mrr'] and hybrid_stats['avg_mrr'] > bm25_stats['avg_mrr']:
            print("\n  ✅ 混合检索在整体排序质量上表现最佳!")
        else:
            print("\n  ⚠️  混合检索未显示明显优势,可能需要调整权重参数")

        print("=" * 80)


def main():
    """运行A/B测试"""
    suite = ABTestSuite()

    # 运行测试
    test_results = suite.run_ab_test()

    # 打印报告
    suite.print_summary(test_results['summary'])

    print("\n✅ A/B测试完成!")
    print("💡 提示: 可以根据测试结果调整hybrid_retriever.py中的权重参数")


if __name__ == "__main__":
    main()
