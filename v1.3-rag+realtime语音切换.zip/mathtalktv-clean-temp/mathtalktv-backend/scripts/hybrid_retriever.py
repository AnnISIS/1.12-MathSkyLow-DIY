"""
Phase 4: 混合检索实现

功能:
1. 查询分类器 - 根据问题类型选择检索策略
2. RRF融合算法 - 合并向量检索和BM25检索结果
3. 统一检索接口 - 提供灵活的混合检索API
"""

import json
import pickle
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple
from collections import defaultdict

# 向量检索依赖
try:
    import chromadb
    from openai import OpenAI
    from dotenv import load_dotenv
    import os
    VECTOR_AVAILABLE = True
except ImportError:
    VECTOR_AVAILABLE = False
    print("⚠️  向量检索依赖未安装")

# BM25检索依赖
try:
    import sys
    sys.path.append(str(Path(__file__).parent))
    from simple_bm25 import SimpleBM25
    BM25_AVAILABLE = True
except ImportError:
    BM25_AVAILABLE = False
    print("⚠️  BM25依赖未安装")


class QueryClassifier:
    """查询分类器 - 识别问题类型并推荐检索策略"""

    # 定义问题类型的特征词
    PATTERNS = {
        'definition': {
            'keywords': ['是什么', '定义', '概念', '含义', '指的是', '什么是', '叫做'],
            'weight': {'vector': 0.3, 'bm25': 0.7}  # BM25更适合精确定义
        },
        'method': {
            'keywords': ['怎么', '如何', '步骤', '方法', '求解', '解法', '计算'],
            'weight': {'vector': 0.5, 'bm25': 0.5}  # 两者平衡
        },
        'why': {
            'keywords': ['为什么', '原因', '为啥', '怎么回事', '道理'],
            'weight': {'vector': 0.8, 'bm25': 0.2}  # 向量更适合理解类问题
        },
        'comparison': {
            'keywords': ['区别', '不同', '对比', '比较', '关系', '联系'],
            'weight': {'vector': 0.7, 'bm25': 0.3}  # 向量更适合关系理解
        },
        'application': {
            'keywords': ['例题', '应用', '实际', '场景', '案例', '练习'],
            'weight': {'vector': 0.6, 'bm25': 0.4}  # 偏向语义理解
        },
        'formula': {
            'keywords': ['公式', '求根公式', '判别式', '韦达', 'Δ', '√'],
            'weight': {'vector': 0.2, 'bm25': 0.8}  # BM25精确匹配公式
        }
    }

    def classify(self, query: str) -> Tuple[str, Dict[str, float]]:
        """
        分类查询并返回推荐的检索权重

        Returns:
            (query_type, weights): 查询类型和推荐权重
        """
        query_lower = query.lower()

        # 匹配每种类型的得分
        scores = {}
        for qtype, config in self.PATTERNS.items():
            score = sum(1 for kw in config['keywords'] if kw in query_lower)
            if score > 0:
                scores[qtype] = score

        # 如果有匹配,返回得分最高的类型
        if scores:
            best_type = max(scores, key=scores.get)
            return best_type, self.PATTERNS[best_type]['weight']

        # 默认均衡策略
        return 'general', {'vector': 0.5, 'bm25': 0.5}


class RRFFusion:
    """Reciprocal Rank Fusion - 倒数排名融合算法"""

    def __init__(self, k: int = 60):
        """
        Args:
            k: 平滑参数,防止排名靠前的文档得分过高
        """
        self.k = k

    def fuse(self,
             vector_results: List[Dict[str, Any]],
             bm25_results: List[Dict[str, Any]],
             alpha: float = 0.5,
             beta: float = 0.5) -> List[Dict[str, Any]]:
        """
        融合两个检索结果

        Args:
            vector_results: 向量检索结果 [{'chunk_id': ..., 'score': ...}, ...]
            bm25_results: BM25检索结果
            alpha: 向量检索权重
            beta: BM25检索权重

        Returns:
            融合后的结果列表
        """
        # 计算每个chunk的RRF得分
        rrf_scores = defaultdict(float)
        chunk_data = {}  # 存储chunk的详细信息

        # 向量检索贡献
        for rank, result in enumerate(vector_results):
            chunk_id = result['chunk_id']
            rrf_scores[chunk_id] += alpha / (self.k + rank + 1)
            chunk_data[chunk_id] = result

        # BM25检索贡献
        for rank, result in enumerate(bm25_results):
            chunk_id = result['chunk_id']
            rrf_scores[chunk_id] += beta / (self.k + rank + 1)

            # 如果向量检索没有这个chunk,添加它
            if chunk_id not in chunk_data:
                chunk_data[chunk_id] = result

        # 按RRF得分排序
        sorted_chunks = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)

        # 构建最终结果
        fused_results = []
        for chunk_id, rrf_score in sorted_chunks:
            result = chunk_data[chunk_id].copy()
            result['rrf_score'] = rrf_score
            fused_results.append(result)

        return fused_results


class HybridRetriever:
    """混合检索器 - 统一接口"""

    def __init__(self, rag_dir: str = "./rag", data_dir: str = "./data"):
        self.rag_dir = Path(rag_dir)
        self.data_dir = Path(data_dir)

        # 加载processed chunks
        chunks_path = self.rag_dir / "processed_chunks.json"
        with open(chunks_path, 'r', encoding='utf-8') as f:
            self.chunks_data = json.load(f)

        # 初始化组件
        self.classifier = QueryClassifier()
        self.rrf = RRFFusion(k=60)

        # 初始化检索器
        self._init_vector_retriever()
        self._init_bm25_retriever()

    def _init_vector_retriever(self):
        """初始化向量检索器"""
        if not VECTOR_AVAILABLE:
            self.vector_retriever = None
            return

        load_dotenv()

        # OpenAI client
        self.openai_client = OpenAI(
            api_key=os.getenv("UIUIAPI_KEY"),
            base_url=os.getenv("UIUIAPI_BASE_URL"),
            timeout=60.0
        )

        # Chroma client
        self.chroma_client = chromadb.PersistentClient(path=str(self.data_dir / "chroma_db"))
        self.collection = self.chroma_client.get_collection("math_rag")

        print("✅ 向量检索器已加载")

    def _init_bm25_retriever(self):
        """初始化BM25检索器"""
        if not BM25_AVAILABLE:
            self.bm25_retriever = None
            return

        # 加载BM25索引
        index_path = self.data_dir / "bm25_index.pkl"
        with open(index_path, 'rb') as f:
            index_data = pickle.load(f)

        self.bm25 = index_data['bm25']
        self.bm25_chunk_ids = index_data['chunk_ids']

        print("✅ BM25检索器已加载")

    def _tokenize(self, text: str) -> List[str]:
        """分词(与build_bm25_index.py保持一致)"""
        # 1. 提取中文字符(单字)
        chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)

        # 2. 提取英文单词
        english_words = re.findall(r'[a-zA-Z]+', text)

        # 3. 提取数字和数学符号
        math_symbols = re.findall(r'[0-9²³±×÷√Δ]+', text)

        # 4. 过滤停用词
        stopwords = {'的', '了', '是', '在', '有', '和', '就', '都', '而',
                    '及', '与', '或', '等', '为', '以', '从', '把', '被'}
        chinese_chars = [c for c in chinese_chars if c not in stopwords]

        # 合并所有token
        return chinese_chars + english_words + math_symbols

    def vector_search(self, query: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """向量检索"""
        if not VECTOR_AVAILABLE or self.openai_client is None:
            return []

        # 生成query embedding
        response = self.openai_client.embeddings.create(
            model="text-embedding-3-small",
            input=query
        )
        query_embedding = response.data[0].embedding

        # 搜索
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=["metadatas", "distances"]
        )

        # 格式化结果
        formatted_results = []
        for metadata, distance in zip(results['metadatas'][0], results['distances'][0]):
            formatted_results.append({
                'chunk_id': metadata['chunk_id'],
                'score': 1 - distance,  # 转换为相似度
                'type': metadata['type'],
                'title': metadata['title'],
                'difficulty': metadata['difficulty'],
                'source': 'vector'
            })

        return formatted_results

    def bm25_search(self, query: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """BM25检索"""
        if not BM25_AVAILABLE or self.bm25 is None:
            return []

        # 分词
        query_tokens = self._tokenize(query)

        # BM25打分
        scores = self.bm25.get_scores(query_tokens)

        # 获取top_k
        top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]

        # 格式化结果
        formatted_results = []
        for idx in top_indices:
            chunk_id = self.bm25_chunk_ids[idx]

            # 获取chunk元数据
            chunk = next((c for c in self.chunks_data['chunks'] if c['chunk_id'] == chunk_id), None)
            if chunk:
                formatted_results.append({
                    'chunk_id': chunk_id,
                    'score': scores[idx],
                    'type': chunk['metadata']['type'],
                    'title': chunk['title'],
                    'difficulty': chunk['metadata']['difficulty'],
                    'source': 'bm25'
                })

        return formatted_results

    def hybrid_search(self,
                      query: str,
                      top_k: int = 5,
                      strategy: str = 'auto') -> List[Dict[str, Any]]:
        """
        混合检索 - 主接口

        Args:
            query: 查询文本
            top_k: 返回结果数量
            strategy: 检索策略
                - 'auto': 自动分类并选择权重
                - 'vector': 仅向量检索
                - 'bm25': 仅BM25检索
                - 'balanced': 均衡混合(0.5/0.5)

        Returns:
            检索结果列表
        """
        print(f"\n查询: {query}")
        print(f"策略: {strategy}")

        # 策略1: 仅向量检索
        if strategy == 'vector':
            results = self.vector_search(query, top_k=top_k)
            return self._enrich_results(results)

        # 策略2: 仅BM25检索
        if strategy == 'bm25':
            results = self.bm25_search(query, top_k=top_k)
            return self._enrich_results(results)

        # 策略3: 混合检索
        # 3.1 查询分类
        if strategy == 'auto':
            query_type, weights = self.classifier.classify(query)
            print(f"问题类型: {query_type}")
            print(f"权重分配: 向量={weights['vector']:.1f}, BM25={weights['bm25']:.1f}")
        else:  # balanced
            query_type = 'balanced'
            weights = {'vector': 0.5, 'bm25': 0.5}
            print(f"使用均衡权重")

        # 3.2 执行两种检索
        vector_results = self.vector_search(query, top_k=20)
        bm25_results = self.bm25_search(query, top_k=20)

        print(f"\n向量检索: {len(vector_results)}个结果")
        print(f"BM25检索: {len(bm25_results)}个结果")

        # 3.3 RRF融合
        fused_results = self.rrf.fuse(
            vector_results,
            bm25_results,
            alpha=weights['vector'],
            beta=weights['bm25']
        )

        # 3.4 返回top_k
        return self._enrich_results(fused_results[:top_k])

    def _enrich_results(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """丰富结果信息(添加完整的chunk内容)"""
        enriched = []

        for result in results:
            chunk_id = result['chunk_id']

            # 查找完整chunk
            chunk = next((c for c in self.chunks_data['chunks'] if c['chunk_id'] == chunk_id), None)

            if chunk:
                enriched_result = result.copy()
                enriched_result['content'] = chunk['content']
                enriched_result['keywords'] = chunk['metadata']['keywords']
                enriched_result['formulas'] = chunk['metadata'].get('formulas', [])
                enriched_result['source_file'] = chunk['source_file']
                enriched.append(enriched_result)

        return enriched


def main():
    """测试混合检索"""
    print("=" * 80)
    print("Phase 4: 混合检索测试")
    print("=" * 80)

    # 创建检索器
    retriever = HybridRetriever()

    # 测试查询
    test_queries = [
        ("什么是判别式?", "auto"),  # 定义类 → BM25权重↑
        ("如何用配方法解方程?", "auto"),  # 方法类 → 均衡
        ("为什么要学配方法?", "auto"),  # Why类 → 向量权重↑
        ("判别式和韦达定理的区别", "auto"),  # 比较类 → 向量权重↑
        ("增长率问题", "auto"),  # 应用类 → 偏向量
    ]

    for query, strategy in test_queries:
        print("\n" + "=" * 80)
        results = retriever.hybrid_search(query, top_k=3, strategy=strategy)

        print(f"\n📊 Top 3 结果:\n")
        for i, result in enumerate(results):
            print(f"{i+1}. [{result['type']}] {result['title']}")
            print(f"   难度: {result['difficulty']}")

            # 显示得分
            if 'rrf_score' in result:
                print(f"   RRF得分: {result['rrf_score']:.4f}")
            elif 'score' in result:
                print(f"   {result['source']}得分: {result['score']:.4f}")

            print(f"   关键词: {', '.join(result['keywords'][:5])}")
            print(f"   内容预览: {result['content'][:80]}...")
            print()

    print("=" * 80)
    print("Phase 4 完成! 混合检索已实现")
    print("=" * 80)


if __name__ == "__main__":
    main()
