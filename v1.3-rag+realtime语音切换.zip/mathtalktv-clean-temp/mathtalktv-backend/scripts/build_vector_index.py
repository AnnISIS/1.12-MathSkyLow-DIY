"""
Phase 2: 向量索引构建

使用Chroma + OpenAI Embeddings构建向量检索系统
"""

import json
import os
from pathlib import Path
from typing import List, Dict, Any
from dotenv import load_dotenv

# 加载.env文件
load_dotenv()

# 延迟导入,先检查依赖
try:
    import chromadb
    from chromadb.config import Settings
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False
    print("⚠️  chromadb未安装")

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    print("⚠️  openai未安装")


class RAGVectorIndexer:
    """RAG向量索引构建器"""

    def __init__(
        self,
        rag_dir: str = "./rag",
        chroma_dir: str = "./data/chroma_db",
        embedding_model: str = "text-embedding-3-small"
    ):
        self.rag_dir = Path(rag_dir)
        self.chroma_dir = Path(chroma_dir)
        self.embedding_model = embedding_model

        # 加载processed chunks
        chunks_path = self.rag_dir / "processed_chunks.json"
        with open(chunks_path, 'r', encoding='utf-8') as f:
            self.data = json.load(f)

        # 初始化OpenAI client
        api_key = os.getenv("UIUIAPI_KEY") or os.getenv("OPENAI_API_KEY")
        base_url = os.getenv("UIUIAPI_BASE_URL") or os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")

        if OPENAI_AVAILABLE and api_key:
            self.client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=60.0,  # 增加超时时间
                max_retries=2
            )
            print(f"✅ 使用API: {base_url}")
        else:
            self.client = None
            print("⚠️  OpenAI API未配置")

        # 初始化Chroma
        if CHROMA_AVAILABLE:
            self.chroma_client = chromadb.PersistentClient(
                path=str(self.chroma_dir),
                settings=Settings(anonymized_telemetry=False)
            )
        else:
            self.chroma_client = None

    def get_embedding(self, text: str) -> List[float]:
        """获取文本的embedding向量"""
        if not self.client:
            raise ValueError("OpenAI client未初始化")

        response = self.client.embeddings.create(
            model=self.embedding_model,
            input=text
        )
        return response.data[0].embedding

    def create_collection(self, collection_name: str = "math_rag"):
        """创建或获取Chroma collection"""
        if not self.chroma_client:
            raise ValueError("Chroma client未初始化")

        # 删除已存在的collection(重新构建)
        try:
            self.chroma_client.delete_collection(collection_name)
            print(f"已删除旧collection: {collection_name}")
        except:
            pass

        # 创建新collection
        collection = self.chroma_client.create_collection(
            name=collection_name,
            metadata={"description": "一元二次方程RAG知识库"}
        )
        print(f"✅ 创建collection: {collection_name}")
        return collection

    def build_vector_index(self, batch_size: int = 10):
        """构建向量索引"""
        print("=" * 60)
        print("开始构建向量索引")
        print("=" * 60)

        # 创建collection
        collection = self.create_collection()

        chunks = self.data['chunks']
        total = len(chunks)

        print(f"\n总共{total}个chunks,开始生成embeddings...")

        # 批处理生成embeddings
        for i in range(0, total, batch_size):
            batch = chunks[i:i+batch_size]
            batch_ids = []
            batch_texts = []
            batch_metadatas = []

            for chunk in batch:
                # 准备文本(title + content)
                text = f"{chunk['title']}\n\n{chunk['content']}"

                # 准备metadata(Chroma会自动存储)
                metadata = {
                    "chunk_id": chunk['chunk_id'],
                    "source_file": chunk['source_file'],
                    "title": chunk['title'],
                    "type": chunk['metadata']['type'],
                    "difficulty": chunk['metadata']['difficulty'],
                    "topics": ",".join(chunk['metadata']['topics']),
                    "keywords": ",".join(chunk['metadata']['keywords'][:10]),  # 限制长度
                }

                batch_ids.append(chunk['chunk_id'])
                batch_texts.append(text)
                batch_metadatas.append(metadata)

            # 添加到collection(Chroma会自动调用embedding function)
            # 但我们手动生成embeddings更可控
            print(f"  处理 {i+1}-{min(i+batch_size, total)} / {total}...", end=" ")

            try:
                # 生成embeddings
                embeddings = []
                for text in batch_texts:
                    emb = self.get_embedding(text)
                    embeddings.append(emb)

                # 添加到Chroma
                collection.add(
                    ids=batch_ids,
                    documents=batch_texts,
                    metadatas=batch_metadatas,
                    embeddings=embeddings
                )
                print("✓")
            except Exception as e:
                print(f"\n错误: {e}")
                continue

        print(f"\n✅ 向量索引构建完成!")
        print(f"📊 统计:")
        print(f"  - Collection: {collection.name}")
        print(f"  - 总vectors: {collection.count()}")
        print(f"  - Embedding model: {self.embedding_model}")

        return collection

    def test_search(self, query: str, top_k: int = 3):
        """测试向量检索"""
        print("\n" + "=" * 60)
        print(f"测试查询: {query}")
        print("=" * 60)

        collection = self.chroma_client.get_collection("math_rag")

        # 生成query embedding
        query_embedding = self.get_embedding(query)

        # 搜索
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=["documents", "metadatas", "distances"]
        )

        print(f"\nTop {top_k} 结果:\n")
        for i, (doc, metadata, distance) in enumerate(zip(
            results['documents'][0],
            results['metadatas'][0],
            results['distances'][0]
        )):
            print(f"{i+1}. [{metadata['type']}] {metadata['title']}")
            print(f"   相似度: {1 - distance:.4f}")
            print(f"   难度: {metadata['difficulty']}")
            print(f"   来源: {metadata['source_file']}")
            print(f"   内容预览: {doc[:100]}...")
            print()

def main():
    """主函数"""
    # 检查依赖
    if not CHROMA_AVAILABLE:
        print("❌ 请先安装chromadb: pip install chromadb")
        return

    if not OPENAI_AVAILABLE:
        print("❌ 请先安装openai: pip install openai")
        return

    # 检查API KEY
    if not os.getenv("OPENAI_API_KEY") and not os.getenv("DASHSCOPE_API_KEY"):
        print("❌ 请设置环境变量 OPENAI_API_KEY 或 DASHSCOPE_API_KEY")
        return

    # 创建索引器
    indexer = RAGVectorIndexer()

    # 构建向量索引
    collection = indexer.build_vector_index(batch_size=5)  # 小批次避免API限流

    # 测试查询
    test_queries = [
        "如何判断一元二次方程有几个根?",
        "韦达定理是什么?",
        "配方法的步骤",
        "增长率问题怎么列方程?"
    ]

    for query in test_queries:
        indexer.test_search(query, top_k=3)

    print("\n" + "=" * 60)
    print("Phase 2 完成! 向量索引已构建")
    print("=" * 60)


if __name__ == "__main__":
    main()
