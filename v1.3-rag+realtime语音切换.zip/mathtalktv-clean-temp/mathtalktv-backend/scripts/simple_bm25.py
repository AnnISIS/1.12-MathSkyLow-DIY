"""
简化版BM25实现(无需外部依赖)
"""

import math
from collections import Counter
from typing import List, Dict


class SimpleBM25:
    """简化的BM25算法实现"""

    def __init__(self, corpus: List[List[str]], k1: float = 1.5, b: float = 0.75):
        """
        Args:
            corpus: 分词后的文档列表 [[word1, word2, ...], ...]
            k1: 词频饱和参数
            b: 文档长度归一化参数
        """
        self.corpus = corpus
        self.k1 = k1
        self.b = b

        # 计算文档数和平均文档长度
        self.N = len(corpus)
        self.avgdl = sum(len(doc) for doc in corpus) / self.N if self.N > 0 else 0

        # 计算IDF
        self.idf = self._calculate_idf()

    def _calculate_idf(self) -> Dict[str, float]:
        """计算IDF(逆文档频率)"""
        idf = {}
        df = Counter()  # 文档频率

        # 统计每个词出现在多少文档中
        for doc in self.corpus:
            unique_words = set(doc)
            for word in unique_words:
                df[word] += 1

        # 计算IDF
        for word, freq in df.items():
            idf[word] = math.log((self.N - freq + 0.5) / (freq + 0.5) + 1)

        return idf

    def get_scores(self, query: List[str]) -> List[float]:
        """计算查询与每个文档的BM25分数"""
        scores = []

        for doc in self.corpus:
            score = 0.0
            doc_len = len(doc)
            word_freq = Counter(doc)

            for word in query:
                if word not in self.idf:
                    continue

                # 词频
                tf = word_freq.get(word, 0)

                # BM25公式
                idf = self.idf[word]
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (1 - self.b + self.b * doc_len / self.avgdl)

                score += idf * (numerator / denominator)

            scores.append(score)

        return scores


# 测试
if __name__ == "__main__":
    corpus = [
        ["判别式", "定义", "公式", "Δ"],
        ["韦达定理", "两根", "之和", "之积"],
        ["配方法", "步骤", "完全", "平方"]
    ]

    bm25 = SimpleBM25(corpus)
    query = ["判别式", "公式"]
    scores = bm25.get_scores(query)

    print("BM25分数:", scores)
    print("最相关文档:", scores.index(max(scores)))
