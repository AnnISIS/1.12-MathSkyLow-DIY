"""
Phase 3: 关键词索引(BM25)构建

使用BM25算法实现关键词检索,与向量检索互补
"""

import json
import pickle
from pathlib import Path
from typing import List, Dict, Any
import re

# 尝试导入jieba和rank_bm25
try:
    import jieba
    import jieba.analyse
    JIEBA_AVAILABLE = True
except ImportError:
    JIEBA_AVAILABLE = False
    print("⚠️  jieba未安装,将使用简单分词")

try:
    from rank_bm25 import BM25Okapi
    BM25_AVAILABLE = True
except ImportError:
    # 使用自己实现的BM25
    from simple_bm25 import SimpleBM25 as BM25Okapi
    BM25_AVAILABLE = True
    print("⚠️  使用简化版BM25实现")


class BM25Indexer:
    """BM25关键词索引构建器"""

    def __init__(self, rag_dir: str = "./rag", output_dir: str = "./data"):
        self.rag_dir = Path(rag_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 加载processed chunks
        chunks_path = self.rag_dir / "processed_chunks.json"
        with open(chunks_path, 'r', encoding='utf-8') as f:
            self.data = json.load(f)

        # 初始化jieba
        if JIEBA_AVAILABLE:
            self._init_jieba_dict()

    def _init_jieba_dict(self):
        """初始化jieba数学词典"""
        math_terms = [
            "一元二次方程", "判别式", "韦达定理", "配方法", "公式法",
            "因式分解", "直接开平方", "求根公式", "根与系数",
            "两根之和", "两根之积", "完全平方式", "增长率",
            "二次项系数", "一次项系数", "常数项", "抛物线",
            "对称轴", "顶点坐标", "实数根", "整数根",
            "根的个数", "根的符号", "根的分布"
        ]
        for term in math_terms:
            jieba.add_word(term, freq=1000)

        print(f"✅ 加载数学词典: {len(math_terms)}个专业术语")

    def tokenize(self, text: str) -> List[str]:
        """分词"""
        if JIEBA_AVAILABLE:
            # 使用jieba分词
            words = jieba.lcut(text)
            # 过滤停用词和标点
            stopwords = {'的', '了', '是', '在', '有', '和', '就', '都', '而',
                        '及', '与', '或', '等', '为', '以', '从', '把', '被',
                        ',', '。', '!', '?', '、', '；', '：', '"', '"', ''', '''}
            words = [w for w in words if w not in stopwords and len(w) > 1]
            return words
        else:
            # 改进的中文分词: 按字切分 + 提取英文和数学符号
            # 1. 提取中文字符(单字)
            chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)

            # 2. 提取英文单词
            english_words = re.findall(r'[a-zA-Z]+', text)

            # 3. 提取数字和数学符号
            math_symbols = re.findall(r'[0-9²³±×÷√Δ]+', text)

            # 4. 过滤停用词
            stopwords = {'的', '了', '是', '在', '有', '和', '就', '都', '而',
                        '及', '与', '或', '等', '为', '以', '从', '把', '被'}
            chinese_chars = [c for c in chinese_chars if c not in stopwords]

            # 合并所有token
            all_tokens = chinese_chars + english_words + math_symbols

            return all_tokens

    def build_bm25_index(self):
        """构建BM25索引"""
        print("=" * 60)
        print("开始构建BM25关键词索引")
        print("=" * 60)

        chunks = self.data['chunks']
        total = len(chunks)

        print(f"\n总共{total}个chunks,开始分词...")

        # 准备文档
        corpus = []
        chunk_ids = []

        for i, chunk in enumerate(chunks):
            # 准备文本(title + content + keywords)
            text_parts = [
                chunk['title'],
                chunk['content'],
                ' '.join(chunk['metadata']['keywords'])  # 关键词权重↑
            ]
            text = '\n'.join(text_parts)

            # 分词
            tokens = self.tokenize(text)
            corpus.append(tokens)
            chunk_ids.append(chunk['chunk_id'])

            if (i + 1) % 5 == 0 or i == total - 1:
                print(f"  分词进度: {i+1}/{total}")

        # 构建BM25索引
        print("\n构建BM25索引...")
        if not BM25_AVAILABLE:
            print("❌ rank_bm25未安装,无法构建索引")
            return None

        bm25 = BM25Okapi(corpus)

        # 保存索引
        index_data = {
            'bm25': bm25,
            'chunk_ids': chunk_ids,
            'corpus': corpus
        }

        index_path = self.output_dir / "bm25_index.pkl"
        with open(index_path, 'wb') as f:
            pickle.dump(index_data, f)

        print(f"\n✅ BM25索引已保存: {index_path}")
        print(f"📊 统计:")
        print(f"  - 文档数: {len(chunk_ids)}")
        print(f"  - 平均词数: {sum(len(doc) for doc in corpus) / len(corpus):.1f}")

        return index_data

    def test_search(self, query: str, top_k: int = 5):
        """测试BM25检索"""
        print("\n" + "=" * 60)
        print(f"测试查询: {query}")
        print("=" * 60)

        # 加载索引
        index_path = self.output_dir / "bm25_index.pkl"
        if not index_path.exists():
            print("❌ BM25索引不存在,请先构建")
            return

        with open(index_path, 'rb') as f:
            index_data = pickle.load(f)

        bm25 = index_data['bm25']
        chunk_ids = index_data['chunk_ids']

        # 查询分词
        query_tokens = self.tokenize(query)
        print(f"\n查询分词: {' | '.join(query_tokens)}")

        # BM25打分
        scores = bm25.get_scores(query_tokens)

        # 获取top_k
        top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]

        print(f"\nTop {top_k} 结果:\n")
        for rank, idx in enumerate(top_indices):
            chunk_id = chunk_ids[idx]
            score = scores[idx]

            # 获取chunk详情
            chunk = next(c for c in self.data['chunks'] if c['chunk_id'] == chunk_id)

            print(f"{rank+1}. [{chunk['metadata']['type']}] {chunk['title']}")
            print(f"   BM25得分: {score:.4f}")
            print(f"   难度: {chunk['metadata']['difficulty']}")
            print(f"   关键词: {', '.join(chunk['metadata']['keywords'][:5])}")
            print(f"   内容预览: {chunk['content'][:80]}...")
            print()

    def compare_with_vector(self, query: str):
        """对比向量检索和关键词检索"""
        print("\n" + "=" * 60)
        print(f"对比测试: {query}")
        print("=" * 60)

        # BM25检索
        print("\n【关键词检索(BM25)】")
        self.test_search(query, top_k=3)

        # 向量检索(需要已构建)
        try:
            import chromadb
            from openai import OpenAI
            from dotenv import load_dotenv
            import os

            load_dotenv()

            client = OpenAI(
                api_key=os.getenv("UIUIAPI_KEY"),
                base_url=os.getenv("UIUIAPI_BASE_URL"),
                timeout=60.0
            )

            chroma_client = chromadb.PersistentClient(path=str(self.output_dir / "chroma_db"))
            collection = chroma_client.get_collection("math_rag")

            # 生成query embedding
            response = client.embeddings.create(
                model="text-embedding-3-small",
                input=query
            )
            query_embedding = response.data[0].embedding

            # 搜索
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=3,
                include=["metadatas", "distances"]
            )

            print("\n【向量检索(Semantic)】")
            for i, (metadata, distance) in enumerate(zip(
                results['metadatas'][0],
                results['distances'][0]
            )):
                print(f"{i+1}. [{metadata['type']}] {metadata['title']}")
                print(f"   相似度: {1 - distance:.4f}")
                print(f"   难度: {metadata['difficulty']}")
                print()

        except Exception as e:
            print(f"\n⚠️  向量检索失败: {e}")


def main():
    """主函数"""
    # 检查依赖
    if not BM25_AVAILABLE:
        print("❌ 请先安装: pip install rank_bm25")
        print("提示: jieba是可选的,未安装会使用简单分词")
        return

    # 创建索引器
    indexer = BM25Indexer()

    # 构建索引
    indexer.build_bm25_index()

    # 测试查询
    test_queries = [
        "判别式公式",
        "韦达定理的应用",
        "配方法步骤",
        "增长率问题",
        "如何判断根的个数"
    ]

    for query in test_queries:
        indexer.test_search(query, top_k=3)

    # 对比测试
    print("\n" + "=" * 60)
    print("向量检索 vs 关键词检索 对比")
    print("=" * 60)

    comparison_queries = [
        "判别式是什么?",
        "配方法的具体步骤"
    ]

    for query in comparison_queries:
        indexer.compare_with_vector(query)

    print("\n" + "=" * 60)
    print("Phase 3 完成! BM25索引已构建")
    print("=" * 60)


if __name__ == "__main__":
    main()
