"""
RAG文档分块与索引构建脚本

功能:
1. 读取RAG markdown文件
2. 根据metadata.json进行智能分块
3. 提取关键词(可选jieba分词,未安装则使用简单规则)
4. 生成结构化JSON数据用于:
   - 向量检索(Embedding)
   - 关键词检索(BM25)
   - 混合检索

依赖(可选):
pip install jieba
"""

import os
import json
import re
from typing import List, Dict, Any
from pathlib import Path
from collections import Counter

# 尝试导入jieba,如果失败则使用简单规则
try:
    import jieba
    import jieba.analyse
    JIEBA_AVAILABLE = True
except ImportError:
    JIEBA_AVAILABLE = False
    print("⚠️  jieba未安装,将使用简单规则提取关键词")


class RAGDocumentProcessor:
    """RAG文档处理器"""

    def __init__(self, rag_dir: str = "./rag"):
        self.rag_dir = Path(rag_dir)
        self.metadata_path = self.rag_dir / "metadata.json"
        self.output_path = self.rag_dir / "processed_chunks.json"

        # 加载元数据
        with open(self.metadata_path, 'r', encoding='utf-8') as f:
            self.metadata = json.load(f)

        # 添加数学领域自定义词典
        self._init_jieba_dict()

    def _init_jieba_dict(self):
        """初始化jieba数学词典"""
        if not JIEBA_AVAILABLE:
            return

        math_terms = [
            "一元二次方程", "判别式", "韦达定理", "配方法", "公式法",
            "因式分解", "直接开平方", "求根公式", "根与系数",
            "两根之和", "两根之积", "完全平方式", "增长率",
            "二次项系数", "一次项系数", "常数项", "抛物线",
            "对称轴", "顶点坐标", "实数根", "整数根"
        ]
        for term in math_terms:
            jieba.add_word(term, freq=1000)

        # 加载公式索引
        for formula in self.metadata['global_metadata']['formula_index']:
            jieba.add_word(formula, freq=800)

    def read_markdown_file(self, filename: str) -> str:
        """读取markdown文件"""
        file_path = self.rag_dir / filename
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()

    def extract_chunk_content(self, content: str, start_line: int, end_line: int) -> str:
        """提取指定行范围的内容"""
        lines = content.split('\n')
        # 注意: markdown行号从1开始,python索引从0开始
        chunk_lines = lines[start_line-1:end_line]

        # 合并内容并清理多余换行
        chunk_content = '\n'.join(chunk_lines).strip()

        # 清理连续多个换行符,保留段落间的单个换行
        chunk_content = re.sub(r'\n{3,}', '\n\n', chunk_content)

        return chunk_content

    def extract_keywords(self, text: str, topK: int = 10) -> List[str]:
        """提取关键词"""
        if JIEBA_AVAILABLE:
            # 使用jieba的TF-IDF算法
            keywords = jieba.analyse.extract_tags(text, topK=topK, withWeight=False)
            return keywords
        else:
            # 简单规则: 提取数学关键词
            math_keywords = [
                "一元二次方程", "判别式", "韦达定理", "配方法", "公式法",
                "因式分解", "直接开平方", "求根公式", "根与系数",
                "两根之和", "两根之积", "完全平方式", "增长率",
                "二次项系数", "一次项系数", "常数项", "实数根", "整数根",
                "抛物线", "对称轴", "顶点", "解方程", "化简", "移项"
            ]

            # 统计关键词出现次数
            found_keywords = []
            text_lower = text.lower()
            for keyword in math_keywords:
                if keyword in text:
                    found_keywords.append(keyword)

            return found_keywords[:topK]

    def extract_formulas(self, text: str) -> List[str]:
        """提取数学公式"""
        # 改进规则: 包含数学符号但过滤表格和步骤描述
        formula_pattern = r'[x²xy\+\-\=\(\)√Δ±]+'
        formulas = []

        for line in text.split('\n'):
            line = line.strip()

            # 过滤表格边框和步骤描述
            if '│' in line or '─' in line or '┼' in line:
                continue
            if line.startswith('Step') or line.startswith('情况') or line.startswith('例题'):
                continue

            # 检查是否包含数学符号且长度合理
            if re.search(formula_pattern, line) and 5 <= len(line) < 100:
                # 清理markdown标记
                clean_line = re.sub(r'[#\*`]', '', line).strip()

                # 再次检查清理后的内容是否有效
                if clean_line and re.search(formula_pattern, clean_line):
                    formulas.append(clean_line)

        return list(set(formulas))[:5]  # 去重并限制数量

    def process_all_documents(self) -> List[Dict[str, Any]]:
        """处理所有文档,生成结构化chunks"""
        all_chunks = []

        for doc_meta in self.metadata['documents']:
            filename = doc_meta['filename']
            print(f"处理文档: {filename}")

            # 读取文件内容
            content = self.read_markdown_file(filename)

            # 处理每个chunk
            for chunk_meta in doc_meta['chunks']:
                # 提取chunk内容
                chunk_content = self.extract_chunk_content(
                    content,
                    chunk_meta['line_start'],
                    chunk_meta['line_end']
                )

                # 自动提取关键词(补充元数据中的keywords)
                auto_keywords = self.extract_keywords(chunk_content, topK=15)

                # 合并元数据关键词和自动提取的关键词
                combined_keywords = list(set(
                    chunk_meta.get('keywords', []) + auto_keywords
                ))

                # 提取公式
                formulas = chunk_meta.get('formulas', [])
                if not formulas:
                    formulas = self.extract_formulas(chunk_content)

                # 构建结构化chunk
                processed_chunk = {
                    "chunk_id": chunk_meta['chunk_id'],
                    "source_file": filename,
                    "title": chunk_meta['title'],
                    "content": chunk_content,
                    "metadata": {
                        "type": chunk_meta['type'],
                        "difficulty": chunk_meta['difficulty'],
                        "keywords": combined_keywords,
                        "topics": chunk_meta.get('topics', []),
                        "formulas": formulas,
                        "related_topics": chunk_meta.get('related_topics', []),
                        "question": chunk_meta.get('question', None),  # FAQ专用
                        "line_range": f"{chunk_meta['line_start']}-{chunk_meta['line_end']}"
                    }
                }

                all_chunks.append(processed_chunk)
                print(f"  ✓ {chunk_meta['chunk_id']}: {len(chunk_content)}字符")

        return all_chunks

    def generate_keyword_index(self, chunks: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """生成关键词倒排索引"""
        keyword_index = {}

        for chunk in chunks:
            chunk_id = chunk['chunk_id']
            keywords = chunk['metadata']['keywords']

            for keyword in keywords:
                if keyword not in keyword_index:
                    keyword_index[keyword] = []
                keyword_index[keyword].append(chunk_id)

        # 按文档频率排序
        keyword_index = {
            k: list(set(v))  # 去重
            for k, v in sorted(keyword_index.items(), key=lambda x: len(x[1]), reverse=True)
        }

        return keyword_index

    def generate_formula_index(self, chunks: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """生成公式索引"""
        formula_index = {}

        for chunk in chunks:
            chunk_id = chunk['chunk_id']
            formulas = chunk['metadata']['formulas']

            for formula in formulas:
                if formula not in formula_index:
                    formula_index[formula] = []
                formula_index[formula].append(chunk_id)

        return formula_index

    def save_processed_data(self, chunks: List[Dict[str, Any]]):
        """保存处理后的数据"""
        # 生成索引
        keyword_index = self.generate_keyword_index(chunks)
        formula_index = self.generate_formula_index(chunks)

        output_data = {
            "chunks": chunks,
            "indexes": {
                "keyword_index": keyword_index,
                "formula_index": formula_index
            },
            "statistics": {
                "total_chunks": len(chunks),
                "total_keywords": len(keyword_index),
                "total_formulas": len(formula_index),
                "chunks_by_type": self._count_by_field(chunks, 'type'),
                "chunks_by_difficulty": self._count_by_field(chunks, 'difficulty')
            }
        }

        # 保存为JSON
        with open(self.output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)

        print(f"\n✅ 数据已保存到: {self.output_path}")
        print(f"📊 统计信息:")
        print(f"  - 总chunks: {len(chunks)}")
        print(f"  - 总关键词: {len(keyword_index)}")
        print(f"  - 总公式: {len(formula_index)}")

    def _count_by_field(self, chunks: List[Dict], field: str) -> Dict[str, int]:
        """统计某字段的分布"""
        counts = {}
        for chunk in chunks:
            value = chunk['metadata'].get(field, 'unknown')
            counts[value] = counts.get(value, 0) + 1
        return counts

    def run(self):
        """执行完整处理流程"""
        print("=" * 60)
        print("RAG文档处理开始")
        print("=" * 60)

        # 处理文档
        chunks = self.process_all_documents()

        # 保存数据
        self.save_processed_data(chunks)

        print("=" * 60)
        print("处理完成!")
        print("=" * 60)


def main():
    """主函数"""
    # 获取当前脚本所在目录
    script_dir = Path(__file__).parent
    rag_dir = script_dir.parent / "rag"

    # 创建处理器
    processor = RAGDocumentProcessor(rag_dir=str(rag_dir))

    # 运行处理
    processor.run()


if __name__ == "__main__":
    main()
