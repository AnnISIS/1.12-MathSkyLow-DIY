import aiosqlite
from app.core.config import settings


async def init_db():
    """初始化数据库表"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        # 创建 users 表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        """)

        # 创建 videos 表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS videos (
                id TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                filepath TEXT NOT NULL,
                duration REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'processing'
            )
        """)

        # 创建 nodes 表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS nodes (
                id TEXT PRIMARY KEY,
                video_id TEXT NOT NULL,
                order_num INTEGER NOT NULL,
                start_time REAL NOT NULL,
                end_time REAL NOT NULL,
                title TEXT,
                summary TEXT,
                FOREIGN KEY (video_id) REFERENCES videos(id)
            )
        """)

        # 为节点化RAG添加新字段（增量添加，兼容旧表）
        try:
            # 添加 key_concepts 字段（JSON格式存储关键概念列表）
            await db.execute("""
                ALTER TABLE nodes ADD COLUMN key_concepts TEXT
            """)
        except:
            pass  # 字段已存在

        try:
            # 添加 transcript 字段（该节点的完整字幕文本）
            await db.execute("""
                ALTER TABLE nodes ADD COLUMN transcript TEXT
            """)
        except:
            pass

        try:
            # 添加 embedding 字段（JSON格式存储1536维向量）
            await db.execute("""
                ALTER TABLE nodes ADD COLUMN embedding TEXT
            """)
        except:
            pass

        try:
            # 添加 created_at 字段
            await db.execute("""
                ALTER TABLE nodes ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            """)
        except:
            pass

        # 创建 subtitles 表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS subtitles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT NOT NULL,
                text TEXT,
                start_time REAL,
                end_time REAL,
                FOREIGN KEY (video_id) REFERENCES videos(id)
            )
        """)

        # 创建学习记录表（记录每次观看会话）
        await db.execute("""
            CREATE TABLE IF NOT EXISTS learning_sessions (
                id TEXT PRIMARY KEY,
                student_id TEXT NOT NULL,
                video_id TEXT NOT NULL,
                start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                end_time TIMESTAMP,
                watch_duration REAL DEFAULT 0,
                completion_rate REAL DEFAULT 0,
                FOREIGN KEY (video_id) REFERENCES videos(id)
            )
        """)

        # 创建提问记录表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS question_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                video_id TEXT NOT NULL,
                question_text TEXT NOT NULL,
                question_time REAL,
                question_type TEXT,
                answer_text TEXT,
                confidence_score REAL,
                rag_enabled BOOLEAN DEFAULT 1,
                is_relevant BOOLEAN DEFAULT 1,
                satisfaction_rating INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES learning_sessions(id),
                FOREIGN KEY (video_id) REFERENCES videos(id)
            )
        """)

        # 创建节点交互记录表（记录学生点击/跳转到哪些知识点）
        await db.execute("""
            CREATE TABLE IF NOT EXISTS node_interactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                video_id TEXT NOT NULL,
                node_id TEXT NOT NULL,
                interaction_type TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES learning_sessions(id),
                FOREIGN KEY (node_id) REFERENCES nodes(id)
            )
        """)

        # 创建学生画像表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS student_profiles (
                student_id TEXT PRIMARY KEY,
                total_watch_time REAL DEFAULT 0,
                total_questions INTEGER DEFAULT 0,
                total_sessions INTEGER DEFAULT 0,
                avg_completion_rate REAL DEFAULT 0,
                weak_concepts TEXT,
                learning_preferences TEXT,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # 创建知识点掌握度表
        await db.execute("""
            CREATE TABLE IF NOT EXISTS concept_mastery (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT NOT NULL,
                concept_name TEXT NOT NULL,
                mastery_level REAL DEFAULT 0,
                question_count INTEGER DEFAULT 0,
                correct_count INTEGER DEFAULT 0,
                last_reviewed TIMESTAMP,
                FOREIGN KEY (student_id) REFERENCES student_profiles(student_id),
                UNIQUE(student_id, concept_name)
            )
        """)

        await db.commit()
        print("✅ 数据库初始化完成")


async def get_db():
    """获取数据库连接（依赖注入用）"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        yield db
