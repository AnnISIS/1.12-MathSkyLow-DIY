"""
学习报告API路由
"""
from fastapi import APIRouter, HTTPException
from typing import Dict

from app.services.report_generator import ReportGenerator
from app.services.profile_analyzer import ProfileAnalyzer

router = APIRouter()


@router.get("/reports/video/{video_id}")
async def get_video_report(video_id: str) -> Dict:
    """
    获取视频学习报告

    Returns:
        {
            "video_id": "...",
            "total_views": 150,
            "avg_completion_rate": 0.75,
            "total_questions": 320,
            "avg_satisfaction": 4.3,
            "question_heatmap": [...],
            "question_wordcloud": [...]
        }
    """
    try:
        report = await ReportGenerator.generate_video_report(video_id)
        if not report:
            raise HTTPException(status_code=404, detail="视频报告生成失败")
        return report
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/reports/student/{student_id}")
async def get_student_report(student_id: str) -> Dict:
    """
    获取学生学习报告

    Returns:
        {
            "student_id": "...",
            "total_watch_time": 3600,
            "total_sessions": 25,
            "total_questions": 80,
            "weak_concepts": ["配方法", "因式分解"],
            "mastery_distribution": {...}
        }
    """
    try:
        report = await ReportGenerator.generate_student_report(student_id)
        if not report:
            raise HTTPException(status_code=404, detail="学生报告生成失败")
        return report
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/reports/video/{video_id}/heatmap")
async def get_question_heatmap(video_id: str):
    """获取提问热力图数据"""
    try:
        heatmap = await ReportGenerator.get_question_heatmap(video_id)
        return {"heatmap": heatmap}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/reports/video/{video_id}/wordcloud")
async def get_question_wordcloud(video_id: str):
    """获取问题词云数据"""
    try:
        wordcloud = await ReportGenerator.get_question_wordcloud(video_id)
        return {"wordcloud": wordcloud}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/profile/update/{student_id}")
async def update_student_profile(student_id: str):
    """手动触发更新学生画像"""
    try:
        await ProfileAnalyzer.update_profile(student_id)
        return {"message": "学生画像更新成功", "student_id": student_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
