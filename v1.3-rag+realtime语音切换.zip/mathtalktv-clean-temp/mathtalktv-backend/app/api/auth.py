from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, validator
import hashlib
import jwt
from datetime import datetime, timedelta
import re
import uuid
import aiosqlite

from app.core.config import settings

router = APIRouter()

# JWT配置
SECRET_KEY = "mathtalk-secret-key-change-in-production"  # 生产环境应从环境变量读取
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7天


class RegisterRequest(BaseModel):
    username: str
    password: str

    @validator('username')
    def validate_username(cls, v):
        if len(v) < 3:
            raise ValueError('用户名长度至少为3位')
        if len(v) > 20:
            raise ValueError('用户名长度最多20位')
        return v

    @validator('password')
    def validate_password(cls, v):
        if len(v) < 6:
            raise ValueError('密码长度至少为6位')
        return v


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    token: str
    user_id: str
    username: str


def hash_password(password: str) -> str:
    """简单的密码加密（使用SHA256）"""
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """验证密码"""
    return hash_password(plain_password) == hashed_password


def create_access_token(data: dict) -> str:
    """生成JWT token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def is_email(username: str) -> bool:
    """判断是否为邮箱"""
    return '@' in username


@router.post("/api/auth/register", response_model=LoginResponse)
async def register(req: RegisterRequest):
    """用户注册"""
    try:
        async with aiosqlite.connect(settings.DB_PATH) as db:
            # 检查用户名是否已存在
            cursor = await db.execute(
                "SELECT id FROM users WHERE username = ?",
                (req.username,)
            )
            existing_user = await cursor.fetchone()
            if existing_user:
                raise HTTPException(status_code=400, detail="该用户名已被注册")

            # 创建新用户
            user_id = str(uuid.uuid4())
            password_hash = hash_password(req.password)

            await db.execute(
                """
                INSERT INTO users (id, username, password_hash)
                VALUES (?, ?, ?)
                """,
                (user_id, req.username, password_hash)
            )
            await db.commit()

            # 生成token
            token = create_access_token({"user_id": user_id})

            print(f"✅ 用户注册成功: {req.username}, user_id: {user_id}")

            return LoginResponse(
                token=token,
                user_id=user_id,
                username=req.username
            )

    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ 注册失败: {e}")
        raise HTTPException(status_code=500, detail="注册失败，请稍后重试")


@router.post("/api/auth/login", response_model=LoginResponse)
async def login(req: LoginRequest):
    """用户登录"""
    try:
        async with aiosqlite.connect(settings.DB_PATH) as db:
            db.row_factory = aiosqlite.Row

            # 查找用户
            cursor = await db.execute(
                "SELECT id, username, password_hash, is_active FROM users WHERE username = ?",
                (req.username,)
            )

            user = await cursor.fetchone()

            # 验证用户和密码
            if not user:
                raise HTTPException(status_code=401, detail="用户名或密码错误")

            if not verify_password(req.password, user['password_hash']):
                raise HTTPException(status_code=401, detail="用户名或密码错误")

            if not user['is_active']:
                raise HTTPException(status_code=403, detail="账号已被禁用")

            # 生成token
            token = create_access_token({"user_id": user['id']})

            print(f"✅ 用户登录成功: {req.username}")

            return LoginResponse(
                token=token,
                user_id=user['id'],
                username=req.username
            )

    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ 登录失败: {e}")
        raise HTTPException(status_code=500, detail="登录失败，请稍后重试")


@router.get("/api/auth/me")
async def get_current_user(token: str):
    """获取当前用户信息"""
    try:
        # 验证token
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")

        if not user_id:
            raise HTTPException(status_code=401, detail="无效的token")

        # 查找用户
        async with aiosqlite.connect(settings.DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT id, phone, email, created_at FROM users WHERE id = ?",
                (user_id,)
            )
            user = await cursor.fetchone()

            if not user:
                raise HTTPException(status_code=404, detail="用户不存在")

            return {
                "user_id": user['id'],
                "phone": user['phone'],
                "email": user['email'],
                "created_at": user['created_at']
            }

    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="token已过期")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="无效的token")
    except Exception as e:
        print(f"❌ 获取用户信息失败: {e}")
        raise HTTPException(status_code=500, detail="获取用户信息失败")
