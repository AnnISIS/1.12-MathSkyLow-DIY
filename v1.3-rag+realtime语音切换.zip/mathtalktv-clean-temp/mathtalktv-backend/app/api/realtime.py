"""
OpenAI Realtime API 会话管理
用于前端直接连接 OpenAI Realtime WebSocket
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional
import httpx
import logging
import os

from app.core.config import settings

router = APIRouter()
logger = logging.getLogger(__name__)


class RealtimeSessionRequest(BaseModel):
    """创建 Realtime Session 的请求"""
    video_context: Optional[str] = None
    video_id: Optional[str] = None
    current_time: Optional[float] = None


@router.post("/realtime/session")
async def create_realtime_session(request: RealtimeSessionRequest) -> Dict[str, Any]:
    """
    创建 OpenAI Realtime Session 并返回 client_secret

    前端使用 client_secret 直接连接 WebSocket
    """
    try:
        # 构建系统提示词
        instructions = """你是一个超会讲数学的温柔老师，正在帮初中生答疑。学生暂停了视频来问你问题。

## 角色设定
- 你像学长/学姐一样温柔贴心，说话要像朋友聊天一样自然
- 语气轻松活泼，可以用"哈哈"、"嘿"、"对吧"、"是不是"这样的口语
- 解释概念时用最简单直白的大白话
- 多用生活中的例子，比如游戏、零花钱、身高这些学生熟悉的东西

## 回答原则
1. 只回答学生问的问题，别扯远了
2. 说话别太长，30秒内说完（100-150字左右）
3. 回答完后随意问一句，比如"懂了不？要继续看视频吗？"

## 语音表达规范
说话时用自然语言，让学生容易听懂：
- 说"x的平方"而不是"x^2"
- 说"根号x"而不是"√x"
- 说"a不等于零"而不是"a≠0"
"""

        # 如果有视频上下文，添加到提示词
        if request.video_context:
            instructions += f"\n\n## 学生刚才听到的内容（当前时间前30秒）\n{request.video_context}\n\n注意：这是学生实际听到的内容，回答'刚才'相关问题时只参考这部分。"

        # 配置代理（如果需要）
        proxies = None
        if os.getenv("HTTP_PROXY") or os.getenv("HTTPS_PROXY"):
            proxies = {
                "http://": os.getenv("HTTP_PROXY"),
                "https://": os.getenv("HTTPS_PROXY"),
            }
            logger.info(f"[Realtime API] 使用代理: {proxies}")

        # 调用 OpenAI API 创建 session
        async with httpx.AsyncClient(proxies=proxies, timeout=30.0) as client:
            response = await client.post(
                "https://api.openai.com/v1/realtime/sessions",
                headers={
                    "Authorization": f"Bearer {settings.OPENAI_API_KEY}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "gpt-4o-realtime-preview-2024-12-17",
                    "modalities": ["text", "audio"],
                    "voice": "alloy",
                    "instructions": instructions,
                    "input_audio_format": "pcm16",
                    "output_audio_format": "pcm16",
                    "input_audio_transcription": {
                        "model": "whisper-1",
                        "language": "zh"
                    },
                    "turn_detection": {
                        "type": "server_vad",
                        "threshold": 0.3,  # 降低阈值，更容易检测到语音
                        "prefix_padding_ms": 500,  # 增加前置填充
                        "silence_duration_ms": 800  # 增加静音持续时间
                    }
                }
            )

            if response.status_code != 200:
                error_text = response.text
                logger.error(f"[Realtime API] Session 创建失败: {error_text}")
                raise HTTPException(
                    status_code=response.status_code,
                    detail=f"Failed to create Realtime session: {error_text}"
                )

            data = response.json()
            logger.info(f"[Realtime API] Session 创建成功")

            # 提取 client_secret
            client_secret = data.get("client_secret")
            if isinstance(client_secret, dict):
                client_secret = client_secret.get("value")

            return {
                "client_secret": client_secret,
                "expires_at": data.get("expires_at")
            }

    except httpx.HTTPError as e:
        logger.error(f"[Realtime API] HTTP 错误: {e}")
        raise HTTPException(status_code=500, detail=f"Network error: {str(e)}")
    except Exception as e:
        logger.error(f"[Realtime API] 创建 session 失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))
