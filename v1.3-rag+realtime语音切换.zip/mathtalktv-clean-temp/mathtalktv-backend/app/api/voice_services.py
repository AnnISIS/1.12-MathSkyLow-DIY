"""
语音服务管理API
用于查询和切换不同的语音服务提供商
"""
from fastapi import APIRouter, HTTPException
from typing import Dict, Any, List
from pydantic import BaseModel

from app.services.voice_service_factory import VoiceServiceFactory
from app.services.voice_service_base import VoiceServiceType

router = APIRouter()


class VoiceServiceSwitchRequest(BaseModel):
    """切换语音服务请求"""
    service_type: str  # xfyun, openai_realtime, doubao, aliyun_ice, tencent_rag


@router.get("/voice-services")
async def get_voice_services() -> Dict[str, Any]:
    """
    获取所有可用的语音服务列表

    Returns:
        {
            "current": "xfyun",
            "services": [
                {
                    "id": "xfyun",
                    "name": "讯飞ASR+TTS",
                    "type": "pipeline",
                    "capabilities": {...},
                    "available": true
                },
                ...
            ]
        }
    """
    try:
        services = VoiceServiceFactory.get_available_services()
        current = VoiceServiceFactory.get_default_service_type().value

        return {
            "current": current,
            "services": services
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取语音服务列表失败: {str(e)}")


@router.post("/voice-services/switch")
async def switch_voice_service(request: VoiceServiceSwitchRequest) -> Dict[str, Any]:
    """
    切换语音服务（注意：这是全局设置，会影响所有会话）

    Args:
        request: 包含service_type的请求体

    Returns:
        {
            "success": true,
            "service_type": "openai_realtime",
            "message": "已切换到OpenAI Realtime"
        }
    """
    try:
        # 验证服务类型
        try:
            service_type = VoiceServiceType(request.service_type)
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"不支持的语音服务类型: {request.service_type}"
            )

        # 尝试创建服务实例（验证配置是否正确）
        try:
            service = VoiceServiceFactory.create_service(service_type)
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail=f"无法创建语音服务实例，请检查配置: {str(e)}"
            )

        # 更新全局配置（注意：这只在当前进程生效）
        from app.core.config import settings
        settings.DEFAULT_VOICE_SERVICE = request.service_type

        service_name = VoiceServiceFactory._get_service_display_name(service_type)

        return {
            "success": True,
            "service_type": request.service_type,
            "message": f"已切换到 {service_name}"
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"切换语音服务失败: {str(e)}")


@router.get("/voice-services/{service_type}/capabilities")
async def get_service_capabilities(service_type: str) -> Dict[str, Any]:
    """
    获取指定语音服务的能力详情

    Args:
        service_type: 服务类型ID

    Returns:
        {
            "id": "xfyun",
            "name": "讯飞ASR+TTS",
            "capabilities": {
                "streaming_asr": true,
                "streaming_tts": true,
                "end_to_end": false,
                "rag_integration": false,
                "emotion_control": true
            }
        }
    """
    try:
        # 验证服务类型
        try:
            service_enum = VoiceServiceType(service_type)
        except ValueError:
            raise HTTPException(
                status_code=404,
                detail=f"不支持的语音服务类型: {service_type}"
            )

        # 创建服务实例并获取能力
        service = VoiceServiceFactory.create_service(service_enum)
        capabilities = service.get_capabilities()
        service_name = VoiceServiceFactory._get_service_display_name(service_enum)

        return {
            "id": service_type,
            "name": service_name,
            "capabilities": capabilities
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取服务能力失败: {str(e)}")
