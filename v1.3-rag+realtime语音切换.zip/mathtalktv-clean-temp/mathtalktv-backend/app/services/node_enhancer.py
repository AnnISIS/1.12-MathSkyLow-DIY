"""
节点内容增强服务
使用GPT-4为视频节点生成：title, summary, keyConcepts
"""
import json
import logging
from typing import List, Dict
from openai import AsyncOpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)


class NodeEnhancer:
    """节点内容增强器"""

    def __init__(self):
        self.client = AsyncOpenAI(
            api_key=settings.UIUIAPI_KEY,
            base_url=settings.UIUIAPI_BASE_URL
        )

    async def enhance_node(self, node_transcript: str) -> Dict[str, any]:
        """
        为单个节点生成增强内容

        Args:
            node_transcript: 节点的字幕文本

        Returns:
            {
                "title": "节点标题（10字以内）",
                "summary": "内容摘要（50-100字）",
                "keyConcepts": ["关键概念1", "关键概念2", ...]
            }
        """
        prompt = self._build_enhancement_prompt(node_transcript)

        try:
            response = await self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "你是一个数学教学内容分析专家。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,  # 较低温度保证一致性
                response_format={"type": "json_object"}
            )

            result = json.loads(response.choices[0].message.content)

            logger.info(f"✅ 节点内容增强完成: {result.get('title', 'N/A')}")

            return result

        except Exception as e:
            logger.error(f"❌ 节点内容增强失败: {e}")
            # 返回默认值
            return {
                "title": "未命名节点",
                "summary": node_transcript[:100] if len(node_transcript) > 100 else node_transcript,
                "keyConcepts": []
            }

    async def enhance_nodes_batch(self, nodes_data: List[Dict]) -> List[Dict]:
        """
        批量增强多个节点

        Args:
            nodes_data: 节点列表，每个包含 {id, transcript}

        Returns:
            增强后的节点列表，每个包含 {id, title, summary, keyConcepts}
        """
        enhanced_nodes = []

        for node in nodes_data:
            node_id = node.get("id")
            transcript = node.get("transcript", "")

            if not transcript:
                logger.warning(f"⚠️ 节点 {node_id} 没有字幕内容，跳过")
                continue

            logger.info(f"🔄 正在增强节点: {node_id}")

            enhanced_content = await self.enhance_node(transcript)

            enhanced_nodes.append({
                "id": node_id,
                "title": enhanced_content["title"],
                "summary": enhanced_content["summary"],
                "keyConcepts": enhanced_content["keyConcepts"]
            })

        logger.info(f"✅ 批量增强完成: {len(enhanced_nodes)}/{len(nodes_data)} 个节点")

        return enhanced_nodes

    def _build_enhancement_prompt(self, node_transcript: str) -> str:
        """构建节点增强的Prompt"""
        return f"""你是一个数学教学内容分析专家。请分析以下知识点节点的字幕内容，生成结构化的摘要信息。

节点字幕：
{node_transcript}

请输出 JSON 格式：
{{
  "title": "简洁的节点标题（10字以内）",
  "summary": "节点内容摘要（50-100字），包含讲了什么、重点是什么",
  "keyConcepts": ["关键概念1", "关键概念2", ...] // 3-6个关键词
}}

要求：
1. title 要简洁明了，能让学生快速理解这部分讲什么
2. summary 要概括核心内容，便于后续检索匹配
3. keyConcepts 提取数学术语和关键词，用于精确匹配

示例输出：
{{
  "title": "配方法的基本步骤",
  "summary": "详细讲解配方法的四个步骤：移常数项、二次项系数化为1、加减一次项系数一半的平方、化为完全平方式。通过例题演示完整过程。",
  "keyConcepts": ["配方法", "完全平方式", "配方步骤", "一次项系数"]
}}

请仅返回JSON，不要有其他文字。"""


async def generate_node_transcript(video_id: str, node_id: str, start_time: float, end_time: float) -> str:
    """
    从subtitles表中提取节点对应的字幕文本

    Args:
        video_id: 视频ID
        node_id: 节点ID
        start_time: 节点开始时间（秒）
        end_time: 节点结束时间（秒）

    Returns:
        该时间段内的完整字幕文本
    """
    import aiosqlite

    try:
        async with aiosqlite.connect(settings.DB_PATH) as db:
            cursor = await db.execute(
                """
                SELECT text FROM subtitles
                WHERE video_id = ?
                  AND start_time >= ?
                  AND end_time <= ?
                ORDER BY start_time
                """,
                (video_id, start_time, end_time)
            )
            rows = await cursor.fetchall()

            if rows:
                transcript = " ".join([row[0] for row in rows])
                logger.info(f"✅ 提取节点字幕: {node_id}, {len(rows)}段, {len(transcript)}字")
                return transcript
            else:
                logger.warning(f"⚠️ 节点 {node_id} 没有找到字幕")
                return ""

    except Exception as e:
        logger.error(f"❌ 提取节点字幕失败: {e}")
        return ""
