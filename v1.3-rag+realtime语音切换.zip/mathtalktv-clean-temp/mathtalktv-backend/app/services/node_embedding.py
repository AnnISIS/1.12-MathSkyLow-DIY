"""
节点Embedding生成服务
为视频节点生成向量表示，用于语义检索
"""
import json
import logging
from typing import List
from openai import AsyncOpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)


class NodeEmbeddingService:
    """节点Embedding生成器"""

    def __init__(self):
        self.client = AsyncOpenAI(
            api_key=settings.UIUIAPI_KEY,
            base_url=settings.UIUIAPI_BASE_URL
        )
        self.model = "text-embedding-3-small"  # 使用小模型，更快更便宜
        self.dimensions = 1536  # 输出维度

    async def generate_node_embedding(
        self,
        summary: str,
        key_concepts: List[str]
    ) -> List[float]:
        """
        为单个节点生成embedding

        Args:
            summary: 节点摘要
            key_concepts: 关键概念列表

        Returns:
            1536维向量
        """
        # 组合摘要和关键概念作为embedding输入
        # 格式: "摘要内容。关键词：概念1、概念2、概念3"
        text_to_embed = f"{summary}。关键词：{'、'.join(key_concepts)}"

        try:
            response = await self.client.embeddings.create(
                model=self.model,
                input=text_to_embed
            )

            embedding = response.data[0].embedding

            logger.info(f"✅ 生成embedding: {len(embedding)}维")

            return embedding

        except Exception as e:
            logger.error(f"❌ 生成embedding失败: {e}")
            # 返回零向量作为fallback
            return [0.0] * self.dimensions

    async def generate_embeddings_batch(
        self,
        nodes_data: List[dict]
    ) -> List[dict]:
        """
        批量生成多个节点的embedding

        Args:
            nodes_data: 节点列表，每个包含 {id, summary, keyConcepts}

        Returns:
            带有embedding的节点列表
        """
        results = []

        for node in nodes_data:
            node_id = node.get("id")
            summary = node.get("summary", "")
            key_concepts = node.get("keyConcepts", [])

            if not summary:
                logger.warning(f"⚠️ 节点 {node_id} 没有摘要，跳过")
                continue

            logger.info(f"🔄 正在生成embedding: {node_id}")

            embedding = await self.generate_node_embedding(summary, key_concepts)

            results.append({
                "id": node_id,
                "embedding": embedding
            })

        logger.info(f"✅ 批量生成embedding完成: {len(results)}/{len(nodes_data)} 个节点")

        return results

    async def generate_query_embedding(self, query: str) -> List[float]:
        """
        为用户查询生成embedding

        Args:
            query: 用户问题

        Returns:
            1536维向量
        """
        try:
            response = await self.client.embeddings.create(
                model=self.model,
                input=query
            )

            return response.data[0].embedding

        except Exception as e:
            logger.error(f"❌ 生成查询embedding失败: {e}")
            return [0.0] * self.dimensions


def embedding_to_json(embedding: List[float]) -> str:
    """将embedding向量转换为JSON字符串（用于存储到SQLite）"""
    return json.dumps(embedding)


def json_to_embedding(json_str: str) -> List[float]:
    """从JSON字符串恢复embedding向量"""
    try:
        return json.loads(json_str)
    except:
        return [0.0] * 1536
