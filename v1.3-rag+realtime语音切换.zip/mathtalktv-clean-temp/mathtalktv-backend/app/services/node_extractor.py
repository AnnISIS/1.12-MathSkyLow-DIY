"""
AI节点识别服务：从字幕中识别知识点节点
"""
import uuid
import json
import aiosqlite
from typing import List
from openai import AsyncOpenAI

from app.core.config import settings
from app.models.schemas import Subtitle, Node


class NodeExtractor:
    """节点提取器"""

    def __init__(self):
        # 根据配置选择LLM提供商
        if settings.LLM_PROVIDER == "uiuiapi":
            self.client = AsyncOpenAI(
                api_key=settings.UIUIAPI_KEY,
                base_url=settings.UIUIAPI_BASE_URL
            )
            self.model = "gpt-4o-mini"  # uiuiapi支持的模型
        elif settings.LLM_PROVIDER == "deepseek":
            self.client = AsyncOpenAI(
                api_key=settings.DEEPSEEK_API_KEY,
                base_url="https://api.deepseek.com/v1"
            )
            self.model = "deepseek-chat"
        else:
            raise ValueError(f"不支持的LLM提供商: {settings.LLM_PROVIDER}")

    def build_prompt(self, subtitles: List[Subtitle]) -> str:
        """构建节点识别的Prompt"""
        # 将字幕格式化为文本
        subtitle_text = ""
        for i, sub in enumerate(subtitles):
            subtitle_text += f"[{sub.start_time:.1f}s - {sub.end_time:.1f}s] {sub.text}\n"

        prompt = f"""你是一位初中数学教学专家。现在给你一个数学教学视频的完整字幕（带时间戳），请识别出知识点节点的边界。

## 字幕内容
{subtitle_text}

## 任务
1. 识别每个独立知识点的开始和结束时间
2. 为每个节点起标题（5-10字）
3. 总结节点核心内容（30-50字）

## 输出格式（JSON数组）
```json
[
  {{
    "order": 1,
    "start_time": 0.0,
    "end_time": 120.5,
    "title": "引入：什么是一元二次方程",
    "summary": "从实际问题引入一元二次方程的定义，解释各项的含义"
  }},
  ...
]
```

## 要求
- 每个节点时长建议1-3分钟
- 节点边界应在教师讲解段落的自然停顿处
- 标题要体现知识点名称
- 只输出JSON，不要其他文字说明

请开始识别："""

        return prompt

    async def extract_nodes(self, subtitles: List[Subtitle]) -> List[Node]:
        """
        使用LLM从字幕中提取节点

        Returns:
            节点列表
        """
        if not subtitles:
            print("⚠️ 字幕为空，无法提取节点")
            return []

        try:
            print(f"🤖 正在使用 {settings.LLM_PROVIDER} 识别知识点节点...")

            # 构建prompt
            prompt = self.build_prompt(subtitles)

            # 调用LLM
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "你是一位专业的初中数学教学专家，擅长分析教学视频内容。"
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.3,  # 降低随机性，提高准确性
                max_tokens=2000
            )

            # 解析返回的JSON
            content = response.choices[0].message.content.strip()

            # 尝试提取JSON（有时LLM会加```json```包裹）
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                content = content.split("```")[1].split("```")[0].strip()

            nodes_data = json.loads(content)

            # 转换为Node对象
            nodes = []
            for data in nodes_data:
                node = Node(
                    id=str(uuid.uuid4()),
                    order_num=data["order"],
                    start_time=float(data["start_time"]),
                    end_time=float(data["end_time"]),
                    title=data["title"],
                    summary=data["summary"]
                )
                nodes.append(node)

            print(f"✅ 成功识别 {len(nodes)} 个知识点节点")
            return nodes

        except json.JSONDecodeError as e:
            print(f"❌ JSON解析失败: {e}")
            print(f"LLM返回内容: {content}")
            raise Exception("节点识别失败：LLM返回格式错误")

        except Exception as e:
            print(f"❌ 节点识别失败: {str(e)}")
            raise e

    async def save_nodes_to_db(self, video_id: str, nodes: List[Node]) -> None:
        """保存节点到数据库并生成embedding"""
        from app.services.rag_retriever import RAGRetriever

        rag_retriever = RAGRetriever()

        async with aiosqlite.connect(settings.DB_PATH) as db:
            for node in nodes:
                # 生成embedding
                embedding_text = f"{node.title}\n{node.summary}\n{node.transcript[:500] if node.transcript else ''}"
                embedding = await rag_retriever.get_embedding(embedding_text)
                embedding_json = json.dumps(embedding) if embedding else None

                await db.execute("""
                    INSERT INTO nodes (id, video_id, order_num, start_time, end_time, title, summary, embedding)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    node.id,
                    video_id,
                    node.order_num,
                    node.start_time,
                    node.end_time,
                    node.title,
                    node.summary,
                    embedding_json
                ))

            # 更新视频状态为ready（有节点）
            await db.execute(
                "UPDATE videos SET status = 'ready' WHERE id = ?",
                (video_id,)
            )

            await db.commit()
            print(f"✅ 节点已保存到数据库(含embedding): {video_id}")

    async def process_video_nodes(self, video_id: str) -> List[Node]:
        """
        为指定视频处理节点识别

        Returns:
            识别出的节点列表
        """
        # 1. 从数据库获取字幕
        async with aiosqlite.connect(settings.DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT * FROM subtitles WHERE video_id = ? ORDER BY start_time",
                (video_id,)
            )
            rows = await cursor.fetchall()

            if not rows:
                raise Exception("未找到字幕数据")

            subtitles = [
                Subtitle(
                    text=row["text"],
                    start_time=row["start_time"],
                    end_time=row["end_time"]
                )
                for row in rows
            ]

        # 2. 提取节点
        nodes = await self.extract_nodes(subtitles)

        # 3. 保存到数据库
        if nodes:
            await self.save_nodes_to_db(video_id, nodes)

        return nodes
