"""
报告生成服务 (ReportGenerator)
生成可视化学习报告
"""
import logging
from typing import Dict, List, Optional
from collections import Counter
import aiosqlite
import json

from app.core.config import settings

logger = logging.getLogger(__name__)


class ReportGenerator:
    """学习报告生成服务"""

    @staticmethod
    async def generate_video_report(video_id: str) -> Dict:
        """
        生成单个视频的学习报告

        Args:
            video_id: 视频ID

        Returns:
            视频报告字典
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 基本统计
                cursor = await db.execute("""
                    SELECT
                        COUNT(DISTINCT student_id) as total_views,
                        AVG(completion_rate) as avg_completion_rate,
                        SUM(watch_duration) as total_watch_time
                    FROM learning_sessions
                    WHERE video_id = ?
                """, (video_id,))
                basic_stats = await cursor.fetchone()

                # 提问统计
                cursor = await db.execute("""
                    SELECT COUNT(*) as total_questions
                    FROM question_records
                    WHERE video_id = ?
                """, (video_id,))
                question_stats = await cursor.fetchone()

                # 满意度统计
                satisfaction_stats = await ReportGenerator.get_satisfaction_stats(video_id)

                # 提问热力图数据
                heatmap_data = await ReportGenerator.get_question_heatmap(video_id)

                # 问题词云数据
                wordcloud_data = await ReportGenerator.get_question_wordcloud(video_id)

                report = {
                    "video_id": video_id,
                    "total_views": basic_stats[0] or 0,
                    "avg_completion_rate": round(basic_stats[1] or 0, 3),
                    "total_watch_time": round(basic_stats[2] or 0, 1),
                    "total_questions": question_stats[0] or 0,
                    "avg_satisfaction": satisfaction_stats.get("avg", 0),
                    "satisfaction_distribution": satisfaction_stats.get("distribution", {}),
                    "question_heatmap": heatmap_data,
                    "question_wordcloud": wordcloud_data
                }

                logger.info(f"📊 生成视频报告: {video_id}")
                return report

        except Exception as e:
            logger.error(f"生成视频报告失败: {e}")
            return {}

    @staticmethod
    async def generate_student_report(student_id: str) -> Dict:
        """
        生成学生个人学习报告

        Args:
            student_id: 学生ID

        Returns:
            学生报告字典
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 获取学生画像
                cursor = await db.execute("""
                    SELECT
                        total_watch_time,
                        total_questions,
                        total_sessions,
                        avg_completion_rate,
                        weak_concepts,
                        learning_preferences
                    FROM student_profiles
                    WHERE student_id = ?
                """, (student_id,))
                profile = await cursor.fetchone()

                if not profile:
                    return {
                        "student_id": student_id,
                        "message": "暂无学习数据"
                    }

                # 获取知识点掌握度分布
                cursor = await db.execute("""
                    SELECT concept_name, mastery_level
                    FROM concept_mastery
                    WHERE student_id = ?
                    ORDER BY mastery_level ASC
                    LIMIT 10
                """, (student_id,))
                mastery_data = await cursor.fetchall()

                # 获取最近学习趋势
                cursor = await db.execute("""
                    SELECT
                        DATE(start_time) as date,
                        COUNT(*) as session_count,
                        SUM(watch_duration) as daily_watch_time
                    FROM learning_sessions
                    WHERE student_id = ?
                    GROUP BY DATE(start_time)
                    ORDER BY date DESC
                    LIMIT 30
                """, (student_id,))
                trend_data = await cursor.fetchall()

                report = {
                    "student_id": student_id,
                    "total_watch_time": round(profile[0] or 0, 1),
                    "total_sessions": profile[2] or 0,
                    "total_questions": profile[1] or 0,
                    "avg_completion_rate": round(profile[3] or 0, 3),
                    "weak_concepts": json.loads(profile[4]) if profile[4] else [],
                    "learning_preferences": json.loads(profile[5]) if profile[5] else {},
                    "mastery_distribution": {
                        row[0]: round(row[1], 3) for row in mastery_data
                    },
                    "learning_trend": [
                        {
                            "date": row[0],
                            "sessions": row[1],
                            "watch_time": round(row[2], 1)
                        }
                        for row in trend_data
                    ]
                }

                logger.info(f"📊 生成学生报告: {student_id}")
                return report

        except Exception as e:
            logger.error(f"生成学生报告失败: {e}")
            return {}

    @staticmethod
    async def get_question_heatmap(video_id: str) -> List[Dict]:
        """
        生成提问时间轴热力图数据

        Args:
            video_id: 视频ID

        Returns:
            热力图数据列表 [{time: 120.5, count: 5}, ...]
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 获取所有提问时间点
                cursor = await db.execute("""
                    SELECT question_time
                    FROM question_records
                    WHERE video_id = ? AND question_time IS NOT NULL
                    ORDER BY question_time
                """, (video_id,))
                questions = await cursor.fetchall()

                if not questions:
                    return []

                # 获取视频时长
                cursor = await db.execute("""
                    SELECT duration
                    FROM videos
                    WHERE id = ?
                """, (video_id,))
                video_duration = await cursor.fetchone()
                duration = video_duration[0] if video_duration else 600  # 默认10分钟

                # 将时间分成若干个桶（每30秒一个桶）
                bucket_size = 30
                num_buckets = int(duration / bucket_size) + 1
                buckets = [0] * num_buckets

                for (question_time,) in questions:
                    bucket_index = int(question_time / bucket_size)
                    if bucket_index < num_buckets:
                        buckets[bucket_index] += 1

                # 生成热力图数据
                heatmap = []
                for i, count in enumerate(buckets):
                    heatmap.append({
                        "time": i * bucket_size,
                        "count": count
                    })

                return heatmap

        except Exception as e:
            logger.error(f"生成提问热力图失败: {e}")
            return []

    @staticmethod
    async def get_question_wordcloud(video_id: str) -> List[Dict]:
        """
        生成高频问题词云数据

        Args:
            video_id: 视频ID

        Returns:
            词云数据列表 [{word: "配方法", count: 15}, ...]
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 获取所有问题文本
                cursor = await db.execute("""
                    SELECT question_text
                    FROM question_records
                    WHERE video_id = ?
                """, (video_id,))
                questions = await cursor.fetchall()

                if not questions:
                    return []

                # 简单关键词提取（实际应该使用jieba分词）
                # 这里使用mock示例
                keywords = []
                common_math_terms = [
                    "配方法", "因式分解", "一元二次方程", "函数", "几何", "三角形",
                    "怎么算", "为什么", "公式", "解题", "步骤", "方法"
                ]

                for (question_text,) in questions:
                    for term in common_math_terms:
                        if term in question_text:
                            keywords.append(term)

                # 统计词频
                word_counts = Counter(keywords)

                # 生成词云数据（取前20个）
                wordcloud = [
                    {"word": word, "count": count}
                    for word, count in word_counts.most_common(20)
                ]

                return wordcloud

        except Exception as e:
            logger.error(f"生成问题词云失败: {e}")
            return []

    @staticmethod
    async def get_satisfaction_stats(video_id: str) -> Dict:
        """
        获取满意度统计

        Args:
            video_id: 视频ID

        Returns:
            满意度统计 {avg: 4.2, total: 100, distribution: {5: 60, 4: 30, ...}}
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 获取所有评分
                cursor = await db.execute("""
                    SELECT satisfaction_rating, COUNT(*) as count
                    FROM question_records
                    WHERE video_id = ? AND satisfaction_rating IS NOT NULL
                    GROUP BY satisfaction_rating
                """, (video_id,))
                ratings = await cursor.fetchall()

                if not ratings:
                    return {"avg": 0, "total": 0, "distribution": {}}

                # 计算统计
                total = sum(count for _, count in ratings)
                weighted_sum = sum(rating * count for rating, count in ratings)
                avg_rating = weighted_sum / total if total > 0 else 0

                distribution = {str(rating): count for rating, count in ratings}

                return {
                    "avg": round(avg_rating, 2),
                    "total": total,
                    "distribution": distribution
                }

        except Exception as e:
            logger.error(f"获取满意度统计失败: {e}")
            return {"avg": 0, "total": 0, "distribution": {}}
