"""
问题分类器
用于判断学生提问是简单问题还是复杂问题
简单问题: 交互指令、元问题、导航指令等 (不需要RAG,可使用实时语音)
复杂问题: 数学问题、需要视频内容支持的问题 (需要RAG)
"""
import logging
from typing import Dict, Literal

logger = logging.getLogger(__name__)


class QuestionClassifier:
    """问题分类器"""

    # 简单问题关键词库
    SIMPLE_PATTERNS = {
        "interaction": [
            "慢一点", "慢点", "快一点", "快点",
            "重复", "再说一遍", "再讲一遍", "没听清",
            "停止", "暂停", "停",
            "大声", "小声", "听不清"
        ],
        "meta": [
            "你是谁", "你叫什么", "你的名字",
            "怎么用", "怎么使用", "如何使用",
            "能做什么", "有什么功能", "可以干嘛"
        ],
        "navigation": [
            "跳到", "快进", "回退", "倒退",
            "从头", "重新", "开始",
            "上一题", "下一题", "前一题", "后一题",
            "第几分钟", "跳转"
        ],
        "greeting": [
            "你好", "hi", "hello", "嗨",
            "在吗", "在不在",
            "谢谢", "感谢", "太好了"
        ]
    }

    # 数学问题关键词
    MATH_KEYWORDS = [
        # 疑问词
        "怎么", "为什么", "如何", "什么",
        # 数学动作
        "解", "求", "证明", "计算", "化简", "推导",
        # 题目相关
        "答案", "题", "例题", "练习", "作业",
        # 数学概念
        "公式", "定理", "方法", "步骤", "过程",
        "函数", "方程", "图形", "角", "边", "面积", "体积",
        "因式", "配方", "展开", "合并", "约分"
    ]

    @classmethod
    def classify(cls, question: str) -> Dict:
        """
        分类问题

        Args:
            question: 用户提问

        Returns:
            {
                "type": "simple" | "complex",
                "category": "interaction" | "meta" | "navigation" | "greeting" | "math" | "unknown",
                "use_rag": bool,
                "use_realtime": bool,  # 是否适合实时语音
                "confidence": float  # 分类置信度 0-1
            }
        """
        q = question.strip().lower()

        # 1. 超短问题 (<5字) → 简单
        if len(q) < 5:
            return {
                "type": "simple",
                "category": "interaction",
                "use_rag": False,
                "use_realtime": True,
                "confidence": 0.9
            }

        # 2. 简单问题关键词匹配
        for category, keywords in cls.SIMPLE_PATTERNS.items():
            for keyword in keywords:
                if keyword in q:
                    logger.info(f"🏷️ 分类为简单问题 [{category}]: '{question[:20]}...'")
                    return {
                        "type": "simple",
                        "category": category,
                        "use_rag": False,
                        "use_realtime": True,
                        "confidence": 0.95
                    }

        # 3. 数学问题判断
        math_score = 0
        for keyword in cls.MATH_KEYWORDS:
            if keyword in q:
                math_score += 1

        if math_score >= 2:
            # 包含2个及以上数学关键词 → 复杂数学问题
            logger.info(f"📐 分类为复杂数学问题 (匹配{math_score}个关键词): '{question[:30]}...'")
            return {
                "type": "complex",
                "category": "math",
                "use_rag": True,
                "use_realtime": False,
                "confidence": min(0.7 + math_score * 0.1, 1.0)
            }

        # 4. 单个数学关键词 → 可能是数学问题
        if math_score == 1:
            logger.info(f"📐 分类为可能的数学问题: '{question[:30]}...'")
            return {
                "type": "complex",
                "category": "math",
                "use_rag": True,
                "use_realtime": False,
                "confidence": 0.6
            }

        # 5. 默认为复杂问题（保守策略，避免漏掉重要问题）
        logger.info(f"❓ 未明确分类，默认为复杂问题: '{question[:30]}...'")
        return {
            "type": "complex",
            "category": "unknown",
            "use_rag": True,
            "use_realtime": False,
            "confidence": 0.5
        }

    @classmethod
    def get_simple_response(cls, question: str, category: str) -> str:
        """
        为简单问题生成预设回答

        Args:
            question: 用户问题
            category: 问题类别

        Returns:
            预设回答文本
        """
        responses = {
            "interaction": {
                "慢": "好的,我会说慢一点。",
                "快": "好的,我会说快一点。",
                "重复": "我再说一遍刚才的内容...",
                "停": "好的,已停止。",
                "大声": "好的,我会大声一点。",
                "小声": "好的,我会小声一点。"
            },
            "meta": {
                "default": "我是你的AI数学老师,可以帮你解答视频中的数学问题。有什么不懂的随时问我!"
            },
            "navigation": {
                "default": "请直接在视频进度条上操作跳转哦~"
            },
            "greeting": {
                "你好": "你好同学!有什么数学问题我可以帮你吗?",
                "谢谢": "不客气!继续加油学习!有问题随时问我~",
                "default": "😊"
            }
        }

        # 尝试匹配具体回答
        if category in responses:
            category_responses = responses[category]
            for key, response in category_responses.items():
                if key in question:
                    return response
            # 返回该类别的默认回答
            return category_responses.get("default", "好的!")

        return "好的!"


# 便捷函数
def classify_question(question: str) -> Dict:
    """
    便捷的问题分类函数

    Args:
        question: 用户问题

    Returns:
        分类结果字典
    """
    return QuestionClassifier.classify(question)


def is_simple_question(question: str) -> bool:
    """
    判断是否为简单问题

    Args:
        question: 用户问题

    Returns:
        True if 简单问题, False otherwise
    """
    result = QuestionClassifier.classify(question)
    return result["type"] == "simple"


def should_use_rag(question: str) -> bool:
    """
    判断是否需要使用RAG

    Args:
        question: 用户问题

    Returns:
        True if 需要RAG, False otherwise
    """
    result = QuestionClassifier.classify(question)
    return result["use_rag"]
