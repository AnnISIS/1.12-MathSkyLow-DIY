"""
学习行为记录服务 (LearningTracker)
实时记录学生的学习行为：会话、提问、节点交互
"""
import logging
import uuid
from datetime import datetime
from typing import Optional
import aiosqlite

from app.core.config import settings

logger = logging.getLogger(__name__)


class LearningTracker:
    """学习行为记录服务"""

    @staticmethod
    async def create_session(student_id: str, video_id: str) -> str:
        """
        创建新的学习会话

        Args:
            student_id: 学生ID
            video_id: 视频ID

        Returns:
            session_id: 会话ID
        """
        session_id = str(uuid.uuid4())

        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                await db.execute("""
                    INSERT INTO learning_sessions
                    (id, student_id, video_id, start_time)
                    VALUES (?, ?, ?, ?)
                """, (session_id, student_id, video_id, datetime.now()))

                await db.commit()
                logger.info(f"✅ 创建学习会话: session_id={session_id}, student={student_id}, video={video_id}")

        except Exception as e:
            logger.error(f"创建会话失败: {e}")
            raise

        return session_id

    @staticmethod
    async def update_session_progress(
        session_id: str,
        current_time: float,
        duration: float
    ) -> None:
        """
        更新会话观看进度

        Args:
            session_id: 会话ID
            current_time: 当前播放时间(秒)
            duration: 视频总时长(秒)
        """
        try:
            # 计算完成率
            completion_rate = min(current_time / duration, 1.0) if duration > 0 else 0.0

            async with aiosqlite.connect(settings.DB_PATH) as db:
                await db.execute("""
                    UPDATE learning_sessions
                    SET watch_duration = ?, completion_rate = ?
                    WHERE id = ?
                """, (current_time, completion_rate, session_id))

                await db.commit()
                logger.debug(f"📊 更新会话进度: session={session_id}, progress={completion_rate:.2%}")

        except Exception as e:
            logger.error(f"更新会话进度失败: {e}")

    @staticmethod
    async def end_session(session_id: str) -> None:
        """
        结束会话，记录结束时间

        Args:
            session_id: 会话ID
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                await db.execute("""
                    UPDATE learning_sessions
                    SET end_time = ?
                    WHERE id = ?
                """, (datetime.now(), session_id))

                await db.commit()
                logger.info(f"🏁 会话结束: session_id={session_id}")

        except Exception as e:
            logger.error(f"结束会话失败: {e}")

    @staticmethod
    async def record_question(
        session_id: str,
        student_id: str,
        video_id: str,
        question_text: str,
        answer_text: str,
        confidence_score: float,
        question_time: Optional[float] = None,
        question_type: str = "voice",
        rag_enabled: bool = True,
        is_relevant: bool = True
    ) -> int:
        """
        记录提问

        Args:
            session_id: 会话ID
            student_id: 学生ID
            video_id: 视频ID
            question_text: 问题内容
            answer_text: AI回答内容
            confidence_score: RAG置信度分数
            question_time: 提问时的视频时间点(秒)
            question_type: 问题类型 (voice/text)
            rag_enabled: 是否启用RAG
            is_relevant: 是否相关问题

        Returns:
            question_id: 问题记录ID
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                cursor = await db.execute("""
                    INSERT INTO question_records
                    (session_id, student_id, video_id, question_text, answer_text,
                     confidence_score, question_time, question_type, rag_enabled, is_relevant)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    session_id, student_id, video_id, question_text, answer_text,
                    confidence_score, question_time, question_type, rag_enabled, is_relevant
                ))

                await db.commit()
                question_id = cursor.lastrowid

                logger.info(f"❓ 记录提问: id={question_id}, type={question_type}, "
                           f"confidence={confidence_score:.3f}, relevant={is_relevant}")

                return question_id

        except Exception as e:
            logger.error(f"记录提问失败: {e}")
            return -1

    @staticmethod
    async def record_node_interaction(
        session_id: str,
        student_id: str,
        video_id: str,
        node_id: str,
        interaction_type: str = "click"
    ) -> None:
        """
        记录节点交互

        Args:
            session_id: 会话ID
            student_id: 学生ID
            video_id: 视频ID
            node_id: 节点ID
            interaction_type: 交互类型 (click/hover/jump)
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                await db.execute("""
                    INSERT INTO node_interactions
                    (session_id, student_id, video_id, node_id, interaction_type)
                    VALUES (?, ?, ?, ?, ?)
                """, (session_id, student_id, video_id, node_id, interaction_type))

                await db.commit()
                logger.debug(f"🔘 记录节点交互: node={node_id}, type={interaction_type}")

        except Exception as e:
            logger.error(f"记录节点交互失败: {e}")

    @staticmethod
    async def record_satisfaction(question_id: int, rating: int) -> None:
        """
        记录满意度评分

        Args:
            question_id: 问题记录ID
            rating: 评分 (1-5)
        """
        try:
            if not 1 <= rating <= 5:
                logger.warning(f"无效的评分: {rating}")
                return

            async with aiosqlite.connect(settings.DB_PATH) as db:
                await db.execute("""
                    UPDATE question_records
                    SET satisfaction_rating = ?
                    WHERE id = ?
                """, (rating, question_id))

                await db.commit()
                logger.info(f"⭐ 记录满意度评分: question={question_id}, rating={rating}")

        except Exception as e:
            logger.error(f"记录满意度评分失败: {e}")
