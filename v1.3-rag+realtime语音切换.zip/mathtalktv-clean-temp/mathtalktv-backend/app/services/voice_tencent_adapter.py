"""
腾讯云语音服务适配器 + RAG中间件
ASR识别后，在调用LLM前精准注入RAG内容，速度更快
"""
import asyncio
import json
import logging
from typing import AsyncGenerator, Optional, Dict, Any, Callable
import time
import hmac
import hashlib
import base64
from urllib.parse import urlencode, quote
import uuid

from app.services.voice_service_base import VoiceServiceBase, VoiceServiceType

logger = logging.getLogger(__name__)


class TencentRAGService(VoiceServiceBase):
    """
    腾讯云ASR+TTS + 自研RAG中间件
    特点：在ASR识别文字后、LLM生成前，精准检索并注入RAG
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.service_type = VoiceServiceType.TENCENT_RAG
        self.secret_id = config.get("secret_id")
        self.secret_key = config.get("secret_key")
        self.app_id = config.get("app_id")

        # 腾讯云ASR WebSocket endpoint
        self.asr_endpoint = f"wss://asr.cloud.tencent.com/asr/v2/{self.app_id}"

    def _generate_signature(self, params: Dict[str, Any]) -> str:
        """
        生成腾讯云ASR签名
        文档: https://cloud.tencent.com/document/product/1093/35637

        签名原文格式: asr.cloud.tencent.com/asr/v2/{appid}?{sorted_params}
        注意：不需要加HTTP方法前缀
        """
        # 1. 对参数进行字典序排序（按key排序）
        sorted_params = sorted(params.items(), key=lambda x: x[0])

        # 2. 构建查询字符串
        query_parts = []
        for key, value in sorted_params:
            query_parts.append(f"{key}={value}")
        query_string = "&".join(query_parts)

        # 3. 拼接签名原文
        signature_base = f"asr.cloud.tencent.com/asr/v2/{self.app_id}?{query_string}"

        logger.info(f"[Tencent] 签名原文: {signature_base}")

        # 4. 使用 HMAC-SHA1 加密
        signature = hmac.new(
            self.secret_key.encode('utf-8'),
            signature_base.encode('utf-8'),
            hashlib.sha1
        ).digest()

        # 5. Base64 编码
        signature_b64 = base64.b64encode(signature).decode('utf-8')

        logger.info(f"[Tencent] 生成签名: {signature_b64}")

        return signature_b64

    async def process_conversation(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        context: Dict[str, Any],
        on_asr_result: Optional[Callable[[str, bool], None]] = None,
        on_llm_response: Optional[Callable[[str], None]] = None,
        on_tts_chunk: Optional[Callable[[bytes], None]] = None,
    ) -> Dict[str, Any]:
        """
        处理对话流程：ASR -> RAG中间件 -> LLM -> TTS
        """
        logger.info(f"[Tencent] 开始处理语音对话")

        # 1. ASR识别用户语音
        user_text = await self.speech_to_text(audio_stream, on_asr_result)
        logger.info(f"[Tencent ASR] 识别结果: {user_text}")

        # 2. 调用外部LLM生成回答（从context传入）
        from app.services.llm_factory import generate_completion

        messages = [
            {"role": "system", "content": context.get("system_prompt", "")},
        ]
        for turn in context.get("conversation_history", []):
            messages.append({"role": "user", "content": turn["user"]})
            messages.append({"role": "assistant", "content": turn["assistant"]})
        messages.append({"role": "user", "content": user_text})

        result = await generate_completion(
            messages=messages,
            model=context.get("current_model", "gpt-4o-mini"),
            temperature=0.7,
            max_tokens=500
        )
        assistant_text = result["content"]
        logger.info(f"[Tencent LLM] 回答: {assistant_text[:100]}...")

        if on_llm_response:
            on_llm_response(assistant_text)

        # 3. TTS合成语音
        assistant_audio = await self.text_to_speech(assistant_text)
        logger.info(f"[Tencent TTS] 合成完成: {len(assistant_audio)} 字节")

        if on_tts_chunk:
            on_tts_chunk(assistant_audio)

        return {
            "user_text": user_text,
            "assistant_text": assistant_text,
            "assistant_audio": assistant_audio,
            "metadata": {
                "provider": "tencent",
                "mode": "rag"
            }
        }

    async def text_to_speech(self, text: str, **kwargs) -> bytes:
        """
        腾讯云实时语音合成（WebSocket）
        文档: https://cloud.tencent.com/document/product/1073/34093
        """
        logger.info(f"[Tencent TTS] 合成文本: {text[:50]}...")
        try:
            import websockets
            from urllib.parse import urlencode, quote

            # 清理LaTeX符号
            import re
            text = re.sub(r'\[DRAW:(DESMOS|GEOGEBRA):[^\]]+\]', '', text)
            text = re.sub(r'\$\$[^\$]+\$\$', '公式', text)
            text = text.replace('$', '')

            # 生成请求参数
            timestamp = int(time.time())
            expired = timestamp + 86400  # 24小时有效
            session_id = str(uuid.uuid4())

            params = {
                "Action": "TextToStreamAudioWS",
                "AppId": str(self.app_id),
                "SecretId": self.secret_id,
                "Timestamp": str(timestamp),
                "Expired": str(expired),
                "SessionId": session_id,
                "Text": text,
                "VoiceType": "101001",  # 智瑜（温柔女声）
                "Codec": "pcm",
                "SampleRate": "16000",
                "Volume": "0",
                "Speed": "0",
            }

            # 生成签名（不包含Text）
            sign_params = {k: v for k, v in params.items() if k != "Text"}
            sorted_params = sorted(sign_params.items())
            query_string = urlencode(sorted_params)

            # 签名原文
            signature_base = f"GETtts.cloud.tencent.com/stream_ws?{query_string}"

            # HMAC-SHA1加密
            signature = base64.b64encode(
                hmac.new(
                    self.secret_key.encode('utf-8'),
                    signature_base.encode('utf-8'),
                    hashlib.sha1
                ).digest()
            ).decode('utf-8')

            params["Signature"] = signature

            # URL编码Text参数
            params["Text"] = quote(text.encode('utf-8'))

            # 构建WebSocket URL
            url = f"wss://tts.cloud.tencent.com/stream_ws?{urlencode(params)}"

            logger.info(f"[Tencent TTS] 开始连接WebSocket")

            audio_data = b""

            async with websockets.connect(url) as ws:
                # 握手阶段：等待服务端确认
                response = await ws.recv()
                result = json.loads(response)
                if result.get("code") != 0:
                    raise Exception(f"握手失败: {result.get('message')}")

                logger.info(f"[Tencent TTS] 握手成功")

                # 接收音频数据
                async for message in ws:
                    if isinstance(message, bytes):
                        # 二进制音频数据
                        audio_data += message
                    else:
                        # 文本消息
                        result = json.loads(message)
                        code = result.get("code", 0)

                        if code != 0:
                            error_msg = result.get("message", "Unknown error")
                            logger.error(f"[Tencent TTS] 合成错误: {error_msg}")
                            raise Exception(f"TTS失败: {error_msg}")

                        # 检查是否完成
                        if result.get("final") == 1:
                            logger.info(f"[Tencent TTS] 合成完成")
                            break

            logger.info(f"[Tencent TTS] 合成成功: {len(audio_data)} 字节")
            return audio_data

        except Exception as e:
            logger.error(f"[Tencent TTS] 合成失败: {e}")
            return b""

    async def speech_to_text(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        on_result: Optional[Callable[[str, bool], None]] = None
    ) -> str:
        """
        腾讯云实时语音识别（WebSocket）
        文档: https://cloud.tencent.com/document/product/1093/35637
        """
        logger.info(f"[Tencent ASR] 开始识别")
        try:
            import websockets

            # 生成请求参数
            timestamp = int(time.time())
            expired = timestamp + 86400  # 24小时有效
            nonce = int(time.time() * 1000)
            voice_id = str(uuid.uuid4())

            params = {
                "secretid": self.secret_id,
                "timestamp": str(timestamp),
                "expired": str(expired),
                "nonce": str(nonce),
                "engine_model_type": "16k_zh",  # 16k中文通用
                "voice_id": voice_id,
                "voice_format": "1",  # PCM格式
                "needvad": "1",  # 开启VAD
            }

            # 生成签名（不包含signature参数本身）
            signature = self._generate_signature(params)

            # 将签名添加到参数中（不需要quote，urlencode会自动处理）
            params["signature"] = signature

            # 构建WebSocket URL
            url = f"{self.asr_endpoint}?{urlencode(params)}"

            user_text = ""

            logger.info(f"[Tencent ASR] 开始连接: {self.asr_endpoint}")

            async with websockets.connect(url) as ws:
                # 握手阶段：等待服务端确认
                response = await ws.recv()
                result = json.loads(response)
                if result.get("code") != 0:
                    raise Exception(f"握手失败: {result.get('message')}")

                logger.info(f"[Tencent ASR] 握手成功")

                # 发送音频数据
                send_task = asyncio.create_task(
                    self._send_tencent_audio(ws, audio_stream)
                )

                # 接收识别结果
                try:
                    async for message in ws:
                        result = json.loads(message)
                        code = result.get("code", 0)

                        if code != 0:
                            error_msg = result.get("message", "Unknown error")
                            logger.error(f"[Tencent ASR] 识别错误: {error_msg}")
                            raise Exception(f"ASR失败: {error_msg}")

                        # 检查是否为最终结果
                        if result.get("final") == 1:
                            logger.info(f"[Tencent ASR] 识别完成")
                            break

                        # 获取识别结果
                        result_data = result.get("result", {})
                        slice_type = result_data.get("slice_type", 0)
                        voice_text = result_data.get("voice_text_str", "")

                        if slice_type == 0:
                            # 一段话开始
                            logger.info(f"[Tencent ASR] 开始识别新的一段话")
                        elif slice_type == 1:
                            # 识别中（非稳态）
                            logger.info(f"[Tencent ASR] 中间结果: {voice_text}")
                            if on_result:
                                on_result(voice_text, False)
                        elif slice_type == 2:
                            # 一段话结束（稳态）
                            user_text = voice_text
                            logger.info(f"[Tencent ASR] 稳态结果: {voice_text}")
                            if on_result:
                                on_result(voice_text, True)

                finally:
                    send_task.cancel()
                    try:
                        await send_task
                    except asyncio.CancelledError:
                        pass

            return user_text

        except Exception as e:
            logger.error(f"[Tencent ASR] 识别失败: {type(e).__name__}: {str(e)}")
            import traceback
            logger.error(f"[Tencent ASR] 详细错误: {traceback.format_exc()}")
            raise Exception(f"腾讯云ASR识别失败: {str(e)}")

    async def _send_tencent_audio(self, ws, audio_stream: AsyncGenerator[bytes, None]):
        """发送音频到腾讯云ASR"""
        try:
            # 发送音频数据（二进制）
            async for chunk in audio_stream:
                await ws.send(chunk)
                await asyncio.sleep(0.04)  # 40ms间隔，符合腾讯云要求

            # 发送结束标志（JSON）
            end_msg = {"type": "end"}
            await ws.send(json.dumps(end_msg))
            logger.info(f"[Tencent ASR] 已发送结束标志")

        except asyncio.CancelledError:
            logger.info(f"[Tencent ASR] 音频发送被取消")
        except Exception as e:
            logger.error(f"[Tencent ASR] 音频发送失败: {e}")

    def is_end_to_end(self) -> bool:
        """腾讯云是管道模式"""
        return False

    def get_capabilities(self) -> Dict[str, bool]:
        """获取服务能力"""
        return {
            "streaming_asr": True,
            "streaming_tts": True,  # TTS已完整实现
            "end_to_end": False,
            "rag_integration": True,
            "emotion_control": False,
            "low_latency": True  # 腾讯云延迟最低
        }
