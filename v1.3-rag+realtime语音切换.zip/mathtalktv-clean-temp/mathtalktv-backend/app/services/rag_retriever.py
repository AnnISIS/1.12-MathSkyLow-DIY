"""
RAG检索服务：基于节点的语义检索
支持三种检索模式: vector(向量) / bm25(关键词) / hybrid(混合)
"""
import json
import logging
from typing import List, Tuple, Dict
from openai import AsyncOpenAI
import numpy as np
import aiosqlite
from rank_bm25 import BM25Okapi

from app.core.config import settings

logger = logging.getLogger(__name__)


class RAGRetriever:
    """RAG检索器 - 支持向量/BM25/混合三种检索模式"""

    def __init__(self, mode: str = "vector"):
        """
        初始化检索器

        Args:
            mode: 检索模式 - "vector"(纯向量) / "bm25"(纯BM25) / "hybrid"(混合)
        """
        self.client = AsyncOpenAI(
            api_key=settings.UIUIAPI_KEY,
            base_url=settings.UIUIAPI_BASE_URL
        )
        self.embedding_model = "text-embedding-ada-002"
        self.mode = mode  # 检索模式

        # BM25相关 (延迟初始化)
        self.bm25_index = None
        self.bm25_nodes = []  # 保存节点数据用于BM25检索

    async def get_embedding(self, text: str) -> List[float]:
        """获取文本的embedding向量"""
        try:
            response = await self.client.embeddings.create(
                model=self.embedding_model,
                input=text
            )
            return response.data[0].embedding
        except Exception as e:
            logger.error(f"获取embedding失败: {e}")
            return []

    def cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """计算余弦相似度"""
        if not vec1 or not vec2:
            return 0.0

        vec1_array = np.array(vec1)
        vec2_array = np.array(vec2)

        dot_product = np.dot(vec1_array, vec2_array)
        norm1 = np.linalg.norm(vec1_array)
        norm2 = np.linalg.norm(vec2_array)

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return float(dot_product / (norm1 * norm2))

    def chunk_text(self, text: str, chunk_size: int = 200, overlap: int = 50) -> List[str]:
        """将长文本分块"""
        if len(text) <= chunk_size:
            return [text]

        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]

            # 尽量在句号、问号、感叹号处断开
            if end < len(text):
                for punct in ['。', '！', '？', '.', '!', '?']:
                    last_punct = chunk.rfind(punct)
                    if last_punct > chunk_size // 2:  # 确保块不会太小
                        end = start + last_punct + 1
                        chunk = text[start:end]
                        break

            chunks.append(chunk.strip())
            start = end - overlap  # 重叠部分避免信息丢失

        return chunks

    async def retrieve_relevant_chunks(
        self,
        question: str,
        full_text: str,
        top_k: int = 3
    ) -> List[Tuple[str, float]]:
        """
        检索最相关的文本块

        Args:
            question: 用户问题
            full_text: 完整字幕文本
            top_k: 返回前K个最相关的块

        Returns:
            [(chunk_text, similarity_score), ...]
        """
        logger.info(f"🔍 RAG检索: 问题长度={len(question)}, 文本长度={len(full_text)}")

        # 1. 分块
        chunks = self.chunk_text(full_text, chunk_size=settings.RAG_CHUNK_SIZE)
        logger.info(f"📄 文本分块: {len(chunks)}个块")

        if not chunks:
            return []

        # 2. 获取问题的embedding
        question_embedding = await self.get_embedding(question)
        if not question_embedding:
            logger.warning("⚠️ 问题embedding获取失败，使用简单截取")
            # 降级到简单截取
            return [(full_text[:1000], 0.0)]

        # 3. 获取所有块的embedding并计算相似度
        chunk_scores = []
        for i, chunk in enumerate(chunks):
            chunk_embedding = await self.get_embedding(chunk)
            if chunk_embedding:
                similarity = self.cosine_similarity(question_embedding, chunk_embedding)
                chunk_scores.append((chunk, similarity))
                logger.debug(f"  块{i+1}: 相似度={similarity:.3f}, 长度={len(chunk)}")

        # 4. 按相似度排序并返回top_k
        chunk_scores.sort(key=lambda x: x[1], reverse=True)
        top_chunks = chunk_scores[:top_k]

        logger.info(f"✅ 检索完成: 返回{len(top_chunks)}个相关块")
        for i, (chunk, score) in enumerate(top_chunks):
            logger.info(f"  Top{i+1}: 相似度={score:.3f}, 内容预览={chunk[:50]}...")

        return top_chunks

    async def build_rag_context(
        self,
        question: str,
        full_text: str,
        top_k: int = 3
    ) -> str:
        """
        构建RAG上下文

        Returns:
            格式化的上下文文本
        """
        chunks = await self.retrieve_relevant_chunks(question, full_text, top_k)

        if not chunks:
            return "（暂无相关内容）"

        # 格式化上下文
        context_parts = []
        for i, (chunk, score) in enumerate(chunks, 1):
            context_parts.append(f"[相关片段{i}]（相似度: {score:.2f}）\n{chunk}")

        return "\n\n".join(context_parts)

    # ========== 节点级检索方法（新增） ==========

    async def _build_bm25_index(self, video_id: str):
        """构建BM25索引 (懒加载)"""
        import time
        start_time = time.time()
        logger.info(f"🔨 开始构建BM25索引: video_id={video_id}")

        async with aiosqlite.connect(settings.DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                """
                SELECT id, title, summary, transcript, start_time, end_time,
                       key_concepts, embedding
                FROM nodes
                WHERE video_id = ?
                ORDER BY order_num
                """,
                (video_id,)
            )
            rows = await cursor.fetchall()

        if not rows:
            logger.warning(f"⚠️ 视频 {video_id} 没有节点")
            return

        # 准备语料库
        self.bm25_nodes = []
        tokenized_corpus = []

        for row in rows:
            # 使用title + summary + key_concepts作为检索文本
            key_concepts = json.loads(row["key_concepts"] or "[]")
            search_text = f"{row['title']} {row['summary']} {' '.join(key_concepts)}"

            # 简单分词 (按字符)
            tokens = list(search_text)  # 中文按字符分词

            tokenized_corpus.append(tokens)
            self.bm25_nodes.append({
                "id": row["id"],
                "title": row["title"],
                "summary": row["summary"],
                "transcript": row["transcript"],
                "start_time": row["start_time"],
                "end_time": row["end_time"],
                "embedding": row["embedding"]
            })

        # 构建BM25索引
        self.bm25_index = BM25Okapi(tokenized_corpus)
        build_time = time.time() - start_time
        logger.info(f"✅ BM25索引构建完成: {len(self.bm25_nodes)}个节点, 耗时: {build_time:.2f}秒")

    async def _bm25_search(self, question: str, top_k: int = 3) -> List[Dict]:
        """使用BM25搜索"""
        import time
        start_time = time.time()

        if not self.bm25_index or not self.bm25_nodes:
            logger.warning("⚠️ BM25索引未初始化")
            return []

        logger.info(f"🔤 BM25搜索: {question[:30]}...")

        # 分词
        query_tokens = list(question)  # 中文按字符分词

        # 获取BM25分数
        scores = self.bm25_index.get_scores(query_tokens)

        # 排序并获取top_k
        top_indices = np.argsort(scores)[::-1][:top_k]

        results = []
        for idx in top_indices:
            if scores[idx] > 0:  # 只返回有分数的结果
                node = self.bm25_nodes[idx].copy()
                node["similarity"] = float(scores[idx] / 100)  # 归一化到0-1范围
                node["keyword_bonus"] = 0.0
                results.append(node)
                logger.info(f"  BM25匹配: 「{node['title']}」 分数={scores[idx]:.2f}")

        search_time = time.time() - start_time
        logger.info(f"✅ BM25搜索完成: 返回{len(results)}个节点, 耗时: {search_time:.3f}秒")

        return results

    async def retrieve_relevant_nodes(
        self,
        video_id: str,
        question: str,
        top_k: int = 3
    ) -> List[Dict]:
        """
        基于节点检索最相关的知识点 (支持三种模式)

        Args:
            video_id: 视频ID
            question: 用户问题
            top_k: 返回前K个最相关的节点

        Returns:
            [
                {
                    "id": "node-xxx-1",
                    "title": "配方法的基本步骤",
                    "summary": "...",
                    "transcript": "...",
                    "start_time": 210,
                    "end_time": 380,
                    "similarity": 0.85
                },
                ...
            ]
        """
        logger.info(f"🔍 节点检索 [{self.mode}模式]: video_id={video_id}, question={question[:50]}...")

        # 根据模式选择检索方式
        if self.mode == "bm25":
            # 纯BM25检索
            if not self.bm25_index:
                await self._build_bm25_index(video_id)
            return await self._bm25_search(question, top_k)

        elif self.mode == "hybrid":
            # 混合检索 (0.7向量 + 0.3BM25)
            logger.info(f"⚡ 混合检索模式: 0.7向量 + 0.3BM25")
            if not self.bm25_index:
                await self._build_bm25_index(video_id)

            # 获取向量检索结果
            vector_results = await self._vector_search(video_id, question, top_k=5)  # 多取一些候选

            # 获取BM25结果
            bm25_results = await self._bm25_search(question, top_k=5)

            # 合并结果 (按node_id去重并加权)
            combined_scores = {}

            for node in vector_results:
                node_id = node["id"]
                combined_scores[node_id] = {
                    "node": node,
                    "vector_score": node["similarity"],
                    "bm25_score": 0.0
                }

            for node in bm25_results:
                node_id = node["id"]
                if node_id in combined_scores:
                    combined_scores[node_id]["bm25_score"] = node["similarity"]
                else:
                    combined_scores[node_id] = {
                        "node": node,
                        "vector_score": 0.0,
                        "bm25_score": node["similarity"]
                    }

            # 计算混合分数 (0.7向量 + 0.3BM25)
            final_results = []
            for node_id, data in combined_scores.items():
                hybrid_score = 0.7 * data["vector_score"] + 0.3 * data["bm25_score"]
                node = data["node"]
                node["similarity"] = hybrid_score
                final_results.append(node)
                logger.info(f"  混合: 「{node['title']}」 向量={data['vector_score']:.3f} BM25={data['bm25_score']:.3f} → {hybrid_score:.3f}")

            # 按混合分数排序
            final_results.sort(key=lambda x: x["similarity"], reverse=True)
            logger.info(f"✅ 混合检索完成: 返回{len(final_results[:top_k])}个节点")
            return final_results[:top_k]

        else:
            # 默认: 纯向量检索
            return await self._vector_search(video_id, question, top_k)

    async def _vector_search(self, video_id: str, question: str, top_k: int = 3) -> List[Dict]:
        """纯向量检索 (原逻辑)"""
        import time
        start_time = time.time()

        logger.info(f"🔍 向量搜索: {question[:30]}...")

        # 1. 获取问题的embedding
        question_embedding = await self.get_embedding(question)
        if not question_embedding:
            logger.warning("⚠️ 问题embedding获取失败")
            return []

        # 2. 从数据库读取该视频的所有节点
        async with aiosqlite.connect(settings.DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                """
                SELECT id, title, summary, transcript, start_time, end_time,
                       key_concepts, embedding
                FROM nodes
                WHERE video_id = ?
                  AND embedding IS NOT NULL
                ORDER BY order_num
                """,
                (video_id,)
            )
            rows = await cursor.fetchall()

        if not rows:
            logger.warning(f"⚠️ 视频 {video_id} 没有找到节点或节点未生成embedding")
            return []

        logger.info(f"📦 找到 {len(rows)} 个节点")

        # 3. 计算相似度并排序
        node_scores = []
        for row in rows:
            try:
                node_embedding_str = row["embedding"]
                if not node_embedding_str:
                    continue

                node_embedding = json.loads(node_embedding_str)
                similarity = self.cosine_similarity(question_embedding, node_embedding)

                # 关键词匹配加权
                key_concepts = json.loads(row["key_concepts"] or "[]")
                keyword_bonus = 0.0
                if key_concepts:
                    question_lower = question.lower()
                    matching_keywords = sum(1 for kw in key_concepts if kw.lower() in question_lower)
                    keyword_bonus = matching_keywords * 0.1  # 每个匹配的关键词加0.1

                final_score = similarity + keyword_bonus

                node_scores.append({
                    "id": row["id"],
                    "title": row["title"],
                    "summary": row["summary"],
                    "transcript": row["transcript"],
                    "start_time": row["start_time"],
                    "end_time": row["end_time"],
                    "similarity": final_score,
                    "keyword_bonus": keyword_bonus
                })

                logger.debug(f"  节点: {row['title']}, 相似度={similarity:.3f}, 关键词加权={keyword_bonus:.2f}")

            except Exception as e:
                logger.error(f"处理节点 {row['id']} 时出错: {e}")
                continue

        # 4. 按得分排序并返回top_k
        node_scores.sort(key=lambda x: x["similarity"], reverse=True)
        top_nodes = node_scores[:top_k]

        search_time = time.time() - start_time
        logger.info(f"✅ 向量检索完成: 返回{len(top_nodes)}个相关节点, 耗时: {search_time:.3f}秒")
        for i, node in enumerate(top_nodes, 1):
            logger.info(f"  Top{i}: 「{node['title']}」 相似度={node['similarity']:.3f}")

        return top_nodes

    async def build_node_context(
        self,
        video_id: str,
        question: str,
        top_k: int = 3
    ) -> tuple[str, float]:
        """
        构建基于节点的RAG上下文

        Returns:
            (格式化的上下文文本, 最高相似度分数)
        """
        nodes = await self.retrieve_relevant_nodes(video_id, question, top_k)

        if not nodes:
            return "（暂无相关内容）", 0.0

        # 获取最高相似度作为置信度
        max_similarity = nodes[0]['similarity'] if nodes else 0.0

        # 格式化上下文
        context_parts = []
        for i, node in enumerate(nodes, 1):
            start_time_str = f"{int(node['start_time'] // 60)}:{int(node['start_time'] % 60):02d}"
            end_time_str = f"{int(node['end_time'] // 60)}:{int(node['end_time'] % 60):02d}"

            context_parts.append(
                f"[知识点{i}]「{node['title']}」({start_time_str} - {end_time_str})\n"
                f"摘要: {node['summary']}\n"
                f"完整内容:\n{node['transcript']}\n"
                f"相关度: {node['similarity']:.2f}"
            )

        return "\n\n".join(context_parts), max_similarity
