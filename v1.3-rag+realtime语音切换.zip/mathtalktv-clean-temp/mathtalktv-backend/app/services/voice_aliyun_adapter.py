"""
阿里云语音服务适配器
支持两种模式：
1. 基础模式：阿里云NLS (ASR + TTS) + 自研LLM
2. 智能体模式：阿里云NLS (ASR + TTS) + 通义星尘智能体（支持知识库）
"""
import asyncio
import json
import logging
from typing import AsyncGenerator, Optional, Dict, Any, Callable

from app.services.voice_service_base import VoiceServiceBase, VoiceServiceType

logger = logging.getLogger(__name__)


class AliyunICEService(VoiceServiceBase):
    """阿里云智能语音服务 - 支持基础模式和智能体模式"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.service_type = VoiceServiceType.ALIYUN_ICE
        self.access_key_id = config.get("access_key_id")
        self.access_key_secret = config.get("access_key_secret")
        self.app_key = config.get("app_key")

        # 智能体配置
        self.use_stardust = config.get("use_stardust", False)
        self.agent_id = config.get("agent_id", "")

        # 阿里云NLS endpoint（根据你的配置使用上海区域）
        self.nls_endpoint = "wss://nls-gateway-cn-shanghai.aliyuncs.com/ws/v1"
        # 通义星尘API endpoint
        self.stardust_endpoint = "https://bailian.aliyuncs.com/v1/agent/chat"

    async def process_conversation(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        context: Dict[str, Any],
        on_asr_result: Optional[Callable[[str, bool], None]] = None,
        on_llm_response: Optional[Callable[[str], None]] = None,
        on_tts_chunk: Optional[Callable[[bytes], None]] = None,
    ) -> Dict[str, Any]:
        """
        处理语音对话

        流程：ASR识别 → LLM/智能体 → TTS合成
        """
        logger.info(f"[Aliyun] 开始处理，模式: {'智能体' if self.use_stardust else '基础'}")

        # 1. ASR识别用户语音
        user_text = await self._aliyun_asr(audio_stream, on_asr_result)
        logger.info(f"[Aliyun ASR] 识别结果: {user_text}")

        # 2. 根据模式选择LLM
        if self.use_stardust and self.agent_id:
            # 使用通义星尘智能体（支持知识库）
            logger.info(f"[Aliyun] 调用通义星尘智能体: {self.agent_id}")
            assistant_text = await self._call_stardust_agent(user_text, context)
        else:
            # 使用外部LLM（从context传入）
            logger.info(f"[Aliyun] 使用基础模式，调用外部LLM")
            from app.services.llm_factory import generate_completion

            messages = [
                {"role": "system", "content": context.get("system_prompt", "")},
            ]
            for turn in context.get("conversation_history", []):
                messages.append({"role": "user", "content": turn["user"]})
                messages.append({"role": "assistant", "content": turn["assistant"]})
            messages.append({"role": "user", "content": user_text})

            result = await generate_completion(
                messages=messages,
                model=context.get("current_model", "gpt-4o-mini"),
                temperature=0.7,
                max_tokens=500
            )
            assistant_text = result["content"]

        logger.info(f"[Aliyun LLM] 回答: {assistant_text[:100]}...")

        if on_llm_response:
            on_llm_response(assistant_text)

        # 3. TTS合成语音
        assistant_audio = await self._aliyun_tts(assistant_text, on_tts_chunk)
        logger.info(f"[Aliyun TTS] 合成完成: {len(assistant_audio)} 字节")

        return {
            "user_text": user_text,
            "assistant_text": assistant_text,
            "assistant_audio": assistant_audio,
            "metadata": {
                "provider": "aliyun",
                "mode": "stardust" if self.use_stardust else "basic",
                "agent_id": self.agent_id if self.use_stardust else None
            }
        }

    async def _aliyun_asr(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        on_result: Optional[Callable[[str, bool], None]] = None
    ) -> str:
        """
        阿里云实时语音识别（ASR）
        文档：https://help.aliyun.com/document_detail/84428.html
        """
        try:
            import websockets

            # 生成token
            logger.info(f"[Aliyun ASR] 开始生成Token...")
            token = self._generate_nls_token()
            logger.info(f"[Aliyun ASR] Token生成成功: {token[:20]}...")

            # 构建WebSocket URL（Token作为查询参数）
            url = f"{self.nls_endpoint}?token={token}"

            user_text = ""
            task_id = f"task_{int(asyncio.get_event_loop().time() * 1000)}"

            logger.info(f"[Aliyun ASR] 开始连接WebSocket: {self.nls_endpoint}")

            async with websockets.connect(url) as ws:
                logger.info(f"[Aliyun ASR] WebSocket连接成功")

                # 发送启动参数
                import uuid
                start_msg = {
                    "header": {
                        "message_id": str(uuid.uuid4()),
                        "task_id": task_id,
                        "namespace": "SpeechTranscriber",
                        "name": "StartTranscription",
                        "appkey": self.app_key
                    },
                    "payload": {
                        "format": "pcm",
                        "sample_rate": 16000,
                        "enable_intermediate_result": True,
                        "enable_punctuation_prediction": True,
                        "enable_inverse_text_normalization": True
                    }
                }
                await ws.send(json.dumps(start_msg))
                logger.info(f"[Aliyun ASR] 已发送启动命令")

                # 发送音频
                send_task = asyncio.create_task(
                    self._send_nls_audio(ws, audio_stream, task_id)
                )

                # 接收识别结果
                try:
                    async for message in ws:
                        result = json.loads(message)
                        header = result.get("header", {})
                        name = header.get("name")
                        payload = result.get("payload", {})

                        logger.debug(f"[Aliyun ASR] 收到消息: {name}")

                        if name == "TranscriptionResultChanged":
                            # 中间结果
                            text = payload.get("result", "")
                            logger.info(f"[Aliyun ASR] 中间结果: {text}")
                            if on_result:
                                on_result(text, False)

                        elif name == "SentenceEnd":
                            # 句子结束
                            text = payload.get("result", "")
                            user_text = text
                            logger.info(f"[Aliyun ASR] 句子结束: {text}")
                            if on_result:
                                on_result(text, True)

                        elif name == "TranscriptionCompleted":
                            # 识别完成
                            logger.info(f"[Aliyun ASR] 识别完成")
                            break

                        elif name == "TaskFailed":
                            # 识别失败 - 打印完整payload以便调试
                            logger.error(f"[Aliyun ASR] TaskFailed完整响应: {result}")
                            error_msg = payload.get("message", payload.get("error_message", "Unknown error"))
                            error_code = payload.get("status", payload.get("error_code", "unknown"))
                            logger.error(f"[Aliyun ASR] 识别失败 (code={error_code}): {error_msg}")
                            raise Exception(f"ASR失败({error_code}): {error_msg}")

                finally:
                    send_task.cancel()
                    try:
                        await send_task
                    except asyncio.CancelledError:
                        pass

            return user_text

        except Exception as e:
            logger.error(f"[Aliyun ASR] 识别失败: {type(e).__name__}: {str(e)}")
            import traceback
            logger.error(f"[Aliyun ASR] 详细错误: {traceback.format_exc()}")
            raise Exception(f"阿里云ASR识别失败: {str(e)}")

    async def _send_nls_audio(self, ws, audio_stream: AsyncGenerator[bytes, None], task_id: str):
        """发送音频到阿里云NLS"""
        try:
            async for chunk in audio_stream:
                # 发送二进制音频数据（阿里云NLS直接接收二进制PCM）
                await ws.send(chunk)
                await asyncio.sleep(0.01)  # 控制发送速率

            # 发送停止命令
            import uuid
            stop_msg = {
                "header": {
                    "message_id": str(uuid.uuid4()),
                    "task_id": task_id,
                    "namespace": "SpeechTranscriber",
                    "name": "StopTranscription",
                    "appkey": self.app_key
                },
                "payload": {}
            }
            await ws.send(json.dumps(stop_msg))
            logger.info(f"[Aliyun ASR] 已发送停止命令")

        except asyncio.CancelledError:
            logger.info(f"[Aliyun ASR] 音频发送被取消")
        except Exception as e:
            logger.error(f"[Aliyun ASR] 音频发送失败: {e}")

    async def _call_stardust_agent(self, user_text: str, context: Dict[str, Any]) -> str:
        """
        调用通义星尘智能体API

        Reference: https://help.aliyun.com/document_detail/2712262.html
        """
        try:
            import httpx

            # 构建请求
            request_data = {
                "app_id": self.agent_id,  # 智能体ID（characterId）
                "session_id": context.get("session_id", "default_session"),
                "prompt": user_text,
                "stream": False
            }

            # 生成签名认证
            headers = {
                "Content-Type": "application/json",
                "Authorization": self._generate_bailian_auth()
            }

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.stardust_endpoint,
                    headers=headers,
                    json=request_data,
                    timeout=30.0
                )

                response.raise_for_status()
                result = response.json()

                # 解析响应
                if result.get("success"):
                    data = result.get("data", {})
                    answer = data.get("text", "")

                    # 记录知识库检索信息
                    references = data.get("doc_references", [])
                    if references:
                        logger.info(f"[Aliyun Stardust] 检索到 {len(references)} 个知识片段")

                    return answer
                else:
                    error_msg = result.get("errorMsg", "Unknown error")
                    logger.error(f"[Aliyun Stardust] API错误: {error_msg}")
                    return "抱歉，智能体调用失败，请稍后再试。"

        except Exception as e:
            logger.error(f"[Aliyun Stardust] 调用失败: {e}")
            return "抱歉，智能体暂时无法使用，请稍后再试。"

    async def _aliyun_tts(
        self,
        text: str,
        on_chunk: Optional[Callable[[bytes], None]] = None
    ) -> bytes:
        """
        阿里云语音合成（TTS）
        """
        try:
            import httpx

            # 清理LaTeX
            import re
            text = re.sub(r'\[DRAW:(DESMOS|GEOGEBRA):[^\]]+\]', '', text)
            text = re.sub(r'\$\$[^\$]+\$\$', '公式', text)
            text = text.replace('$', '')

            # 生成token
            token = self._generate_nls_token()

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "https://nls-gateway-cn-shanghai.aliyuncs.com/stream/v1/tts",
                    headers={
                        "Content-Type": "application/json"
                    },
                    json={
                        "appkey": self.app_key,
                        "token": token,
                        "text": text,
                        "format": "pcm",
                        "sample_rate": 16000,
                        "voice": "aixia",  # 艾夏-温柔女声
                        "speech_rate": 0,
                        "pitch_rate": 0,
                        "volume": 50
                    },
                    timeout=30.0
                )

                response.raise_for_status()
                audio_data = response.content

                if on_chunk:
                    on_chunk(audio_data)

                return audio_data

        except Exception as e:
            logger.error(f"[Aliyun TTS] 合成失败: {e}")
            return b""

    def _generate_nls_token(self) -> str:
        """
        生成阿里云NLS Token（通过OpenAPI调用获取）
        参考文档：https://help.aliyun.com/document_detail/450255.html
        """
        try:
            import httpx
            import json
            import time
            import hmac
            import hashlib
            import base64
            from urllib.parse import quote_plus
            import uuid

            # 1. 构建请求参数
            timestamp = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            nonce = str(uuid.uuid4())

            # 公共参数
            params = {
                'AccessKeyId': self.access_key_id,
                'Action': 'CreateToken',
                'Format': 'JSON',
                'RegionId': 'cn-shanghai',
                'SignatureMethod': 'HMAC-SHA1',
                'SignatureNonce': nonce,
                'SignatureVersion': '1.0',
                'Timestamp': timestamp,
                'Version': '2019-02-28'
            }

            # 2. 构造待签名字符串
            sorted_params = sorted(params.items())
            canonicalized_query_string = '&'.join([f"{quote_plus(k)}={quote_plus(str(v))}" for k, v in sorted_params])
            string_to_sign = f"POST&%2F&{quote_plus(canonicalized_query_string)}"

            # 3. 计算签名
            h = hmac.new(
                (self.access_key_secret + '&').encode('utf-8'),
                string_to_sign.encode('utf-8'),
                hashlib.sha1
            )
            signature = base64.b64encode(h.digest()).decode('utf-8')

            # 4. 发送请求
            params['Signature'] = signature

            response = httpx.post(
                'https://nls-meta.cn-shanghai.aliyuncs.com/',
                params=params,
                timeout=10.0
            )

            response.raise_for_status()
            result = response.json()

            if 'Token' in result and 'Id' in result['Token']:
                token = result['Token']['Id']
                expire_time = result['Token']['ExpireTime']
                logger.info(f"[Aliyun Token] 获取成功，过期时间: {expire_time}")
                return token
            else:
                raise Exception(f"Token获取失败: {result}")

        except Exception as e:
            logger.error(f"[Aliyun Token] 获取失败: {e}")
            raise Exception(f"无法获取阿里云Token: {str(e)}")

    def _generate_bailian_auth(self) -> str:
        """生成百炼平台认证header"""
        # 使用AccessKey认证
        import base64
        auth_string = f"{self.access_key_id}:{self.access_key_secret}"
        auth_b64 = base64.b64encode(auth_string.encode('utf-8')).decode('utf-8')
        return f"Basic {auth_b64}"

    async def text_to_speech(self, text: str, **kwargs) -> bytes:
        """文本转语音"""
        return await self._aliyun_tts(text)

    async def speech_to_text(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        on_result: Optional[Callable[[str, bool], None]] = None
    ) -> str:
        """语音转文本"""
        return await self._aliyun_asr(audio_stream, on_result)

    def is_end_to_end(self) -> bool:
        """阿里云是管道模式，不是端到端"""
        return False

    def get_capabilities(self) -> Dict[str, bool]:
        """获取服务能力"""
        return {
            "streaming_asr": True,
            "streaming_tts": True,
            "end_to_end": False,
            "rag_integration": self.use_stardust,  # 智能体模式支持RAG
            "emotion_control": True,
            "knowledge_base": self.use_stardust  # 智能体模式支持知识库
        }
