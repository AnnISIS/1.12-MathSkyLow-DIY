"""
语音服务工厂类 - 统一创建和管理所有语音服务
"""
import logging
from typing import Dict, Any, List

from app.services.voice_service_base import VoiceServiceBase, VoiceServiceType
from app.services.voice_xfyun_adapter import XFYunVoiceService
from app.services.voice_openai_adapter import OpenAIRealtimeService
from app.services.voice_doubao_adapter import DoubaoVoiceService
from app.services.voice_aliyun_adapter import AliyunICEService
from app.services.voice_tencent_adapter import TencentRAGService
from app.core.config import settings

logger = logging.getLogger(__name__)


class VoiceServiceFactory:
    """语音服务工厂类"""

    # 服务映射表
    SERVICE_MAP = {
        VoiceServiceType.XFYUN: XFYunVoiceService,
        VoiceServiceType.OPENAI_REALTIME: OpenAIRealtimeService,
        VoiceServiceType.DOUBAO: DoubaoVoiceService,
        VoiceServiceType.ALIYUN_ICE: AliyunICEService,
        VoiceServiceType.TENCENT_RAG: TencentRAGService,
    }

    @staticmethod
    def create_service(service_type: VoiceServiceType) -> VoiceServiceBase:
        """
        创建语音服务实例

        Args:
            service_type: 服务类型

        Returns:
            VoiceServiceBase实例

        Raises:
            ValueError: 不支持的服务类型
        """
        service_class = VoiceServiceFactory.SERVICE_MAP.get(service_type)

        if not service_class:
            raise ValueError(f"不支持的语音服务类型: {service_type}")

        # 根据不同服务类型构建配置
        config = VoiceServiceFactory._build_config(service_type)

        logger.info(f"[VoiceFactory] 创建语音服务: {service_type}")
        return service_class(config)

    @staticmethod
    def _build_config(service_type: VoiceServiceType) -> Dict[str, Any]:
        """
        根据服务类型构建配置

        Args:
            service_type: 服务类型

        Returns:
            配置字典
        """
        config = {}

        if service_type == VoiceServiceType.XFYUN:
            config = {
                "app_id": settings.XFYUN_APP_ID,
                "api_key": settings.XFYUN_API_KEY,
                "api_secret": settings.XFYUN_API_SECRET,
            }

        elif service_type == VoiceServiceType.OPENAI_REALTIME:
            config = {
                "api_key": getattr(settings, "OPENAI_API_KEY", ""),
                "model": getattr(settings, "OPENAI_REALTIME_MODEL", "gpt-4o-realtime-preview-2024-12-17"),
            }

        elif service_type == VoiceServiceType.DOUBAO:
            config = {
                "api_key": getattr(settings, "DOUBAO_API_KEY", ""),
                "app_id": getattr(settings, "DOUBAO_APP_ID", ""),
                "access_token": getattr(settings, "DOUBAO_ACCESS_TOKEN", ""),
                "model": getattr(settings, "DOUBAO_MODEL", "doubao-realtime-audio"),
            }

        elif service_type == VoiceServiceType.ALIYUN_ICE:
            config = {
                "access_key_id": getattr(settings, "ALIYUN_ACCESS_KEY_ID", ""),
                "access_key_secret": getattr(settings, "ALIYUN_ACCESS_KEY_SECRET", ""),
                "app_key": getattr(settings, "ALIYUN_APP_KEY", ""),
                "knowledge_base_id": getattr(settings, "ALIYUN_KNOWLEDGE_BASE_ID", ""),
                # 智能体配置
                "use_stardust": getattr(settings, "ALIYUN_STARDUST_USE_STARDUST", False),
                "agent_id": getattr(settings, "ALIYUN_STARDUST_AGENT_ID", ""),
            }

        elif service_type == VoiceServiceType.TENCENT_RAG:
            config = {
                "secret_id": getattr(settings, "TENCENT_SECRET_ID", ""),
                "secret_key": getattr(settings, "TENCENT_SECRET_KEY", ""),
                "app_id": getattr(settings, "TENCENT_APP_ID", ""),
            }

        return config

    @staticmethod
    def get_available_services() -> List[Dict[str, Any]]:
        """
        获取所有可用的语音服务列表

        Returns:
            [
                {
                    "id": "xfyun",
                    "name": "讯飞ASR+TTS",
                    "type": "pipeline",
                    "capabilities": {...}
                },
                ...
            ]
        """
        services = []

        for service_type in VoiceServiceType:
            try:
                # 尝试创建服务实例
                service = VoiceServiceFactory.create_service(service_type)
                capabilities = service.get_capabilities()

                services.append({
                    "id": service_type.value,
                    "name": VoiceServiceFactory._get_service_display_name(service_type),
                    "type": "end_to_end" if service.is_end_to_end() else "pipeline",
                    "capabilities": capabilities,
                    "available": True
                })
            except Exception as e:
                logger.warning(f"[VoiceFactory] 服务 {service_type} 不可用: {e}")
                services.append({
                    "id": service_type.value,
                    "name": VoiceServiceFactory._get_service_display_name(service_type),
                    "type": "unknown",
                    "capabilities": {},
                    "available": False,
                    "error": str(e)
                })

        return services

    @staticmethod
    def _get_service_display_name(service_type: VoiceServiceType) -> str:
        """获取服务显示名称"""
        # 检查是否使用星尘智能体
        from app.core.config import settings
        use_stardust = getattr(settings, "ALIYUN_STARDUST_USE_STARDUST", False)

        name_map = {
            VoiceServiceType.XFYUN: "讯飞ASR+TTS",
            VoiceServiceType.OPENAI_REALTIME: "OpenAI Realtime (端到端)",
            VoiceServiceType.DOUBAO: "豆包端到端语音",
            VoiceServiceType.ALIYUN_ICE: "阿里云NLS+通义星尘 (支持知识库)" if use_stardust else "阿里云NLS基础版",
            VoiceServiceType.TENCENT_RAG: "腾讯云ASR+TTS+RAG中间件 (最快)",
        }
        return name_map.get(service_type, service_type.value)

    @staticmethod
    def get_default_service_type() -> VoiceServiceType:
        """
        获取默认语音服务类型

        Returns:
            默认的VoiceServiceType
        """
        default = getattr(settings, "DEFAULT_VOICE_SERVICE", "xfyun")
        try:
            return VoiceServiceType(default)
        except ValueError:
            logger.warning(f"[VoiceFactory] 无效的默认服务 '{default}'，使用讯飞")
            return VoiceServiceType.XFYUN
