"""
讯飞语音服务适配器
封装讯飞ASR+TTS，实现统一接口
"""
import asyncio
import logging
from typing import AsyncGenerator, Optional, Dict, Any, Callable

from app.services.voice_service_base import VoiceServiceBase, VoiceServiceType
from app.services.xfyun_asr import XFYunASR
from app.services.xfyun_tts import XFYunTTS
from app.services.llm_factory import generate_completion

logger = logging.getLogger(__name__)


class XFYunVoiceService(VoiceServiceBase):
    """讯飞语音服务（ASR+TTS管道模式）"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.service_type = VoiceServiceType.XFYUN
        self.asr = XFYunASR()
        self.tts = XFYunTTS()

    async def process_conversation(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        context: Dict[str, Any],
        on_asr_result: Optional[Callable[[str, bool], None]] = None,
        on_llm_response: Optional[Callable[[str], None]] = None,
        on_tts_chunk: Optional[Callable[[bytes], None]] = None,
    ) -> Dict[str, Any]:
        """
        处理完整对话流程（ASR -> LLM -> TTS）

        Args:
            audio_stream: 输入音频流
            context: 对话上下文
                {
                    "system_prompt": str,
                    "conversation_history": List[Dict],
                    "current_model": str
                }
        """
        # 1. ASR识别用户语音
        user_text = ""
        asr_complete = asyncio.Event()

        def on_asr_result_internal(text: str, is_final: bool):
            nonlocal user_text
            user_text += text
            if on_asr_result:
                on_asr_result(text, is_final)
            if is_final:
                asr_complete.set()

        def on_asr_error(error_msg: str):
            logger.error(f"ASR错误: {error_msg}")
            asr_complete.set()

        # 启动ASR
        await self.asr.recognize_stream(
            audio_stream,
            on_result=on_asr_result_internal,
            on_error=on_asr_error
        )

        # 等待ASR完成
        await asr_complete.wait()

        if not user_text:
            raise Exception("未识别到语音内容")

        logger.info(f"[XFYun ASR] 识别结果: {user_text}")

        # 2. 调用LLM生成回答
        messages = [
            {"role": "system", "content": context.get("system_prompt", "")}
        ]

        # 添加历史对话
        for turn in context.get("conversation_history", []):
            messages.append({"role": "user", "content": turn["user"]})
            messages.append({"role": "assistant", "content": turn["assistant"]})

        # 添加当前问题
        messages.append({"role": "user", "content": user_text})

        # 调用LLM
        result = await generate_completion(
            messages=messages,
            model=context.get("current_model", "gpt-4o-mini"),
            temperature=0.7,
            max_tokens=500
        )

        assistant_text = result["content"]
        logger.info(f"[XFYun LLM] 回答: {assistant_text[:100]}...")

        if on_llm_response:
            on_llm_response(assistant_text)

        # 3. TTS合成语音
        assistant_audio = await self.text_to_speech(
            assistant_text,
            voice_name=context.get("voice_name", "aisxping"),
            speed=context.get("speed", 45),
            volume=context.get("volume", 60),
            pitch=context.get("pitch", 55),
            on_chunk=on_tts_chunk
        )

        logger.info(f"[XFYun TTS] 合成完成: {len(assistant_audio)} 字节")

        return {
            "user_text": user_text,
            "assistant_text": assistant_text,
            "assistant_audio": assistant_audio,
            "metadata": {
                "provider": "xfyun",
                "asr_engine": "xfyun_iat",
                "tts_engine": "xfyun_tts",
                "llm_provider": result["provider"],
                "llm_model": result["model"],
                "input_tokens": result["input_tokens"],
                "output_tokens": result["output_tokens"]
            }
        }

    async def text_to_speech(
        self,
        text: str,
        voice_name: str = "aisxping",
        speed: int = 45,
        volume: int = 60,
        pitch: int = 55,
        on_chunk: Optional[Callable[[bytes], None]] = None,
        **kwargs
    ) -> bytes:
        """
        文本转语音

        Args:
            text: 要合成的文本
            voice_name: 发音人
            speed: 语速
            volume: 音量
            pitch: 音高
            on_chunk: 音频块回调
        """
        # 清理LaTeX符号
        import re
        text = re.sub(r'\[DRAW:(DESMOS|GEOGEBRA):[^\]]+\]', '', text)
        text = re.sub(r'\$([a-zA-Z])\$', r'\1', text)
        text = text.replace(r'\neq', '不等于')
        text = text.replace(r'\leq', '小于等于')
        text = text.replace(r'\geq', '大于等于')
        text = re.sub(r'\$\$[^\$]+\$\$', '公式', text)
        text = text.replace('$', '')

        audio_data = b""
        async for chunk in self.tts.synthesize_stream(text, voice_name, speed, volume, pitch):
            audio_data += chunk
            if on_chunk:
                on_chunk(chunk)

        return audio_data

    async def speech_to_text(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        on_result: Optional[Callable[[str, bool], None]] = None
    ) -> str:
        """语音转文本"""
        user_text = ""
        asr_complete = asyncio.Event()

        def on_asr_result_internal(text: str, is_final: bool):
            nonlocal user_text
            user_text += text
            if on_result:
                on_result(text, is_final)
            if is_final:
                asr_complete.set()

        await self.asr.recognize_stream(
            audio_stream,
            on_result=on_asr_result_internal
        )

        await asr_complete.wait()
        return user_text

    def is_end_to_end(self) -> bool:
        """讯飞是管道模式，不是端到端"""
        return False

    def get_capabilities(self) -> Dict[str, bool]:
        """获取服务能力"""
        return {
            "streaming_asr": True,
            "streaming_tts": True,
            "end_to_end": False,
            "rag_integration": False,
            "emotion_control": True  # 支持语速、音高、音量调节
        }
