"""
字节豆包端到端语音服务适配器
支持实时语音对话 - 使用二进制协议
参考文档: https://www.volcengine.com/docs/6561/1594356
"""
import asyncio
import json
import logging
import struct
from typing import AsyncGenerator, Optional, Dict, Any, Callable
from enum import IntEnum

from app.services.voice_service_base import VoiceServiceBase, VoiceServiceType

logger = logging.getLogger(__name__)


class DoubaoMessageType(IntEnum):
    """豆包消息类型"""
    # 客户端发送
    START_SESSION = 100          # 开始会话
    FINISH_SESSION = 102         # 结束会话
    TASK_REQUEST = 200           # 任务请求（音频数据）

    # 服务端返回
    SESSION_STARTED = 101        # 会话已开始
    SESSION_FINISHED = 103       # 会话已结束
    ASR_RESPONSE = 451           # ASR识别结果
    TTS_RESPONSE = 352           # TTS音频数据
    CHAT_RESPONSE = 550          # Chat文本响应


class DoubaoVoiceService(VoiceServiceBase):
    """字节豆包端到端语音服务"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.service_type = VoiceServiceType.DOUBAO
        self.app_id = config.get("app_id")
        self.access_key = config.get("access_token")  # X-Api-Access-Key
        self.app_key = config.get("api_key")  # X-Api-App-Key

        # 豆包实时对话WebSocket endpoint
        self.ws_url = "wss://openspeech.bytedance.com/api/v3/realtime/dialogue"

        # 资源ID（固定值）
        self.resource_id = "volc.speech.dialog"

    async def process_conversation(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        context: Dict[str, Any],
        on_asr_result: Optional[Callable[[str, bool], None]] = None,
        on_llm_response: Optional[Callable[[str], None]] = None,
        on_tts_chunk: Optional[Callable[[bytes], None]] = None,
    ) -> Dict[str, Any]:
        """
        使用豆包端到端API处理语音对话

        协议流程:
        1. 连接WebSocket (带认证headers)
        2. 发送 StartSession (100)
        3. 发送音频数据 TaskRequest (200)
        4. 接收 ASR结果 (451), Chat响应 (550), TTS音频 (352)
        5. 发送 FinishSession (102)
        """
        logger.info(f"[Doubao] 开始处理语音对话")

        try:
            import websockets

            # 构建认证headers
            headers = {
                "X-Api-App-ID": str(self.app_id),
                "X-Api-Access-Key": self.access_key,
                "X-Api-Resource-Id": self.resource_id,
                "X-Api-App-Key": self.app_key,
            }

            user_text = ""
            assistant_text = ""
            assistant_audio = b""

            logger.info(f"[Doubao] 开始连接WebSocket: {self.ws_url}")

            async with websockets.connect(
                self.ws_url,
                extra_headers=headers,
                close_timeout=10,  # 10秒关闭超时
                ping_timeout=20,   # 20秒ping超时
                ping_interval=None  # 禁用自动ping
            ) as ws:
                logger.info(f"[Doubao] WebSocket连接成功")

                # 1. 发送StartSession
                await self._send_start_session(ws, context)

                # 2. 启动音频发送任务
                send_task = asyncio.create_task(
                    self._send_audio_stream(ws, audio_stream)
                )

                # 3. 接收响应（设置超时）
                response_timeout = 30  # 30秒总超时
                start_time = asyncio.get_event_loop().time()

                try:
                    async for message in ws:
                        # 检查超时
                        elapsed = asyncio.get_event_loop().time() - start_time
                        if elapsed > response_timeout:
                            logger.warning(f"[Doubao] 响应超时 ({elapsed:.1f}s)")
                            break

                        if isinstance(message, bytes):
                            # 二进制消息 - 解析协议
                            result = await self._parse_binary_message(message)

                            if result["type"] == DoubaoMessageType.SESSION_STARTED:
                                logger.info(f"[Doubao] 会话已开始")

                            elif result["type"] == DoubaoMessageType.ASR_RESPONSE:
                                # ASR识别结果
                                asr_data = result["data"]
                                text = asr_data.get("text", "")
                                is_final = asr_data.get("is_final", False)

                                logger.info(f"[Doubao ASR] {'最终' if is_final else '中间'}结果: {text}")

                                if is_final:
                                    user_text = text

                                if on_asr_result:
                                    on_asr_result(text, is_final)

                            elif result["type"] == DoubaoMessageType.CHAT_RESPONSE:
                                # Chat文本响应
                                chat_data = result["data"]
                                text = chat_data.get("text", "")
                                assistant_text += text

                                logger.info(f"[Doubao Chat] 文本响应: {text}")

                                if on_llm_response:
                                    on_llm_response(text)

                            elif result["type"] == DoubaoMessageType.TTS_RESPONSE:
                                # TTS音频数据
                                tts_data = result["data"]
                                # 音频可能是base64编码的字符串
                                audio_data = tts_data.get("audio", "")

                                if isinstance(audio_data, str):
                                    # base64解码
                                    import base64
                                    try:
                                        audio_chunk = base64.b64decode(audio_data)
                                    except Exception as e:
                                        logger.error(f"[Doubao TTS] 音频解码失败: {e}")
                                        audio_chunk = b""
                                elif isinstance(audio_data, bytes):
                                    audio_chunk = audio_data
                                else:
                                    logger.warning(f"[Doubao TTS] 未知音频格式: {type(audio_data)}")
                                    audio_chunk = b""

                                if audio_chunk:
                                    assistant_audio += audio_chunk
                                    logger.info(f"[Doubao TTS] 收到音频: {len(audio_chunk)} 字节")

                                    if on_tts_chunk:
                                        on_tts_chunk(audio_chunk)

                            elif result["type"] == DoubaoMessageType.SESSION_FINISHED:
                                logger.info(f"[Doubao] 会话已结束")
                                break

                        else:
                            # 文本消息（可能是错误）
                            logger.warning(f"[Doubao] 收到非预期文本消息: {message}")

                except asyncio.TimeoutError:
                    logger.error(f"[Doubao] 等待响应超时")
                except Exception as e:
                    logger.error(f"[Doubao] 接收消息异常: {type(e).__name__}: {e}")
                finally:
                    # 取消音频发送任务
                    send_task.cancel()
                    try:
                        await send_task
                    except asyncio.CancelledError:
                        pass

                    # 尝试发送FinishSession（忽略错误）
                    try:
                        await asyncio.wait_for(
                            self._send_finish_session(ws),
                            timeout=2.0
                        )
                    except Exception as e:
                        logger.warning(f"[Doubao] 发送FinishSession失败: {e}")

            return {
                "user_text": user_text,
                "assistant_text": assistant_text,
                "assistant_audio": assistant_audio,
                "metadata": {
                    "provider": "doubao",
                    "mode": "end_to_end"
                }
            }

        except Exception as e:
            logger.error(f"[Doubao] 处理失败: {type(e).__name__}: {str(e)}")
            import traceback
            logger.error(f"[Doubao] 详细错误: {traceback.format_exc()}")
            raise Exception(f"豆包处理失败: {str(e)}")

    async def _send_start_session(self, ws, context: Dict[str, Any]):
        """发送StartSession消息 (100)"""
        # 构建StartSession payload
        payload = {
            "app_id": self.app_id,
            "language": "zh-CN",
            "format": "pcm",
            "sample_rate": 16000,
            "bits": 16,
            # Chat配置
            "system_prompt": context.get("system_prompt", "你是一个有帮助的数学老师助手。"),
            "history": context.get("conversation_history", [])[-5:],  # 最近5轮对话
        }

        payload_bytes = json.dumps(payload, ensure_ascii=False).encode('utf-8')

        # 构建二进制消息: [header_size(4)] [version(1)] [type(4)] [sequence(4)] [payload_size(4)] [payload]
        version = 1
        msg_type = DoubaoMessageType.START_SESSION
        sequence = 1
        payload_size = len(payload_bytes)
        header_size = 17  # 4+1+4+4+4

        message = struct.pack(
            '>I B I I I',  # >: big-endian, I: uint32, B: uint8
            header_size,
            version,
            msg_type,
            sequence,
            payload_size
        ) + payload_bytes

        await ws.send(message)
        logger.info(f"[Doubao] 已发送StartSession")

    async def _send_finish_session(self, ws):
        """发送FinishSession消息 (102)"""
        payload = {}
        payload_bytes = json.dumps(payload).encode('utf-8')

        version = 1
        msg_type = DoubaoMessageType.FINISH_SESSION
        sequence = 999
        payload_size = len(payload_bytes)
        header_size = 17

        message = struct.pack(
            '>I B I I I',
            header_size,
            version,
            msg_type,
            sequence,
            payload_size
        ) + payload_bytes

        await ws.send(message)
        logger.info(f"[Doubao] 已发送FinishSession")

    async def _send_audio_stream(self, ws, audio_stream: AsyncGenerator[bytes, None]):
        """发送音频数据 TaskRequest (200)"""
        try:
            import base64

            sequence = 2
            audio_count = 0

            async for audio_chunk in audio_stream:
                audio_count += 1

                # 构建TaskRequest消息
                payload = {
                    "audio": base64.b64encode(audio_chunk).decode('utf-8'),  # 使用base64编码
                    "format": "pcm",
                    "sample_rate": 16000,
                    "bits": 16
                }
                payload_bytes = json.dumps(payload).encode('utf-8')

                version = 1
                msg_type = DoubaoMessageType.TASK_REQUEST
                payload_size = len(payload_bytes)
                header_size = 17

                message = struct.pack(
                    '>I B I I I',
                    header_size,
                    version,
                    msg_type,
                    sequence,
                    payload_size
                ) + payload_bytes

                await ws.send(message)
                logger.debug(f"[Doubao] 发送音频块 #{audio_count}: {len(audio_chunk)} 字节")
                sequence += 1

                # 控制发送速率
                await asyncio.sleep(0.02)  # 20ms

            logger.info(f"[Doubao] 音频发送完成，共 {audio_count} 个块")

        except asyncio.CancelledError:
            logger.info(f"[Doubao] 音频发送被取消")
        except Exception as e:
            logger.error(f"[Doubao] 音频发送失败: {e}")

    async def _parse_binary_message(self, message: bytes) -> Dict[str, Any]:
        """解析二进制消息"""
        try:
            # 解析header: [header_size(4)] [version(1)] [type(4)] [sequence(4)] [payload_size(4)]
            if len(message) < 17:
                raise ValueError(f"消息太短: {len(message)} 字节")

            header_size, version, msg_type, sequence, payload_size = struct.unpack(
                '>I B I I I',
                message[:17]
            )

            # 解析payload
            payload_bytes = message[header_size:header_size + payload_size]

            if payload_bytes:
                payload = json.loads(payload_bytes.decode('utf-8'))
            else:
                payload = {}

            return {
                "type": DoubaoMessageType(msg_type),
                "sequence": sequence,
                "data": payload
            }

        except Exception as e:
            logger.error(f"[Doubao] 解析消息失败: {e}")
            logger.error(f"[Doubao] 消息内容: {message[:100]}...")
            return {
                "type": None,
                "sequence": 0,
                "data": {}
            }

    async def text_to_speech(self, text: str, **kwargs) -> bytes:
        """
        豆包不支持单独的TTS，使用端到端模式
        """
        logger.warning("[Doubao] 端到端模式不支持单独TTS")
        return b""

    async def speech_to_text(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        on_result: Optional[Callable[[str, bool], None]] = None
    ) -> str:
        """
        豆包不支持单独的ASR，使用端到端模式
        """
        logger.warning("[Doubao] 端到端模式不支持单独ASR")
        return ""

    def is_end_to_end(self) -> bool:
        """豆包是端到端模式"""
        return True

    def get_capabilities(self) -> Dict[str, bool]:
        """获取服务能力"""
        return {
            "streaming_asr": True,
            "streaming_tts": True,
            "end_to_end": True,
            "rag_integration": False,
            "emotion_control": False,
            "low_latency": True  # 端到端延迟低
        }
