"""
OpenAI Realtime API 语音服务适配器
端到端语音模型，支持实时对话
"""
import asyncio
import json
import logging
from typing import AsyncGenerator, Optional, Dict, Any, Callable

from app.services.voice_service_base import VoiceServiceBase, VoiceServiceType

logger = logging.getLogger(__name__)


class OpenAIRealtimeService(VoiceServiceBase):
    """OpenAI Realtime API 语音服务（端到端模式）"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.service_type = VoiceServiceType.OPENAI_REALTIME
        self.api_key = config.get("api_key")
        self.model = config.get("model", "gpt-4o-realtime-preview-2024-12-17")
        self.ws_url = "wss://api.openai.com/v1/realtime"
        self.session_api_url = "https://api.openai.com/v1/realtime/sessions"

    async def _create_session(self, context: Dict[str, Any]) -> str:
        """
        创建 Realtime Session 并返回 client_secret

        Reference: https://platform.openai.com/docs/guides/realtime
        """
        import httpx

        try:
            logger.info(f"[OpenAI Realtime] 开始创建 Session, model: {self.model}")

            # 配置代理（如果需要）
            import os
            proxies = None
            if os.getenv("HTTP_PROXY") or os.getenv("HTTPS_PROXY"):
                proxies = {
                    "http://": os.getenv("HTTP_PROXY"),
                    "https://": os.getenv("HTTPS_PROXY"),
                }
                logger.info(f"[OpenAI Realtime] 使用代理: {proxies}")

            async with httpx.AsyncClient(proxies=proxies, verify=True) as client:
                response = await client.post(
                    self.session_api_url,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": self.model,
                        "modalities": ["text", "audio"],
                        "voice": "alloy",
                        "instructions": context.get("system_prompt", "You are a helpful math teacher."),
                        "input_audio_format": "pcm16",
                        "output_audio_format": "pcm16",
                        "input_audio_transcription": {
                            "model": "whisper-1",
                            "language": "zh"
                        },
                        "turn_detection": {
                            "type": "server_vad",
                            "threshold": 0.5,
                            "prefix_padding_ms": 300,
                            "silence_duration_ms": 500
                        }
                    },
                    timeout=30.0
                )

                logger.info(f"[OpenAI Realtime] Session API 响应状态: {response.status_code}")

                if response.status_code != 200:
                    error_text = response.text
                    logger.error(f"[OpenAI Realtime] Session 创建失败: {error_text}")
                    raise Exception(f"Session creation failed with status {response.status_code}: {error_text}")

                response.raise_for_status()
                data = response.json()
                logger.info(f"[OpenAI Realtime] Session 响应数据: {json.dumps(data, indent=2)}")

                # 提取 client_secret (可能是字符串或对象格式)
                client_secret = data.get("client_secret")
                if isinstance(client_secret, dict):
                    client_secret = client_secret.get("value")

                if not client_secret:
                    raise Exception(f"No client_secret in response: {data}")

                logger.info(f"[OpenAI Realtime] Session 创建成功, secret 前20字符: {client_secret[:20]}...")
                return client_secret

        except Exception as e:
            logger.error(f"[OpenAI Realtime] Session 创建失败: {type(e).__name__}: {str(e)}")
            import traceback
            logger.error(f"[OpenAI Realtime] 详细堆栈: {traceback.format_exc()}")
            raise Exception(f"Failed to create OpenAI Realtime session: {str(e)}")

    async def process_conversation(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        context: Dict[str, Any],
        on_asr_result: Optional[Callable[[str, bool], None]] = None,
        on_llm_response: Optional[Callable[[str], None]] = None,
        on_tts_chunk: Optional[Callable[[bytes], None]] = None,
    ) -> Dict[str, Any]:
        """
        使用OpenAI Realtime API处理端到端语音对话

        Reference: https://platform.openai.com/docs/guides/realtime
        """
        logger.info("[OpenAI Realtime] ===== process_conversation 开始 =====")
        logger.info(f"[OpenAI Realtime] API Key 前20字符: {self.api_key[:20] if self.api_key else 'None'}...")

        try:
            import websockets

            # 1. 创建 Session 获取 client_secret
            logger.info("[OpenAI Realtime] 准备创建 Session...")
            client_secret = await self._create_session(context)
            logger.info(f"[OpenAI Realtime] Session 创建成功，client_secret 已获取")

            # 2. 使用 client_secret 连接 WebSocket
            ws_url = f"{self.ws_url}?model={self.model}"
            logger.info(f"[OpenAI Realtime] 连接 WebSocket: {ws_url}")

            user_text = ""
            assistant_text = ""
            assistant_audio = b""

            async with websockets.connect(
                ws_url,
                extra_headers={
                    "Authorization": f"Bearer {client_secret}",
                    "OpenAI-Beta": "realtime=v1"
                }
            ) as ws:
                logger.info(f"[OpenAI Realtime] WebSocket 连接成功: {self.model}")

                # 启动音频发送任务（session 配置已在创建时完成，无需再发送）
                send_task = asyncio.create_task(
                    self._send_audio_stream(ws, audio_stream)
                )

                # 接收响应
                try:
                    async for message in ws:
                        event = json.loads(message)
                        event_type = event.get("type")

                        # ASR识别结果
                        if event_type == "conversation.item.input_audio_transcription.completed":
                            transcript = event.get("transcript", "")
                            user_text += transcript
                            if on_asr_result:
                                on_asr_result(transcript, False)
                            logger.info(f"[OpenAI Realtime] 用户: {transcript}")

                        # LLM响应文本
                        elif event_type == "response.text.delta":
                            delta = event.get("delta", "")
                            assistant_text += delta
                            if on_llm_response:
                                on_llm_response(delta)

                        elif event_type == "response.text.done":
                            text = event.get("text", "")
                            assistant_text = text
                            logger.info(f"[OpenAI Realtime] 助手: {text}")

                        # TTS音频输出
                        elif event_type == "response.audio.delta":
                            audio_b64 = event.get("delta", "")
                            if audio_b64:
                                import base64
                                audio_chunk = base64.b64decode(audio_b64)
                                assistant_audio += audio_chunk
                                if on_tts_chunk:
                                    on_tts_chunk(audio_chunk)

                        # 对话完成
                        elif event_type == "response.done":
                            logger.info("[OpenAI Realtime] 对话完成")
                            break

                        # 错误处理
                        elif event_type == "error":
                            error = event.get("error", {})
                            logger.error(f"[OpenAI Realtime] 错误: {error}")
                            raise Exception(f"OpenAI Realtime Error: {error}")

                except asyncio.CancelledError:
                    logger.info("[OpenAI Realtime] 接收任务被取消")
                finally:
                    send_task.cancel()
                    try:
                        await send_task
                    except asyncio.CancelledError:
                        pass

            return {
                "user_text": user_text,
                "assistant_text": assistant_text,
                "assistant_audio": assistant_audio,
                "metadata": {
                    "provider": "openai_realtime",
                    "model": self.model,
                    "end_to_end": True
                }
            }

        except Exception as e:
            logger.error(f"[OpenAI Realtime] 处理失败: {type(e).__name__}: {str(e)}")
            import traceback
            logger.error(f"[OpenAI Realtime] 详细错误: {traceback.format_exc()}")
            raise Exception(f"OpenAI Realtime处理失败: {str(e)}")

    async def _send_audio_stream(self, ws, audio_stream: AsyncGenerator[bytes, None]):
        """发送音频流到OpenAI Realtime API"""
        import base64

        try:
            async for audio_chunk in audio_stream:
                # 将PCM音频编码为base64
                audio_b64 = base64.b64encode(audio_chunk).decode('utf-8')
                await ws.send(json.dumps({
                    "type": "input_audio_buffer.append",
                    "audio": audio_b64
                }))

            # 提交音频缓冲区
            await ws.send(json.dumps({
                "type": "input_audio_buffer.commit"
            }))

            # 创建响应
            await ws.send(json.dumps({
                "type": "response.create"
            }))

        except asyncio.CancelledError:
            logger.info("[OpenAI Realtime] 音频发送被取消")
        except Exception as e:
            logger.error(f"[OpenAI Realtime] 音频发送失败: {e}")

    async def text_to_speech(self, text: str, **kwargs) -> bytes:
        """
        OpenAI Realtime不支持单独的TTS，使用OpenAI TTS API作为fallback
        """
        logger.warning("[OpenAI Realtime] 使用OpenAI TTS API作为fallback")
        try:
            import httpx

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "https://api.openai.com/v1/audio/speech",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": "tts-1",
                        "input": text,
                        "voice": kwargs.get("voice", "alloy"),
                        "response_format": "pcm"
                    },
                    timeout=30.0
                )
                response.raise_for_status()
                return response.content

        except Exception as e:
            logger.error(f"[OpenAI TTS] 合成失败: {e}")
            raise

    async def speech_to_text(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        on_result: Optional[Callable[[str, bool], None]] = None
    ) -> str:
        """
        OpenAI Realtime不支持单独的ASR，使用Whisper API作为fallback
        """
        logger.warning("[OpenAI Realtime] 使用Whisper API作为fallback")
        try:
            import httpx
            import io

            # 收集所有音频数据
            audio_data = b""
            async for chunk in audio_stream:
                audio_data += chunk

            # 转换为WAV格式
            import wave
            wav_buffer = io.BytesIO()
            with wave.open(wav_buffer, 'wb') as wav_file:
                wav_file.setnchannels(1)
                wav_file.setsampwidth(2)  # 16-bit
                wav_file.setframerate(16000)
                wav_file.writeframes(audio_data)

            wav_buffer.seek(0)

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "https://api.openai.com/v1/audio/transcriptions",
                    headers={
                        "Authorization": f"Bearer {self.api_key}"
                    },
                    files={
                        "file": ("audio.wav", wav_buffer, "audio/wav")
                    },
                    data={
                        "model": "whisper-1",
                        "language": "zh"
                    },
                    timeout=30.0
                )
                response.raise_for_status()
                result = response.json()
                text = result.get("text", "")

                if on_result:
                    on_result(text, True)

                return text

        except Exception as e:
            logger.error(f"[Whisper API] 识别失败: {e}")
            raise

    def is_end_to_end(self) -> bool:
        """OpenAI Realtime是端到端模型"""
        return True

    def get_capabilities(self) -> Dict[str, bool]:
        """获取服务能力"""
        return {
            "streaming_asr": True,
            "streaming_tts": True,
            "end_to_end": True,
            "rag_integration": False,  # 需要通过system prompt注入
            "emotion_control": False
        }
