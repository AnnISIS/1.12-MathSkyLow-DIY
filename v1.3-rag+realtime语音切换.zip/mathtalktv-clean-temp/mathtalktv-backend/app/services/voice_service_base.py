"""
语音服务抽象层 - 统一接口定义
支持多种语音服务提供商：讯飞、OpenAI、豆包、阿里云、腾讯云
"""
from abc import ABC, abstractmethod
from typing import AsyncGenerator, Optional, Dict, Any, Callable
from enum import Enum


class VoiceServiceType(str, Enum):
    """语音服务类型"""
    XFYUN = "xfyun"  # 讯飞 ASR+TTS
    OPENAI_REALTIME = "openai_realtime"  # OpenAI Realtime API (端到端)
    DOUBAO = "doubao"  # 豆包端到端语音模型
    ALIYUN_ICE = "aliyun_ice"  # 阿里云智能通信引擎
    TENCENT_RAG = "tencent_rag"  # 腾讯云 ASR+TTS+RAG中间件


class VoiceServiceBase(ABC):
    """语音服务基类 - 所有语音服务必须实现此接口"""

    def __init__(self, config: Dict[str, Any]):
        """
        初始化语音服务

        Args:
            config: 服务配置字典
        """
        self.config = config
        self.service_type: VoiceServiceType = None

    @abstractmethod
    async def process_conversation(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        context: Dict[str, Any],
        on_asr_result: Optional[Callable[[str, bool], None]] = None,
        on_llm_response: Optional[Callable[[str], None]] = None,
        on_tts_chunk: Optional[Callable[[bytes], None]] = None,
    ) -> Dict[str, Any]:
        """
        处理完整对话流程

        Args:
            audio_stream: 输入音频流（PCM格式）
            context: 对话上下文（包含视频内容、历史对话等）
            on_asr_result: ASR识别结果回调 (text, is_final)
            on_llm_response: LLM响应回调 (text)
            on_tts_chunk: TTS音频块回调 (audio_bytes)

        Returns:
            {
                "user_text": "识别的用户问题",
                "assistant_text": "AI回答文本",
                "assistant_audio": bytes音频数据,
                "metadata": {额外的元数据}
            }
        """
        pass

    @abstractmethod
    async def text_to_speech(self, text: str, **kwargs) -> bytes:
        """
        文本转语音

        Args:
            text: 要合成的文本
            **kwargs: 服务特定参数（语速、音色等）

        Returns:
            音频数据（PCM或其他格式）
        """
        pass

    @abstractmethod
    async def speech_to_text(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        on_result: Optional[Callable[[str, bool], None]] = None
    ) -> str:
        """
        语音转文本

        Args:
            audio_stream: 输入音频流
            on_result: 识别结果回调

        Returns:
            识别的文本
        """
        pass

    @abstractmethod
    def is_end_to_end(self) -> bool:
        """
        判断是否为端到端模型

        Returns:
            True: 端到端模型（一次性处理ASR+LLM+TTS）
            False: 管道模型（需要分步调用ASR、LLM、TTS）
        """
        pass

    async def health_check(self) -> Dict[str, Any]:
        """
        健康检查

        Returns:
            {
                "status": "ok" | "error",
                "message": "详细信息",
                "latency_ms": 延迟毫秒数
            }
        """
        return {
            "status": "ok",
            "message": f"{self.service_type} service is ready",
            "latency_ms": 0
        }

    def get_capabilities(self) -> Dict[str, bool]:
        """
        获取服务能力

        Returns:
            {
                "streaming_asr": 是否支持流式ASR,
                "streaming_tts": 是否支持流式TTS,
                "end_to_end": 是否端到端,
                "rag_integration": 是否原生支持RAG,
                "emotion_control": 是否支持情感控制
            }
        """
        return {
            "streaming_asr": False,
            "streaming_tts": False,
            "end_to_end": self.is_end_to_end(),
            "rag_integration": False,
            "emotion_control": False
        }
