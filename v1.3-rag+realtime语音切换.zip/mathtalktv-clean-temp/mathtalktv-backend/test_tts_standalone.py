"""
独立TTS测试脚本
用于调试讯飞语音合成问题
"""
import asyncio
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(__file__))

from app.services.xfyun_tts import XFYunTTS
from app.core.config import settings


async def main():
    print("=" * 50)
    print("讯飞TTS独立测试")
    print("=" * 50)

    # 检查配置
    print(f"\n配置检查:")
    print(f"APP_ID: {settings.XFYUN_APP_ID}")
    print(f"API_KEY: {settings.XFYUN_API_KEY[:10]}...")
    print(f"API_SECRET: {settings.XFYUN_API_SECRET[:10]}...")

    # 初始化TTS
    tts = XFYunTTS()

    # 测试文本
    test_text = "你好，这是一个语音合成测试。"
    print(f"\n测试文本: {test_text}")

    try:
        print("\n开始合成...")
        audio_data = await tts.synthesize(test_text)

        print(f"✅ 合成成功!")
        print(f"音频数据大小: {len(audio_data)} 字节")

        # 保存到文件
        output_file = "test_output.pcm"
        with open(output_file, "wb") as f:
            f.write(audio_data)

        print(f"\n✅ 音频已保存到: {output_file}")
        print(f"\n播放命令:")
        print(f"ffplay -f s16le -ar 16000 -ac 1 {output_file}")

    except Exception as e:
        print(f"\n❌ 合成失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
