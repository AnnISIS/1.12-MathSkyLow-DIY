# MathTalkTV 📚🎤

> 初中生数学智能讲题平台 - 让学习数学更简单

一个创新的数学学习平台，学生可以上传数学教学视频，随时通过**语音**向AI老师提问，获得**语音+可视化**的实时解答。

## ✨ 核心特性

- 🎥 **视频上传** - 支持MP4等主流格式，自动提取字幕
- 🤖 **AI字幕提取** - 使用Whisper技术，精准识别讲解内容
- 🎯 **智能节点识别** - 自动识别视频中的知识点边界
- 🎤 **实时语音对话** - 按住提问，AI语音回答
- ✍️ **LaTeX公式渲染** - 数学公式完美显示
- 💬 **智能问答** - 结合视频内容的上下文理解

## 🚀 快速开始

### 1. 安装ffmpeg

```bash
# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt-get install ffmpeg

# Windows - 从 https://ffmpeg.org/download.html 下载
```

### 2. 安装Python依赖

```bash
cd mathtalktv-backend
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. 配置环境变量

编辑 `.env` 文件，填入你的API密钥：

```bash
# 讯飞语音服务
XFYUN_APP_ID=your_app_id
XFYUN_API_KEY=your_api_key
XFYUN_API_SECRET=your_api_secret

# OpenAI兼容API（用于Whisper和LLM）
OPENAI_API_KEY=your_api_key
OPENAI_BASE_URL=https://api.openai.com/v1

# uiuiapi (可选，已预配置)
UIUIAPI_KEY=your_key
UIUIAPI_BASE_URL=https://sg.uiuiapi.com/v1
```

### 4. 运行服务

```bash
source venv/bin/activate
python run.py
```

✅ 服务运行在：**http://localhost:8000**
📖 API文档：**http://localhost:8000/docs**

## 📋 功能清单

### 已完成 ✅
- [x] 视频上传与存储
- [x] Whisper AI字幕提取
- [x] AI节点识别（知识点分段）
- [x] 讯飞ASR实时语音识别
- [x] 讯飞TTS语音合成
- [x] WebSocket实时对话流程
- [x] SQLite数据库持久化
- [x] RESTful API接口

### 待优化 🚧
- [ ] 音频格式转换（WebM → PCM）
- [ ] WebSocket心跳保活机制
- [ ] 日志系统完善
- [ ] 错误处理优化
- [ ] 性能监控

## 项目结构

```
app/
├── api/                   # API路由
│   ├── videos.py          # 视频管理接口
│   └── chat.py            # WebSocket对话接口
├── core/                  # 核心配置
│   └── config.py          # 环境变量配置
├── db/                    # 数据库
│   └── database.py        # SQLite初始化
├── models/                # 数据模型
│   └── schemas.py         # Pydantic模型
├── services/              # 业务服务
│   ├── video_processor.py # 视频处理（ffmpeg+Whisper）
│   ├── node_extractor.py  # AI节点识别
│   ├── xfyun_asr.py       # 讯飞语音识别
│   └── xfyun_tts.py       # 讯飞语音合成
└── main.py                # FastAPI主应用
```

## 🔌 API接口

### RESTful API

#### 上传视频
```http
POST /api/upload
Content-Type: multipart/form-data

Response:
{
  "video_id": "uuid",
  "status": "ready_no_nodes",
  "duration": 123.45,
  "subtitles_count": 50
}
```

#### 获取视频详情
```http
GET /api/videos/{video_id}
```

#### 提取知识点节点
```http
POST /api/videos/{video_id}/extract-nodes
```

### WebSocket API

#### 实时对话
```
ws://localhost:8000/api/ws/chat/{video_id}
```

**消息格式：**
- 客户端发送：音频数据（二进制）
- 服务端返回：
  - `{"type": "asr_result", "data": "用户问题"}`
  - `{"type": "ai_response", "data": "AI回答"}`
  - 音频数据（二进制PCM）
  - `{"type": "audio_complete"}`

## 💡 技术亮点

- ⚡ **异步处理**：FastAPI + asyncio，高并发性能
- 🎯 **流式传输**：ASR/TTS流式处理，降低延迟
- 🔄 **实时通信**：WebSocket双向通信
- 📦 **轻量部署**：SQLite无需额外数据库服务
