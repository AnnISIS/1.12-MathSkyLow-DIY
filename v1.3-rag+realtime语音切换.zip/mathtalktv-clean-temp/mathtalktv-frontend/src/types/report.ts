export interface VideoReport {
  video_id: string;
  total_views: number;
  avg_completion_rate: number;
  total_watch_time: number;
  total_questions: number;
  avg_satisfaction: number;
  satisfaction_distribution: { [key: string]: number };
  question_heatmap: Array<{ time: number; count: number }>;
  question_wordcloud: Array<{ word: string; count: number }>;
}

export interface StudentReport {
  student_id: string;
  total_watch_time: number;
  total_sessions: number;
  total_questions: number;
  avg_completion_rate: number;
  weak_concepts: string[];
  learning_preferences: {
    question_style: string;
    learning_mode: string;
    active_level: string;
  };
  mastery_distribution: { [key: string]: number };
  learning_trend: Array<{
    date: string;
    sessions: number;
    watch_time: number;
  }>;
}
