/**
 * 语音服务切换组件
 * 支持在不同语音服务提供商之间切换
 */
import { useState, useEffect } from 'react';
import './VoiceServiceSelector.css';

interface VoiceService {
  id: string;
  name: string;
  type: 'pipeline' | 'end_to_end';
  capabilities: {
    streaming_asr?: boolean;
    streaming_tts?: boolean;
    end_to_end?: boolean;
    rag_integration?: boolean;
    emotion_control?: boolean;
    low_latency?: boolean;
  };
  available: boolean;
  error?: string;
}

interface Props {
  onServiceChange?: (serviceId: string) => void;
}

const VoiceServiceSelector = ({ onServiceChange }: Props) => {
  const [services, setServices] = useState<VoiceService[]>([]);
  const [currentService, setCurrentService] = useState<string>('xfyun');
  const [loading, setLoading] = useState<boolean>(true);
  const [showSelector, setShowSelector] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // 加载语音服务列表
  useEffect(() => {
    fetchVoiceServices();
  }, []);

  const fetchVoiceServices = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:8000/api/voice-services');

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      setServices(data.services);
      setCurrentService(data.current);
      setError(null);
    } catch (err: any) {
      console.error('❌ 获取语音服务列表失败:', err);
      setError(err.message || '获取语音服务列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSwitch = async (serviceId: string) => {
    if (serviceId === currentService) {
      setShowSelector(false);
      return;
    }

    try {
      setLoading(true);
      const response = await fetch('http://localhost:8000/api/voice-services/switch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ service_type: serviceId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || '切换失败');
      }

      const result = await response.json();

      if (result.success) {
        setCurrentService(serviceId);
        setShowSelector(false);
        setError(null);

        // 通知父组件
        if (onServiceChange) {
          onServiceChange(serviceId);
        }

        // 显示成功提示
        alert(`✅ ${result.message}`);
      }
    } catch (err: any) {
      console.error('❌ 切换语音服务失败:', err);
      alert(`❌ 切换失败: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const getServiceIcon = (service: VoiceService) => {
    if (!service.available) return '⚠️';
    if (service.capabilities.end_to_end) return '🚀';
    if (service.capabilities.low_latency) return '⚡';
    if (service.capabilities.rag_integration) return '🔍';
    return '🎤';
  };

  const getCurrentServiceName = () => {
    const service = services.find(s => s.id === currentService);
    return service ? service.name : currentService;
  };

  if (loading && services.length === 0) {
    return (
      <div className="voice-service-selector loading">
        <span>⏳ 加载中...</span>
      </div>
    );
  }

  if (error && services.length === 0) {
    return (
      <div className="voice-service-selector error">
        <span>❌ {error}</span>
      </div>
    );
  }

  return (
    <div className="voice-service-selector">
      <button
        className="current-service-btn"
        onClick={() => setShowSelector(!showSelector)}
        disabled={loading}
      >
        <span className="service-icon">🎤</span>
        <span className="service-name">{getCurrentServiceName()}</span>
        <span className="dropdown-icon">{showSelector ? '▲' : '▼'}</span>
      </button>

      {showSelector && (
        <div className="service-dropdown">
          <div className="dropdown-header">
            <h4>选择语音服务</h4>
            <button
              className="close-btn"
              onClick={() => setShowSelector(false)}
            >
              ✕
            </button>
          </div>

          <div className="service-list">
            {services.map(service => (
              <div
                key={service.id}
                className={`service-item ${service.id === currentService ? 'active' : ''} ${!service.available ? 'disabled' : ''}`}
                onClick={() => service.available && handleServiceSwitch(service.id)}
              >
                <div className="service-header">
                  <span className="service-icon">{getServiceIcon(service)}</span>
                  <span className="service-title">{service.name}</span>
                  {service.id === currentService && <span className="current-badge">当前</span>}
                </div>

                {!service.available && (
                  <div className="service-error">
                    ⚠️ 不可用: {service.error || '请检查配置'}
                  </div>
                )}

                {service.available && (
                  <div className="service-capabilities">
                    {service.capabilities.end_to_end && <span className="capability-tag">端到端</span>}
                    {service.capabilities.rag_integration && <span className="capability-tag rag">原生RAG</span>}
                    {service.capabilities.low_latency && <span className="capability-tag fast">低延迟</span>}
                    {service.capabilities.streaming_asr && <span className="capability-tag">流式ASR</span>}
                    {service.capabilities.streaming_tts && <span className="capability-tag">流式TTS</span>}
                    {service.capabilities.emotion_control && <span className="capability-tag">情感控制</span>}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="dropdown-footer">
            <small>提示: 切换服务后需要重新连接</small>
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceServiceSelector;
