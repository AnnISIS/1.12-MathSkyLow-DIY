import { useState, useEffect, RefObject } from 'react';
import { Node } from '../types';
import './VideoPlayer.css';

interface Props {
  videoUrl: string;
  videoId: string;
  videoRef: RefObject<HTMLVideoElement | null>;
  nodes?: Node[];
}

const VideoPlayer = ({ videoUrl, videoRef, nodes = [] }: Props) => {
  const [currentTime, setCurrentTime] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [duration, setDuration] = useState(0);
  const [hoveredNode, setHoveredNode] = useState<Node | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    console.log('VideoPlayer加载视频:', videoUrl);
    setError(null);
    setReady(false);
  }, [videoUrl]);

  // 空格键暂停/播放视频
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // 只在空格键且不在输入框中时触发
      if (e.code === 'Space' && videoRef.current) {
        const target = e.target as HTMLElement;
        // 避免在输入框、按钮等元素中触发
        if (target.tagName !== 'INPUT' && target.tagName !== 'TEXTAREA' && target.tagName !== 'BUTTON') {
          e.preventDefault();
          if (videoRef.current.paused) {
            videoRef.current.play();
          } else {
            videoRef.current.pause();
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [videoRef]);

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    console.log('视频元数据加载成功');
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleCanPlay = () => {
    console.log('视频可以播放');
    setReady(true);
    setError(null);
  };

  const handleError = (e: any) => {
    console.error('视频加载失败:', e);
    setError('视频加载失败,请检查视频文件是否存在');
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleNodeClick = (node: Node) => {
    if (videoRef.current) {
      videoRef.current.currentTime = node.start_time;
    }
  };

  const handleNodeHover = (node: Node, event: React.MouseEvent<HTMLDivElement>) => {
    setHoveredNode(node);
    const rect = event.currentTarget.getBoundingClientRect();
    const windowWidth = window.innerWidth;
    const tooltipWidth = 300; // tooltip最大宽度

    let x = rect.left + rect.width / 2;

    // 边缘检测：如果tooltip会超出屏幕，调整位置
    if (x - tooltipWidth / 2 < 10) {
      // 左边缘，向右偏移
      x = tooltipWidth / 2 + 10;
    } else if (x + tooltipWidth / 2 > windowWidth - 10) {
      // 右边缘，向左偏移
      x = windowWidth - tooltipWidth / 2 - 10;
    }

    setTooltipPosition({
      x: x,
      y: rect.top
    });
  };

  const handleNodeLeave = () => {
    setHoveredNode(null);
  };

  return (
    <div className="video-player-container">
      {error && (
        <div className="video-error">
          ❌ {error}
          <div className="error-details">
            <p>视频URL: {videoUrl}</p>
            <p>请尝试刷新页面或重新上传视频</p>
          </div>
        </div>
      )}

      <div className="player-wrapper">
        <video
          ref={videoRef}
          src={videoUrl}
          controls
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onCanPlay={handleCanPlay}
          onError={handleError}
          style={{ width: '100%', height: '100%', objectFit: 'contain' }}
        >
          您的浏览器不支持视频播放
        </video>

        {/* 节点标记层 - 覆盖在视频进度条上 */}
        {ready && duration > 0 && nodes.length > 0 && (
          <div className="nodes-overlay">
            {nodes.map((node) => {
              const position = (node.start_time / duration) * 100;
              return (
                <div
                  key={node.id}
                  className="node-marker"
                  style={{ left: `${position}%` }}
                  onClick={() => handleNodeClick(node)}
                  onMouseEnter={(e) => handleNodeHover(node, e)}
                  onMouseLeave={handleNodeLeave}
                  title={node.title}
                >
                  <div className="node-dot" />
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="player-info">
        <span className="time-display">
          {ready ? `${formatTime(currentTime)} / ${formatTime(duration)}` : '加载中...'}
        </span>
      </div>

      {/* 节点信息Tooltip */}
      {hoveredNode && (
        <div
          className="node-tooltip"
          style={{
            left: `${tooltipPosition.x}px`,
            top: `${tooltipPosition.y - 10}px`,
            transform: 'translate(-50%, -100%)'
          }}
        >
          <div className="tooltip-title">{hoveredNode.title}</div>
          {hoveredNode.summary && (
            <div className="tooltip-summary">{hoveredNode.summary}</div>
          )}
          <div className="tooltip-time">
            {formatTime(hoveredNode.start_time)} - {formatTime(hoveredNode.end_time)}
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoPlayer;
