import { useEffect, useRef, useState } from 'react';
import './GeoGebraBoard.css';

interface GeoGebraBoardProps {
  onReady?: (app: any) => void;
  onClose?: () => void;
}

export function GeoGebraBoard({ onReady, onClose }: GeoGebraBoardProps) {
  const appRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // 检查GeoGebra是否已加载
    if ((window as any).GGBApplet) {
      initGeoGebra();
      return;
    }

    // 加载GeoGebra脚本
    const script = document.createElement('script');
    script.src = 'https://www.geogebra.org/apps/deployggb.js';
    script.async = true;

    script.onload = () => {
      initGeoGebra();
    };

    script.onerror = () => {
      console.error('Failed to load GeoGebra API');
      setError('GeoGebra 加载失败');
      setIsLoading(false);
    };

    document.body.appendChild(script);

    return () => {
      if (appRef.current) {
        try {
          // GeoGebra 没有显式的destroy方法，清空容器即可
          if (containerRef.current) {
            containerRef.current.innerHTML = '';
          }
        } catch (e) {
          console.error('Error cleaning up GeoGebra:', e);
        }
      }
    };
  }, []);

  const initGeoGebra = () => {
    try {
      const parameters = {
        appName: "geometry",
        width: containerRef.current?.clientWidth || 800,
        height: containerRef.current?.clientHeight || 600,
        showToolBar: true,
        showAlgebraInput: true,
        showMenuBar: false,
        enableShiftDragZoom: true,
        enableRightClick: false,
        showResetIcon: true,
        language: "zh_CN",
        borderColor: "#e0e0e0",
        preventFocus: false,
        allowStyleBar: true
      };

      const applet = new (window as any).GGBApplet(parameters, true);

      applet.inject('geogebra-container');

      // 等待GeoGebra完全加载
      setTimeout(() => {
        appRef.current = applet;
        setIsLoading(false);

        // 获取GeoGebra API对象
        const api = applet.getAppletObject();
        onReady?.(api);
      }, 1000);

    } catch (e) {
      console.error('Error initializing GeoGebra:', e);
      setError('GeoGebra 初始化失败');
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    if (appRef.current) {
      try {
        const api = appRef.current.getAppletObject();
        api.reset();
      } catch (e) {
        console.error('Error clearing GeoGebra:', e);
      }
    }
  };

  const handleScreenshot = () => {
    if (appRef.current) {
      try {
        const api = appRef.current.getAppletObject();
        const png = api.getPNGBase64(1.0, true, 72);

        const link = document.createElement('a');
        link.href = 'data:image/png;base64,' + png;
        link.download = `geogebra-${Date.now()}.png`;
        link.click();
      } catch (e) {
        console.error('Error taking screenshot:', e);
        alert('截图失败，请重试');
      }
    }
  };

  const handleAddCircle = () => {
    if (appRef.current) {
      try {
        const api = appRef.current.getAppletObject();
        const input = prompt('输入圆的命令 (例如: Circle((0,0), 3)):');
        if (input) {
          api.evalCommand(input);
        }
      } catch (e) {
        console.error('Error adding circle:', e);
      }
    }
  };

  const handleAddPoint = () => {
    if (appRef.current) {
      try {
        const api = appRef.current.getAppletObject();
        const input = prompt('输入点的坐标 (例如: (2, 3)):');
        if (input) {
          api.evalCommand(`Point${input}`);
        }
      } catch (e) {
        console.error('Error adding point:', e);
      }
    }
  };

  const handleAddLine = () => {
    if (appRef.current) {
      try {
        const api = appRef.current.getAppletObject();
        const input = prompt('输入直线命令 (例如: Line((0,0), (1,1))):');
        if (input) {
          api.evalCommand(input);
        }
      } catch (e) {
        console.error('Error adding line:', e);
      }
    }
  };

  const handleAddPolygon = () => {
    if (appRef.current) {
      try {
        const api = appRef.current.getAppletObject();
        const input = prompt('输入多边形命令 (例如: Polygon((0,0), (1,0), (1,1), (0,1))):');
        if (input) {
          api.evalCommand(input);
        }
      } catch (e) {
        console.error('Error adding polygon:', e);
      }
    }
  };

  return (
    <div className="geogebra-board">
      <div className="geogebra-header">
        <h3>📐 GeoGebra 几何画板</h3>
        <button className="close-button" onClick={onClose}>✕</button>
      </div>

      <div className="geogebra-toolbar">
        <button className="toolbar-btn" onClick={handleAddPoint} disabled={isLoading}>
          📍 点
        </button>
        <button className="toolbar-btn" onClick={handleAddLine} disabled={isLoading}>
          📏 直线
        </button>
        <button className="toolbar-btn" onClick={handleAddCircle} disabled={isLoading}>
          ⭕ 圆
        </button>
        <button className="toolbar-btn" onClick={handleAddPolygon} disabled={isLoading}>
          ▭ 多边形
        </button>
        <button className="toolbar-btn" onClick={handleClear} disabled={isLoading}>
          🗑️ 清空
        </button>
        <button className="toolbar-btn" onClick={handleScreenshot} disabled={isLoading}>
          📷 截图
        </button>
      </div>

      {isLoading && !error && (
        <div className="geogebra-loading">
          <div className="spinner"></div>
          <p>正在加载 GeoGebra...</p>
          <p className="loading-hint">首次加载可能需要 5-10 秒</p>
        </div>
      )}

      {error && (
        <div className="geogebra-error">
          <p>❌ {error}</p>
          <button onClick={() => window.location.reload()}>重新加载</button>
        </div>
      )}

      <div className="geogebra-container-wrapper" style={{ position: 'relative' }}>
        <div
          ref={containerRef}
          id="geogebra-container"
          className="geogebra-container"
          style={{ display: isLoading ? 'none' : 'block' }}
        />
      </div>
    </div>
  );
}
