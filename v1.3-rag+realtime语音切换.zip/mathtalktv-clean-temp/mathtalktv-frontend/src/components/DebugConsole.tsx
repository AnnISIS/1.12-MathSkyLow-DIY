/**
 * 调试控制台 - 统一管理所有调试配置
 * 包括: RAG开关、RAG检索模式、LLM模型、语音服务
 */
import { useState, useEffect } from 'react';
import './DebugConsole.css';

interface VoiceService {
  id: string;
  name: string;
  available: boolean;
  error?: string;
}

interface DebugConfig {
  ragEnabled: boolean;
  ragMode: 'vector' | 'bm25' | 'hybrid';
  llmModel: string;
  voiceService: string;
}

interface Props {
  currentConfig: DebugConfig;
  availableModels: Array<{id: string, name: string, provider: string}>;
  onConfigChange: (config: DebugConfig) => void;
}

const DebugConsole = ({ currentConfig, availableModels, onConfigChange }: Props) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [config, setConfig] = useState<DebugConfig>(currentConfig);
  const [voiceServices, setVoiceServices] = useState<VoiceService[]>([]);

  // 同步外部配置变化
  useEffect(() => {
    setConfig(currentConfig);
  }, [currentConfig]);

  // 加载语音服务列表
  useEffect(() => {
    if (isOpen) {
      fetchVoiceServices();
    }
  }, [isOpen]);

  const fetchVoiceServices = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/voice-services');
      if (!response.ok) throw new Error('获取语音服务列表失败');
      const data = await response.json();
      setVoiceServices(data.services);
    } catch (err) {
      console.error('❌ 获取语音服务列表失败:', err);
    }
  };

  const handleSave = () => {
    console.log('🛠️ ===== 调试控制台：保存配置 =====');
    console.log('📊 新配置:', {
      'RAG启用': config.ragEnabled,
      'RAG检索模式': config.ragMode,
      'LLM模型': config.llmModel,
      '语音服务': config.voiceService
    });
    console.log('📊 当前配置:', {
      'RAG启用': currentConfig.ragEnabled,
      'RAG检索模式': currentConfig.ragMode,
      'LLM模型': currentConfig.llmModel,
      '语音服务': currentConfig.voiceService
    });

    // 检测变化
    const changes = [];
    if (config.ragEnabled !== currentConfig.ragEnabled) {
      changes.push(`RAG: ${currentConfig.ragEnabled ? '启用' : '禁用'} → ${config.ragEnabled ? '启用' : '禁用'}`);
    }
    if (config.ragMode !== currentConfig.ragMode) {
      changes.push(`RAG检索模式: ${currentConfig.ragMode} → ${config.ragMode}`);
    }
    if (config.llmModel !== currentConfig.llmModel) {
      changes.push(`LLM模型: ${currentConfig.llmModel} → ${config.llmModel}`);
    }
    if (config.voiceService !== currentConfig.voiceService) {
      changes.push(`语音服务: ${currentConfig.voiceService} → ${config.voiceService}`);
    }

    if (changes.length > 0) {
      console.log('🔄 检测到配置变化:');
      changes.forEach(change => console.log(`  - ${change}`));
    } else {
      console.log('ℹ️ 配置未变化');
    }
    console.log('🛠️ =============================');

    onConfigChange(config);
    setIsOpen(false);
  };

  const handleReset = () => {
    console.log('🔄 调试控制台：重置配置到当前生效值');
    setConfig(currentConfig);
  };

  return (
    <>
      {/* 侧边悬浮按钮 */}
      <button
        className={`debug-console-trigger ${isOpen ? 'open' : ''}`}
        onClick={() => setIsOpen(!isOpen)}
        title="调试控制台"
      >
        <span className="trigger-icon">⚙️</span>
        <span className="trigger-text">调试</span>
      </button>

      {/* 控制台面板 */}
      {isOpen && (
        <>
          {/* 遮罩层 */}
          <div className="debug-console-overlay" onClick={() => setIsOpen(false)} />

          {/* 配置面板 */}
          <div className="debug-console-panel">
            <div className="console-header">
              <h3>🛠️ 调试控制台</h3>
              <button className="close-btn" onClick={() => setIsOpen(false)}>✕</button>
            </div>

            <div className="console-body">
              {/* RAG配置区 */}
              <div className="config-section">
                <h4>🔍 RAG配置</h4>

                <div className="config-item">
                  <label className="config-label">
                    <span>启用RAG</span>
                    <div className="toggle-switch">
                      <input
                        type="checkbox"
                        checked={config.ragEnabled}
                        onChange={(e) => setConfig({...config, ragEnabled: e.target.checked})}
                      />
                      <span className="toggle-slider"></span>
                    </div>
                  </label>
                  <p className="config-desc">
                    {config.ragEnabled ? '使用RAG语义检索相关内容' : '简单截取视频字幕'}
                  </p>
                </div>

                {config.ragEnabled && (
                  <div className="config-item">
                    <label className="config-label">检索模式</label>
                    <div className="radio-group">
                      <label className={`radio-option ${config.ragMode === 'vector' ? 'active' : ''}`}>
                        <input
                          type="radio"
                          name="ragMode"
                          value="vector"
                          checked={config.ragMode === 'vector'}
                          onChange={() => setConfig({...config, ragMode: 'vector'})}
                        />
                        <span className="radio-label">
                          <strong>🔍 向量检索</strong>
                          <small>基于语义理解</small>
                        </span>
                      </label>
                      <label className={`radio-option ${config.ragMode === 'bm25' ? 'active' : ''}`}>
                        <input
                          type="radio"
                          name="ragMode"
                          value="bm25"
                          checked={config.ragMode === 'bm25'}
                          onChange={() => setConfig({...config, ragMode: 'bm25'})}
                        />
                        <span className="radio-label">
                          <strong>🔤 关键词检索 (BM25)</strong>
                          <small>基于关键词匹配</small>
                        </span>
                      </label>
                      <label className={`radio-option ${config.ragMode === 'hybrid' ? 'active' : ''}`}>
                        <input
                          type="radio"
                          name="ragMode"
                          value="hybrid"
                          checked={config.ragMode === 'hybrid'}
                          onChange={() => setConfig({...config, ragMode: 'hybrid'})}
                        />
                        <span className="radio-label">
                          <strong>⚡ 混合检索</strong>
                          <small>0.7向量 + 0.3关键词</small>
                        </span>
                      </label>
                    </div>
                  </div>
                )}
              </div>

              {/* LLM模型配置 */}
              <div className="config-section">
                <h4>🤖 LLM模型</h4>
                <div className="config-item">
                  <label className="config-label">当前模型</label>
                  <select
                    className="model-select"
                    value={config.llmModel}
                    onChange={(e) => setConfig({...config, llmModel: e.target.value})}
                  >
                    {availableModels.map(model => (
                      <option key={model.id} value={model.id}>
                        {model.name} ({model.provider})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* 语音服务配置 */}
              <div className="config-section">
                <h4>🎤 语音服务</h4>
                <div className="config-item">
                  <label className="config-label">当前服务</label>
                  <select
                    className="voice-select"
                    value={config.voiceService}
                    onChange={(e) => setConfig({...config, voiceService: e.target.value})}
                  >
                    {voiceServices.map(service => (
                      <option
                        key={service.id}
                        value={service.id}
                        disabled={!service.available}
                      >
                        {service.name} {!service.available ? '(不可用)' : ''}
                      </option>
                    ))}
                  </select>
                  {voiceServices.find(s => s.id === config.voiceService)?.error && (
                    <p className="config-error">
                      ⚠️ {voiceServices.find(s => s.id === config.voiceService)?.error}
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="console-footer">
              <button className="reset-btn" onClick={handleReset}>
                重置
              </button>
              <button className="save-btn" onClick={handleSave}>
                保存并应用
              </button>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default DebugConsole;
