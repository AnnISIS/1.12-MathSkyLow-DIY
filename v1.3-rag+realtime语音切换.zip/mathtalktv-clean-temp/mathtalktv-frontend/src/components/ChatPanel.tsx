import { useState, useRef, useEffect, RefObject } from 'react';
import katex from 'katex';
import 'katex/dist/katex.min.css';
import { ChatMessage } from '../types';
import DebugConsole from './DebugConsole';
import { useRealtimeVoice } from '../hooks/useRealtimeVoice';
import './ChatPanel.css';

interface Props {
  videoId: string;
  videoRef: RefObject<HTMLVideoElement | null>;
  onAutoDrawRequest?: (drawData: any) => void;  // AI自动绘图回调
  messages?: ChatMessage[];  // 外部传入的历史消息
  onMessagesChange?: (messages: ChatMessage[]) => void;  // 消息更新回调
}

const ChatPanel = ({ videoId, videoRef, onAutoDrawRequest, messages: externalMessages, onMessagesChange }: Props) => {
  // 使用内部状态管理messages，初始值来自外部
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [status, setStatus] = useState<string>('idle');
  const [textInput, setTextInput] = useState<string>(''); // 文字输入框内容

  // 调试配置（统一管理）
  const [debugConfig, setDebugConfig] = useState({
    ragEnabled: true,
    ragMode: 'vector' as 'vector' | 'bm25' | 'hybrid',
    llmModel: 'gpt-4o-mini',
    voiceService: 'xfyun'
  });
  const [availableModels, setAvailableModels] = useState<Array<{id: string, name: string, provider: string}>>([]);

  const reconnectAttemptsRef = useRef<number>(0); // 重连尝试次数
  const maxReconnectAttempts = 5; // 最大重连次数

  // 🧪 OpenAI Realtime 测试模式
  const [testMode, setTestMode] = useState<'websocket' | 'realtime'>('websocket'); // 默认使用现有WebSocket
  const {
    isConnected: realtimeConnected,
    isListening: realtimeListening,
    isSpeaking: realtimeSpeaking,
    connect: realtimeConnect,
    startListening: realtimeStartListening,
    stopListening: realtimeStopListening,
    disconnect: realtimeDisconnect,
  } = useRealtimeVoice({
    videoContext: '', // 暂不传视频上下文
    videoId,
    currentTime: videoRef.current?.currentTime,
    onTranscript: (text, isFinal) => {
      if (isFinal) {
        console.log('👤 用户说:', text);
        setMessages(prev => [...prev, {
          type: 'text',
          content: text,
          role: 'user'
        }]);
      }
    },
    onAnswer: (text) => {
      console.log('🤖 AI说:', text);
      // 流式文本显示（追加到最后一条assistant消息）
      setMessages(prev => {
        const last = prev[prev.length - 1];
        if (last?.role === 'assistant') {
          return [...prev.slice(0, -1), {
            ...last,
            content: (last.content || '') + text
          }];
        } else {
          return [...prev, {
            type: 'text',
            content: text,
            role: 'assistant'
          }];
        }
      });
    },
    onComplete: () => {
      console.log('✅ Realtime 对话完成');
    }
  });

  // 仅在初始化时加载外部messages
  useEffect(() => {
    if (externalMessages && externalMessages.length > 0) {
      setMessages(externalMessages);
    }
  }, []); // 空依赖数组，只在mount时执行

  // 当messages变化时通知父组件（使用ref避免循环依赖）
  const onMessagesChangeRef = useRef(onMessagesChange);
  useEffect(() => {
    onMessagesChangeRef.current = onMessagesChange;
  }, [onMessagesChange]);

  useEffect(() => {
    if (onMessagesChangeRef.current) {
      onMessagesChangeRef.current(messages);
    }
  }, [messages]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const audioChunksRef = useRef<Float32Array[]>([]);
  const processingTimeoutRef = useRef<number | null>(null);
  const receivedAudioChunksRef = useRef<ArrayBuffer[]>([]);
  const currentAudioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const progressIntervalRef = useRef<number | null>(null); // 进度更新定时器

  // 组件加载时初始化可用模型列表
  useEffect(() => {
    // 设置默认可用模型列表
    setAvailableModels([
      {"id": "gpt-4o-mini", "name": "GPT-4o Mini (主站)", "provider": "OpenAI"},
      {"id": "gpt-4o-mini-副站", "name": "GPT-4o Mini (副站)", "provider": "OpenAI"},
      {"id": "gpt-4o", "name": "GPT-4o", "provider": "OpenAI"},
      {"id": "claude-3-5-sonnet", "name": "Claude 3.5 Sonnet", "provider": "Anthropic"},
      {"id": "claude-3-5-haiku", "name": "Claude 3.5 Haiku", "provider": "Anthropic"},
      {"id": "deepseek-chat", "name": "DeepSeek Chat", "provider": "DeepSeek"},
      {"id": "deepseek-reasoner", "name": "DeepSeek Reasoner (推理)", "provider": "DeepSeek"}
    ]);
  }, []);

  // 自动滚动到底部
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'auto' }); // 改为auto避免动画抖动
  };

  useEffect(() => {
    // 延迟滚动，避免在消息渲染过程中多次触发
    const timer = setTimeout(scrollToBottom, 50);
    return () => clearTimeout(timer);
  }, [messages]);

  // 监听视频播放事件，播放时停止AI音频
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleVideoPlay = () => {
      console.log('📹 视频开始播放，停止AI音频');
      stopAIAudio();
    };

    video.addEventListener('play', handleVideoPlay);

    return () => {
      video.removeEventListener('play', handleVideoPlay);
    };
  }, [videoRef]);

  // 发送观看进度（每10秒）
  useEffect(() => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && videoRef.current) {
      // 清除之前的定时器
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }

      // 每10秒发送一次进度
      progressIntervalRef.current = setInterval(() => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && videoRef.current) {
          const currentTime = videoRef.current.currentTime;
          const duration = videoRef.current.duration;

          wsRef.current.send(JSON.stringify({
            command: 'update_progress',
            data: {
              current_time: currentTime,
              duration: duration
            }
          }));

          console.log(`📊 发送进度: ${currentTime.toFixed(1)}s / ${duration.toFixed(1)}s`);
        }
      }, 10000); // 10秒
    }

    // 清理
    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
        progressIntervalRef.current = null;
      }
    };
  }, [videoRef]);

  // 停止AI音频播放
  const stopAIAudio = () => {
    if (currentAudioSourceRef.current) {
      try {
        currentAudioSourceRef.current.stop();
        console.log('🔇 AI音频已停止');
      } catch (e) {
        // 音频可能已经停止
      }
      currentAudioSourceRef.current = null;
    }
  };

  // 处理调试配置变更（统一处理）
  const handleDebugConfigChange = (newConfig: typeof debugConfig) => {
    console.log('🎯 ===== ChatPanel：接收配置变更 =====');
    const prevConfig = debugConfig;
    setDebugConfig(newConfig);

    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      console.warn('⚠️ WebSocket未连接，配置将在下次连接时生效');
      console.log('💾 配置已保存到本地state，等待WebSocket连接后同步');
      console.log('🎯 ===================================');
      return;
    }

    console.log('✅ WebSocket已连接，开始同步配置到后端');

    // RAG开关变化
    if (newConfig.ragEnabled !== prevConfig.ragEnabled) {
      const cmd = {
        command: 'set_rag',
        data: { enabled: newConfig.ragEnabled }
      };
      wsRef.current.send(JSON.stringify(cmd));
      console.log(`📤 发送命令: set_rag`);
      console.log(`   ├─ 状态: ${prevConfig.ragEnabled ? '启用' : '禁用'} → ${newConfig.ragEnabled ? '启用' : '禁用'}`);
      console.log(`   └─ 数据:`, cmd.data);
    }

    // RAG检索模式变化
    if (newConfig.ragMode !== prevConfig.ragMode) {
      const cmd = {
        command: 'set_rag_mode',
        data: { mode: newConfig.ragMode }
      };
      wsRef.current.send(JSON.stringify(cmd));
      console.log(`📤 发送命令: set_rag_mode`);
      console.log(`   ├─ 模式: ${prevConfig.ragMode} → ${newConfig.ragMode}`);
      console.log(`   └─ 数据:`, cmd.data);
    }

    // LLM模型变化
    if (newConfig.llmModel !== prevConfig.llmModel) {
      const cmd = {
        command: 'set_model',
        data: { model: newConfig.llmModel }
      };
      wsRef.current.send(JSON.stringify(cmd));
      console.log(`📤 发送命令: set_model`);
      console.log(`   ├─ 模型: ${prevConfig.llmModel} → ${newConfig.llmModel}`);
      console.log(`   └─ 数据:`, cmd.data);
    }

    // 语音服务变化
    if (newConfig.voiceService !== prevConfig.voiceService) {
      console.log(`📤 语音服务切换: ${prevConfig.voiceService} → ${newConfig.voiceService}`);
      console.log(`   └─ 需要断开WebSocket并调用HTTP API`);
      // 切换语音服务需要断开重连
      switchVoiceService(newConfig.voiceService);
    }

    console.log('🎯 ===================================');
  };

  // 切换语音服务
  const switchVoiceService = async (serviceId: string) => {
    console.log('🎤 ===== 切换语音服务 =====');
    console.log(`🎤 目标服务: ${serviceId}`);

    // 如果WebSocket已连接，通过WebSocket发送切换命令
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      console.log('📡 通过WebSocket发送切换命令');

      const cmd = {
        command: 'set_voice_service',
        data: { service_id: serviceId }
      };

      wsRef.current.send(JSON.stringify(cmd));
      console.log('   命令已发送:', cmd);

      // 等待后端确认（通过监听 voice_service_status 消息）
      console.log('⏳ 等待后端确认...');

    } else {
      // WebSocket未连接，调用HTTP API并更新全局配置
      console.log('📡 WebSocket未连接，调用HTTP API');

      try {
        const requestBody = { service_type: serviceId };
        console.log('   请求体:', requestBody);

        const response = await fetch('http://localhost:8000/api/voice-services/switch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody),
        });

        console.log(`📡 响应状态: ${response.status} ${response.statusText}`);

        if (!response.ok) {
          const errorData = await response.json();
          console.error('❌ 后端返回错误:', errorData);
          throw new Error(errorData.detail || '切换失败');
        }

        const result = await response.json();
        console.log('✅ 后端响应成功:', result);
        console.log('✅ 语音服务已切换至:', serviceId);

        // 更新本地配置
        setDebugConfig(prev => ({...prev, voiceService: serviceId}));

        alert(`✅ ${result.message}\n下次连接时将使用新的语音服务`);
      } catch (err: any) {
        console.error('❌ 切换失败:', err);
        alert(`❌ 切换失败: ${err.message}`);
      }
    }

    console.log('🎤 ========================');
  };

  // 连接WebSocket
  const connectWebSocket = () => {
    // 从localStorage获取token
    const token = localStorage.getItem('token');
    const wsUrl = token
      ? `ws://localhost:8000/api/ws/chat/${videoId}?token=${token}`
      : `ws://localhost:8000/api/ws/chat/${videoId}`;

    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log('✅ ===== WebSocket连接成功 =====');
      setStatus('connected');
      reconnectAttemptsRef.current = 0; // 重置重连计数

      // 连接成功后同步调试配置
      console.log('🔄 同步当前调试配置到后端:');
      console.log('   当前配置:', {
        'LLM模型': debugConfig.llmModel,
        'RAG启用': debugConfig.ragEnabled,
        'RAG检索模式': debugConfig.ragMode,
        '语音服务': debugConfig.voiceService
      });

      const modelCmd = {
        command: 'set_model',
        data: { model: debugConfig.llmModel }
      };
      ws.send(JSON.stringify(modelCmd));
      console.log('   ✓ 发送 set_model:', modelCmd.data);

      const ragCmd = {
        command: 'set_rag',
        data: { enabled: debugConfig.ragEnabled }
      };
      ws.send(JSON.stringify(ragCmd));
      console.log('   ✓ 发送 set_rag:', ragCmd.data);

      const ragModeCmd = {
        command: 'set_rag_mode',
        data: { mode: debugConfig.ragMode }
      };
      ws.send(JSON.stringify(ragModeCmd));
      console.log('   ✓ 发送 set_rag_mode:', ragModeCmd.data);

      // 同步语音服务配置
      const voiceServiceCmd = {
        command: 'set_voice_service',
        data: { service_id: debugConfig.voiceService }
      };
      ws.send(JSON.stringify(voiceServiceCmd));
      console.log('   ✓ 发送 set_voice_service:', voiceServiceCmd.data);

      console.log('✅ 配置同步完成');
      console.log('✅ ============================');
    };

    ws.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        // JSON消息
        const msg = JSON.parse(event.data);
        console.log('收到消息:', msg);

        switch (msg.type) {
          case 'ping':
            // 心跳检测，响应pong
            if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
              wsRef.current.send(JSON.stringify({ command: 'pong' }));
            }
            break;

          case 'auto_draw':
            // AI自动绘图指令
            console.log('🎨 收到自动绘图指令:', msg.data);
            console.log('🎨 画板类型:', msg.data.board_type);
            console.log('🎨 表达式列表:', msg.data.expressions);
            if (onAutoDrawRequest) {
              onAutoDrawRequest(msg.data);
              console.log('✅ 绘图指令已传递给App组件');
            } else {
              console.warn('⚠️ onAutoDrawRequest回调未定义');
            }
            break;

          case 'asr_result':
            // 清除超时
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示用户问题
            setMessages(prev => [...prev, {
              type: 'text',
              content: msg.data,
              role: 'user'
            }]);
            setStatus('thinking');
            // 清空之前的音频块
            receivedAudioChunksRef.current = [];
            break;

          case 'ai_response':
            // 清除超时
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示AI回答文本
            const text = msg.data;

            // 解析文本中的LaTeX公式（$$...$$）
            const parts = text.split(/(\$\$.*?\$\$)/g);

            parts.forEach((part: string) => {
              if (part.startsWith('$$') && part.endsWith('$$')) {
                // LaTeX公式
                const latex = part.slice(2, -2);
                setMessages(prev => [...prev, {
                  type: 'latex',
                  content: latex
                }]);
              } else if (part.trim()) {
                // 普通文本
                setMessages(prev => [...prev, {
                  type: 'text',
                  content: part,
                  role: 'assistant'
                }]);
              }
            });
            setStatus('playing');
            break;

          case 'text_response':
            // 文字问答回复（无音频）
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示AI回答文本
            const textResponse = msg.data;

            // 解析文本中的LaTeX公式（$$...$$）
            const textParts = textResponse.split(/(\$\$.*?\$\$)/g);

            textParts.forEach((part: string) => {
              if (part.startsWith('$$') && part.endsWith('$$')) {
                // LaTeX公式
                const latex = part.slice(2, -2);
                setMessages(prev => [...prev, {
                  type: 'latex',
                  content: latex
                }]);
              } else if (part.trim()) {
                // 普通文本
                setMessages(prev => [...prev, {
                  type: 'text',
                  content: part,
                  role: 'assistant'
                }]);
              }
            });
            setStatus('connected');
            break;

          case 'audio_complete':
            // 所有音频块接收完毕，开始播放
            console.log(`✅ 接收到${receivedAudioChunksRef.current.length}个音频块`);
            if (receivedAudioChunksRef.current.length > 0) {
              await playAllAudioChunks();
            }
            setStatus('connected');
            setIsListening(false);
            break;

          case 'error':
            console.error('错误:', msg.data);
            setMessages(prev => [...prev, {
              type: 'text',
              content: `❌ 错误: ${msg.data}`,
              role: 'assistant'
            }]);
            setStatus('error');
            setIsListening(false);
            break;

          case 'rag_status':
            // 接收RAG状态
            console.log('📥 收到后端响应: rag_status');
            const ragStatus = msg.data;
            console.log('   数据:', ragStatus);
            setDebugConfig(prev => ({...prev, ragEnabled: ragStatus.enabled}));
            console.log(`✅ RAG状态已确认: ${ragStatus.enabled ? '✓ 启用' : '✗ 禁用'}`);
            break;

          case 'model_status':
            // 接收模型状态
            console.log('📥 收到后端响应: model_status');
            const modelStatus = msg.data;
            console.log('   数据:', modelStatus);
            setDebugConfig(prev => ({...prev, llmModel: modelStatus.current_model}));
            if (modelStatus.available_models) {
              setAvailableModels(modelStatus.available_models);
              console.log(`   可用模型数: ${modelStatus.available_models.length}`);
            }
            console.log(`✅ LLM模型已确认: ${modelStatus.current_model}`);
            break;

          case 'rag_mode_status':
            // 接收RAG模式状态
            console.log('📥 收到后端响应: rag_mode_status');
            const ragModeStatus = msg.data;
            console.log('   数据:', ragModeStatus);
            setDebugConfig(prev => ({...prev, ragMode: ragModeStatus.mode}));
            console.log(`✅ RAG检索模式已确认: ${ragModeStatus.mode}`);
            break;

          case 'voice_service_status':
            // 接收语音服务切换状态
            console.log('📥 收到后端响应: voice_service_status');
            const voiceStatus = msg.data;
            console.log('   数据:', voiceStatus);

            if (voiceStatus.success) {
              console.log(`✅ 语音服务切换成功: ${voiceStatus.current_service}`);
              setDebugConfig(prev => ({...prev, voiceService: voiceStatus.current_service}));
              alert(`✅ ${voiceStatus.message}`);
            } else {
              console.error(`❌ 语音服务切换失败: ${voiceStatus.error}`);
              alert(`❌ 切换失败: ${voiceStatus.error}\n\n请检查该服务的API密钥配置`);
            }
            break;
        }
      } else {
        // 音频数据（二进制）
        const audioData = await event.data.arrayBuffer();
        console.log(`收到音频块: ${audioData.byteLength} 字节`);
        // 收集音频块，不立即播放
        receivedAudioChunksRef.current.push(audioData);
      }
    };

    ws.onerror = (error) => {
      console.error('❌ WebSocket错误:', error);
      setStatus('error');
    };

    ws.onclose = (event) => {
      console.log('WebSocket连接关闭, code:', event.code, 'reason:', event.reason);
      setStatus('idle');
      wsRef.current = null;

      // 自动重连（非正常关闭且未超过最大重连次数）
      if (event.code !== 1000 && reconnectAttemptsRef.current < maxReconnectAttempts) {
        reconnectAttemptsRef.current += 1;
        const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current - 1), 10000); // 指数退避
        console.log(`🔄 ${delay}ms后尝试第${reconnectAttemptsRef.current}次重连...`);
        setTimeout(() => {
          if (!wsRef.current || wsRef.current.readyState === WebSocket.CLOSED) {
            connectWebSocket();
          }
        }, delay);
      } else if (reconnectAttemptsRef.current >= maxReconnectAttempts) {
        console.error('❌ 达到最大重连次数，请刷新页面');
        setMessages(prev => [...prev, {
          type: 'text',
          content: '⚠️ 连接已断开，请刷新页面重试',
          role: 'assistant'
        }]);
      }
    };

    wsRef.current = ws;
  };

  // 播放所有音频块
  const playAllAudioChunks = async () => {
    if (receivedAudioChunksRef.current.length === 0) {
      console.warn('⚠️ 没有音频数据');
      return;
    }

    // 计算总长度
    const totalBytes = receivedAudioChunksRef.current.reduce((acc, chunk) => acc + chunk.byteLength, 0);
    console.log(`🎵 准备播放: ${receivedAudioChunksRef.current.length}个块, 总计${totalBytes}字节`);

    // 合并所有音频块
    const combined = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of receivedAudioChunksRef.current) {
      combined.set(new Uint8Array(chunk), offset);
      offset += chunk.byteLength;
    }

    // 创建AudioContext
    if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
      audioContextRef.current = new AudioContext({ sampleRate: 16000 });
    }
    const audioContext = audioContextRef.current;

    // 将PCM数据转换为AudioBuffer
    const audioBuffer = audioContext.createBuffer(1, combined.length / 2, 16000);
    const channelData = audioBuffer.getChannelData(0);
    const view = new DataView(combined.buffer);

    for (let i = 0; i < channelData.length; i++) {
      // PCM 16位有符号整数转换为浮点数
      channelData[i] = view.getInt16(i * 2, true) / 32768.0;
    }

    // 停止之前的音频（如果有）
    stopAIAudio();

    // 播放
    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContext.destination);

    // 保存引用以便后续停止
    currentAudioSourceRef.current = source;

    // 播放结束时清除引用
    source.onended = () => {
      currentAudioSourceRef.current = null;
      console.log('✅ AI音频播放完成');
    };

    source.start();

    console.log('▶️ 开始播放音频');
  };

  // 开始录音
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      mediaStreamRef.current = stream;

      // 创建AudioContext
      const audioContext = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      // 清空音频块
      audioChunksRef.current = [];

      // 处理音频数据
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        // 复制数据
        const chunk = new Float32Array(inputData.length);
        chunk.set(inputData);
        audioChunksRef.current.push(chunk);
      };

      source.connect(processor);
      processor.connect(audioContext.destination);

      console.log('🎤 开始录音(PCM格式)...');
      setStatus('recording');
    } catch (error) {
      console.error('麦克风访问失败:', error);
      alert('无法访问麦克风，请检查浏览器权限设置');
      setIsListening(false);
    }
  };

  // 停止录音
  const stopRecording = () => {
    console.log('🛑 停止录音');

    // 停止处理器
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }

    // 关闭AudioContext
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    // 停止媒体流
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    // 发送音频数据到服务器
    console.log('WebSocket状态:', wsRef.current?.readyState);
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      // 合并所有Float32数据
      const totalLength = audioChunksRef.current.reduce((acc, arr) => acc + arr.length, 0);
      console.log(`音频块数量: ${audioChunksRef.current.length}, 总长度: ${totalLength}`);

      const combined = new Float32Array(totalLength);
      let offset = 0;
      for (const chunk of audioChunksRef.current) {
        combined.set(chunk, offset);
        offset += chunk.length;
      }

      // 转换为16位PCM
      const pcm16 = new Int16Array(combined.length);
      for (let i = 0; i < combined.length; i++) {
        const s = Math.max(-1, Math.min(1, combined[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }

      console.log(`发送PCM音频: ${pcm16.byteLength} 字节`);

      // 发送音频数据
      try {
        wsRef.current.send(pcm16.buffer);
        console.log('✅ 音频数据发送成功');
        setStatus('processing');

        // 设置30秒超时
        if (processingTimeoutRef.current) {
          clearTimeout(processingTimeoutRef.current);
        }
        processingTimeoutRef.current = setTimeout(() => {
          console.warn('⏱️ 处理超时');
          setStatus('connected');
          setMessages(prev => [...prev, {
            type: 'text',
            content: '⏱️ 处理超时，请重试',
            role: 'assistant'
          }]);
        }, 30000);
      } catch (error) {
        console.error('❌ 发送音频失败:', error);
        setStatus('error');
      }
    } else {
      console.error('❌ WebSocket未连接或已关闭');
      setStatus('error');
    }
  };

  // 处理文字提交
  const handleTextSubmit = () => {
    if (!textInput.trim()) return;

    // 暂停视频
    if (videoRef.current && !videoRef.current.paused) {
      videoRef.current.pause();
      console.log('视频已暂停');
    }

    // 连接WebSocket（如果未连接）
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      connectWebSocket();
      // 等待连接后发送
      setTimeout(() => {
        sendTextQuestion();
      }, 500);
    } else {
      sendTextQuestion();
    }
  };

  // 发送文字问题
  const sendTextQuestion = () => {
    if (!textInput.trim() || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    try {
      // 显示用户问题
      setMessages(prev => [...prev, {
        type: 'text',
        content: textInput,
        role: 'user'
      }]);

      // 获取当前视频时间点
      const questionTime = videoRef.current ? videoRef.current.currentTime : null;

      // 发送文字问题到后端（包含视频时间点）
      wsRef.current.send(JSON.stringify({
        command: 'text_question',
        data: {
          question: textInput,
          question_time: questionTime
        }
      }));

      console.log('发送文字问题:', textInput, '时间点:', questionTime);
      setStatus('thinking');
      setTextInput(''); // 清空输入框

      // 设置超时
      if (processingTimeoutRef.current) {
        clearTimeout(processingTimeoutRef.current);
      }
      processingTimeoutRef.current = setTimeout(() => {
        console.warn('处理超时');
        setStatus('connected');
        setMessages(prev => [...prev, {
          type: 'text',
          content: '处理超时，请重试',
          role: 'assistant'
        }]);
      }, 60000);  // 增加到60秒
    } catch (error) {
      console.error('发送文字问题失败:', error);
      setStatus('error');
    }
  };

  // 处理提问按钮点击
  const handleAskClick = () => {
    if (testMode === 'realtime') {
      // 🧪 Realtime 模式
      handleRealtimeAsk();
    } else {
      // 原有 WebSocket 模式
      handleWebSocketAsk();
    }
  };

  // Realtime 模式提问
  const handleRealtimeAsk = async () => {
    if (!realtimeListening) {
      // 暂停视频
      if (videoRef.current && !videoRef.current.paused) {
        videoRef.current.pause();
        console.log('视频已暂停');
      }

      // 连接 Realtime（如果未连接）
      if (!realtimeConnected) {
        await realtimeConnect();
        // 等待连接完成
        setTimeout(() => {
          realtimeStartListening();
        }, 500);
      } else {
        // 开始录音
        realtimeStartListening();
      }
    } else {
      // 停止录音（Realtime 使用 VAD 自动检测说话结束，所以不需要手动停止）
      // 但用户点击了停止按钮，我们还是响应
      realtimeStopListening();
    }
  };

  // WebSocket 模式提问（原逻辑）
  const handleWebSocketAsk = () => {
    if (!isListening) {
      // 开始提问 - 暂停视频
      if (videoRef.current && !videoRef.current.paused) {
        videoRef.current.pause();
        console.log('视频已暂停');
      }

      // 开始提问
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        connectWebSocket();
        // 等待连接成功后再开始录音
        setTimeout(() => {
          startRecording();
          setIsListening(true);
        }, 500);
      } else {
        startRecording();
        setIsListening(true);
      }
    } else {
      // 停止提问
      stopRecording();
      setIsListening(false);
    }
  };

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (processorRef.current) {
        processorRef.current.disconnect();
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (processingTimeoutRef.current) {
        clearTimeout(processingTimeoutRef.current);
      }
      // 停止AI音频
      stopAIAudio();
      // 断开Realtime
      realtimeDisconnect();
    };
  }, [realtimeDisconnect]);

  const renderLatex = (latex: string) => {
    try {
      const html = katex.renderToString(latex, {
        throwOnError: false,
        displayMode: true
      });
      return <div dangerouslySetInnerHTML={{ __html: html }} className="latex-block" />;
    } catch (e) {
      return <div className="latex-error">LaTeX渲染错误</div>;
    }
  };

  // 状态显示文本
  const getStatusText = () => {
    switch (status) {
      case 'recording':
        return '🎤 正在录音...';
      case 'processing':
        return '🔄 识别中...';
      case 'thinking':
        return '💭 AI思考中...';
      case 'playing':
        return '🔊 播放中...';
      case 'error':
        return '❌ 出错了';
      default:
        return '';
    }
  };

  return (
    <div className="chat-panel">
      {/* 调试控制台 */}
      <DebugConsole
        currentConfig={debugConfig}
        availableModels={availableModels}
        onConfigChange={handleDebugConfigChange}
      />

      <div className="chat-header">
        <div className="header-left">
          <h3>💬 问答区</h3>
          <span className="video-id">视频 ID: {videoId.slice(0, 8)}...</span>
        </div>
        {/* 🧪 测试模式切换 */}
        <div className="test-mode-switcher">
          <label>
            <input
              type="radio"
              value="websocket"
              checked={testMode === 'websocket'}
              onChange={(e) => setTestMode(e.target.value as 'websocket' | 'realtime')}
            />
            WebSocket
          </label>
          <label>
            <input
              type="radio"
              value="realtime"
              checked={testMode === 'realtime'}
              onChange={(e) => setTestMode(e.target.value as 'websocket' | 'realtime')}
            />
            🧪 OpenAI Realtime
          </label>
          {testMode === 'realtime' && (
            <span className="realtime-status">
              {realtimeConnected ? '🟢 已连接' : '🔴 未连接'}
            </span>
          )}
        </div>
      </div>

      {status !== 'idle' && status !== 'connected' && (
        <div className="status-indicator">{getStatusText()}</div>
      )}

      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="empty-state">
            <p>👋 点击下方"提问"按钮</p>
            <p>随时向AI老师提问！</p>
          </div>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`message ${msg.role || 'system'}`}>
              {msg.type === 'text' && (
                <div className="message-content">
                  <span className="message-role">
                    {msg.role === 'user' ? '👤 学生' : '🤖 AI老师'}
                  </span>
                  <p>{msg.content}</p>
                </div>
              )}
              {msg.type === 'latex' && renderLatex(msg.content || '')}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="chat-controls">
        {/* 文字输入区域 */}
        <div className="text-input-container">
          <input
            type="text"
            className="text-input"
            placeholder="输入问题..."
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && textInput.trim()) {
                handleTextSubmit();
              }
            }}
            disabled={status === 'processing' || status === 'thinking'}
          />
          <button
            className="text-submit-button"
            onClick={handleTextSubmit}
            disabled={!textInput.trim() || status === 'processing' || status === 'thinking'}
          >
            发送
          </button>
        </div>

        <button
          className={`ask-button ${(isListening || realtimeListening) ? 'listening' : ''}`}
          onClick={handleAskClick}
          disabled={status === 'processing' || status === 'thinking'}
        >
          {testMode === 'realtime'
            ? (realtimeListening ? '🛑 停止提问 (Realtime)' : '🎤 提问 (Realtime)')
            : (isListening ? '🛑 停止提问' : '🎤 提问')
          }
        </button>
      </div>
    </div>
  );
};

export default ChatPanel;
