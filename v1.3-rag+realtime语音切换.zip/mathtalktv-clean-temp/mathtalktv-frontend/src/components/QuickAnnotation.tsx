import { useRef, useState, useEffect, RefObject } from 'react';
import './QuickAnnotation.css';

interface QuickAnnotationProps {
  videoRef?: RefObject<HTMLVideoElement | null>;
  containerRef?: RefObject<HTMLDivElement | null>;  // 新增：支持画板容器
  isActive: boolean;
  onClose: () => void;
  pauseVideo?: boolean;  // 新增：是否需要暂停视频（默认 true）
}

interface Point {
  x: number;
  y: number;
}

export function QuickAnnotation({ videoRef, containerRef, isActive, onClose: _onClose, pauseVideo: _pauseVideo = true }: QuickAnnotationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState('#FF0000');
  const [lineWidth, setLineWidth] = useState(3);
  const [tool, setTool] = useState<'pen' | 'eraser'>('pen');
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyStep, setHistoryStep] = useState(-1);
  const [toolbarVisible, setToolbarVisible] = useState(true);
  const hideTimeoutRef = useRef<number | null>(null);
  const toolbarRef = useRef<HTMLDivElement>(null);

  // 自动隐藏工具栏
  const scheduleHide = () => {
    if (hideTimeoutRef.current) {
      clearTimeout(hideTimeoutRef.current);
    }
    setToolbarVisible(true);
    hideTimeoutRef.current = window.setTimeout(() => {
      setToolbarVisible(false);
    }, 3000);
  };

  // 鼠标移动到工具栏或✏️按钮时显示
  const handleToolbarMouseEnter = () => {
    if (hideTimeoutRef.current) {
      clearTimeout(hideTimeoutRef.current);
    }
    setToolbarVisible(true);
  };

  const handleToolbarMouseLeave = () => {
    scheduleHide();
  };

  useEffect(() => {
    if (isActive) {
      scheduleHide(); // 初始显示3秒后淡出
    } else {
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
      }
      setToolbarVisible(true);
    }

    return () => {
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
      }
    };
  }, [isActive]);

  useEffect(() => {
    if (!isActive || !canvasRef.current) return;

    const canvas = canvasRef.current;

    // 获取目标容器（视频或画板）
    const targetElement = videoRef?.current || containerRef?.current;
    if (!targetElement) return;

    // 设置canvas尺寸与目标容器相同
    const rect = targetElement.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;

    // 不再自动暂停视频，让用户自己控制

    // 初始化历史
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setHistory([imageData]);
      setHistoryStep(0);
    }
  }, [isActive, videoRef, containerRef]);

  const saveHistory = () => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
    const newHistory = history.slice(0, historyStep + 1);
    newHistory.push(imageData);
    setHistory(newHistory);
    setHistoryStep(newHistory.length - 1);
  };

  const undo = () => {
    if (historyStep > 0 && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;

      setHistoryStep(historyStep - 1);
      ctx.putImageData(history[historyStep - 1], 0, 0);
    }
  };

  const clearCanvas = () => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    saveHistory();
  };

  const getPointerPosition = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>): Point => {
    if (!canvasRef.current) return { x: 0, y: 0 };

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();

    // 获取Canvas的缩放比例
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if ('touches' in e) {
      const touch = e.touches[0];
      return {
        x: (touch.clientX - rect.left) * scaleX,
        y: (touch.clientY - rect.top) * scaleY
      };
    } else {
      return {
        x: (e.clientX - rect.left) * scaleX,
        y: (e.clientY - rect.top) * scaleY
      };
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    setIsDrawing(true);

    const pos = getPointerPosition(e);
    if (!canvasRef.current) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (!isDrawing || !canvasRef.current) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const pos = getPointerPosition(e);

    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = tool === 'eraser' ? '#FFFFFF' : color;
    ctx.lineWidth = tool === 'eraser' ? lineWidth * 3 : lineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      saveHistory();
    }
  };

  if (!isActive) return null;

  return (
    <div className="quick-annotation-overlay">
      <div
        ref={toolbarRef}
        className={`annotation-toolbar ${toolbarVisible ? 'visible' : 'hidden'}`}
        onMouseEnter={handleToolbarMouseEnter}
        onMouseLeave={handleToolbarMouseLeave}
      >
        <div className="toolbar-group">
          <button
            className={`tool-btn ${tool === 'pen' ? 'active' : ''}`}
            onClick={() => setTool('pen')}
            title="画笔"
          >
            ✏️ 画笔
          </button>
          <button
            className={`tool-btn ${tool === 'eraser' ? 'active' : ''}`}
            onClick={() => setTool('eraser')}
            title="橡皮擦"
          >
            🧹 橡皮
          </button>
        </div>

        <div className="toolbar-group">
          <label className="color-label">
            颜色:
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="color-picker"
            />
          </label>

          <label className="width-label">
            粗细:
            <input
              type="range"
              min="1"
              max="10"
              value={lineWidth}
              onChange={(e) => setLineWidth(Number(e.target.value))}
              className="width-slider"
            />
            <span>{lineWidth}</span>
          </label>
        </div>

        <div className="toolbar-group">
          <button
            className="tool-btn"
            onClick={undo}
            disabled={historyStep <= 0}
            title="撤销"
          >
            ↶ 撤销
          </button>
          <button
            className="tool-btn"
            onClick={clearCanvas}
            title="清空"
          >
            🗑️ 清空
          </button>
        </div>
      </div>

      <canvas
        ref={canvasRef}
        className="annotation-canvas"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={stopDrawing}
      />

      <div className="annotation-hint">
        💡 提示: 在画面上绘制标注，点击✏️按钮关闭画笔，空格键暂停视频
      </div>
    </div>
  );
}
