import { useEffect, useRef, useState } from 'react';
import './DesmosBoard.css';

interface DesmosBoardProps {
  onReady?: (calculator: any) => void;
  onClose?: () => void;
}

export function DesmosBoard({ onReady, onClose }: DesmosBoardProps) {
  const calculatorRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);  // 新增：容器引用
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // 检查Desmos是否已加载
    if ((window as any).Desmos) {
      // 延迟初始化，等待容器布局完成
      setTimeout(() => initCalculator(), 100);
      return;
    }

    // 加载Desmos脚本
    const script = document.createElement('script');
    script.src = 'https://www.desmos.com/api/v1.8/calculator.js?apiKey=dcb31709b452b1cf9dc26972add0fda6';
    script.async = true;

    script.onload = () => {
      // 延迟初始化，等待容器布局完成
      setTimeout(() => initCalculator(), 100);
    };

    script.onerror = () => {
      console.error('Failed to load Desmos API');
      setIsLoading(false);
    };

    document.body.appendChild(script);

    return () => {
      // 清理calculator实例
      if (calculatorRef.current) {
        try {
          calculatorRef.current.destroy();
        } catch (e) {
          console.error('Error destroying calculator:', e);
        }
      }
    };
  }, []);

  const initCalculator = () => {
    try {
      const elt = document.getElementById('desmos-calculator');
      if (!elt) {
        console.error('❌ Desmos容器元素未找到');
        return;
      }

      // 检查容器尺寸
      const rect = elt.getBoundingClientRect();
      console.log('📐 Desmos容器尺寸:', {
        width: rect.width,
        height: rect.height,
        top: rect.top,
        left: rect.left
      });

      if (rect.width === 0 || rect.height === 0) {
        console.error('❌ Desmos容器尺寸为0，画板无法显示！');
        console.error('📐 父容器尺寸:', elt.parentElement?.getBoundingClientRect());
      }

      console.log('🎨 开始初始化Desmos画板...');
      calculatorRef.current = (window as any).Desmos.GraphingCalculator(elt, {
        keypad: false,
        expressions: true,  // 改为true，显示表达式列表
        settingsMenu: false,
        zoomButtons: true,
        expressionsTopbar: true,  // 改为true，显示顶部工具栏
        border: false,
        lockViewport: false
      });

      console.log('✅ Desmos画板初始化完成', calculatorRef.current);
      setIsLoading(false);

      // 测试：添加一个默认表达式验证画板工作
      console.log('🧪 测试：添加默认表达式 y=0');
      calculatorRef.current.setExpression({ id: 'test', latex: 'y=0', color: '#888888' });

      if (onReady) {
        console.log('📞 调用onReady回调...');
        onReady(calculatorRef.current);
      } else {
        console.warn('⚠️ onReady回调未定义');
      }
    } catch (e) {
      console.error('❌ Desmos初始化失败:', e);
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    if (calculatorRef.current) {
      calculatorRef.current.setBlank();
    }
  };

  const handleScreenshot = () => {
    if (calculatorRef.current) {
      calculatorRef.current.screenshot({
        width: 1200,
        height: 800,
        targetPixelRatio: 2
      }, (data: string) => {
        // 下载截图
        const link = document.createElement('a');
        link.href = data;
        link.download = `desmos-${Date.now()}.png`;
        link.click();
      });
    }
  };

  const handleAddFunction = () => {
    if (calculatorRef.current) {
      const latex = prompt('输入函数表达式 (例如: y=x^2):');
      if (latex) {
        console.log('🔧 手动添加函数:', latex);
        calculatorRef.current.setExpression({
          id: `func-${Date.now()}`,
          latex: latex
        });
        console.log('✅ 手动添加成功');

        // 检查状态
        const state = calculatorRef.current.getState();
        console.log('📊 当前画板状态:', state);
      }
    } else {
      console.error('❌ Calculator未初始化');
    }
  };

  return (
    <div className="desmos-board">
      <div className="desmos-header">
        <h3>📐 Desmos 画板</h3>
        <button className="close-button" onClick={onClose}>✕</button>
      </div>

      <div className="desmos-toolbar">
        <button className="toolbar-btn" onClick={handleAddFunction} title="添加函数">
          ƒ(x) 函数
        </button>
        <button className="toolbar-btn" onClick={handleClear} title="清空画板">
          🗑️ 清空
        </button>
        <button className="toolbar-btn" onClick={handleScreenshot} title="截图">
          📷 截图
        </button>
      </div>

      {isLoading && (
        <div className="desmos-loading">
          <div className="spinner"></div>
          <p>正在加载 Desmos...</p>
        </div>
      )}

      <div className="desmos-container-wrapper" style={{ position: 'relative' }}>
        <div
          ref={containerRef}
          id="desmos-calculator"
          className="desmos-calculator"
          style={{ display: isLoading ? 'none' : 'block' }}
        />
      </div>
    </div>
  );
}
