import axios from 'axios';

// API基础URL
const API_BASE_URL = 'http://localhost:8000/api';

// 创建axios实例
export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 300000, // 5分钟（视频处理可能较慢）
  headers: {
    'Content-Type': 'application/json',
  },
});

// 视频相关API
export const videoApi = {
  // 获取视频列表
  getVideosList: async () => {
    const response = await apiClient.get('/videos');
    return response.data;
  },

  // 上传视频
  uploadVideo: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);

    const response = await apiClient.post('/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  // 获取视频详情
  getVideoDetail: async (videoId: string) => {
    const response = await apiClient.get(`/videos/${videoId}`);
    return response.data;
  },

  // 获取字幕
  getSubtitles: async (videoId: string) => {
    const response = await apiClient.get(`/videos/${videoId}/subtitles`);
    return response.data;
  },

  // 提取节点
  extractNodes: async (videoId: string) => {
    const response = await apiClient.post(`/videos/${videoId}/extract-nodes`);
    return response.data;
  },
};

// WebSocket连接URL
export const WS_BASE_URL = 'ws://localhost:8000/ws';
