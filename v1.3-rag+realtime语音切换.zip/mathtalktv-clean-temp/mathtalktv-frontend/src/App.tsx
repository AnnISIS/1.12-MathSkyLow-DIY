import { useState, useEffect, useRef } from 'react';
import { useHotkeys } from 'react-hotkeys-hook';
import VideoList from './components/VideoList';
import VideoUploader from './components/VideoUploader';
import VideoPlayer from './components/VideoPlayer';
import ChatPanel from './components/ChatPanel';
import { DesmosBoard } from './components/DesmosBoard';
import { GeoGebraBoard } from './components/GeoGebraBoard';
import { QuickAnnotation } from './components/QuickAnnotation';
import StudentReportPage from './pages/StudentReportPage';
import VideoReportPage from './pages/VideoReportPage';
import { LoginPage } from './pages/LoginPage';
import { Video } from './types';
import { videoApi } from './api';
import './App.css';

type ViewMode = 'list' | 'upload' | 'detail' | 'student-report' | 'video-report' | 'login';
type PanelMode = 'chat-only' | 'math-only' | 'both';
type MathBoardType = 'desmos' | 'geogebra';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // 画板相关状态
  const [panelMode, setPanelMode] = useState<PanelMode>('chat-only');  // 初始只显示聊天
  const [showAnnotation, setShowAnnotation] = useState(false);
  const [mathBoardType, setMathBoardType] = useState<MathBoardType>('desmos');
  const desmosCalculatorRef = useRef<any>(null);  // Desmos 实例引用
  const geogebraAppRef = useRef<any>(null);  // GeoGebra 实例引用
  const pendingDrawCommandRef = useRef<any>(null);  // 待执行的绘图指令

  // 历史对话持久化：按videoId存储每个视频的对话记录
  const [videoMessages, setVideoMessages] = useState<Record<string, any[]>>(() => {
    try {
      const saved = localStorage.getItem('videoMessages');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // 画板状态持久化
  const [desmosStates, setDesmosStates] = useState<Record<string, any>>(() => {
    try {
      const saved = localStorage.getItem('desmosStates');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [geogebraStates, setGeogebraStates] = useState<Record<string, any>>(() => {
    try {
      const saved = localStorage.getItem('geogebraStates');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // 保存对话记录到localStorage
  useEffect(() => {
    try {
      localStorage.setItem('videoMessages', JSON.stringify(videoMessages));
    } catch (e) {
      console.error('保存对话记录失败:', e);
    }
  }, [videoMessages]);

  // 保存画板状态到localStorage
  useEffect(() => {
    try {
      localStorage.setItem('desmosStates', JSON.stringify(desmosStates));
    } catch (e) {
      console.error('保存Desmos状态失败:', e);
    }
  }, [desmosStates]);

  useEffect(() => {
    try {
      localStorage.setItem('geogebraStates', JSON.stringify(geogebraStates));
    } catch (e) {
      console.error('保存GeoGebra状态失败:', e);
    }
  }, [geogebraStates]);

  // 检查登录状态
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsLoggedIn(true);
    } else {
      setViewMode('login');
    }
  }, []);

  // 页面加载时检查URL参数，恢复视频详情页
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const videoId = urlParams.get('videoId');

    if (videoId && isLoggedIn) {
      // 从URL恢复视频详情
      handleVideoSelect(videoId);
    }
  }, [isLoggedIn]);

  const handleVideoUploaded = async (videoId: string) => {
    // 上传成功后,获取视频详情并跳转到详情页
    console.log('📹 [App] handleVideoUploaded 被调用, videoId:', videoId);
    try {
      console.log('📹 [App] 开始获取视频详情...');
      const video = await videoApi.getVideoDetail(videoId);
      console.log('📹 [App] 视频详情获取成功:', video);

      setCurrentVideo(video);
      // 视频文件名固定为 {videoId}.mp4
      const url = `http://localhost:8000/static/videos/${videoId}.mp4`;
      console.log('📹 [App] 设置视频URL:', url);
      setVideoUrl(url);
      setViewMode('detail');
      console.log('📹 [App] 切换到详情页');

      // 更新URL参数
      window.history.pushState({}, '', `?videoId=${videoId}`);
    } catch (error) {
      console.error('❌ [App] 获取视频详情失败:', error);
    }
  };

  const handleVideoSelect = async (videoId: string) => {
    // 从列表选择视频,获取详情并跳转到详情页
    console.log('📹 [App] handleVideoSelect 被调用, videoId:', videoId);
    try {
      console.log('📹 [App] 开始获取视频详情...');
      const video = await videoApi.getVideoDetail(videoId);
      console.log('📹 [App] 视频详情获取成功:', video);

      setCurrentVideo(video);
      // 视频文件名固定为 {videoId}.mp4
      const url = `http://localhost:8000/static/videos/${videoId}.mp4`;
      console.log('📹 [App] 视频URL:', url);
      setVideoUrl(url);
      setViewMode('detail');
      console.log('📹 [App] 切换到详情页');

      // 更新URL参数
      window.history.pushState({}, '', `?videoId=${videoId}`);
    } catch (error) {
      console.error('❌ [App] 获取视频详情失败:', error);
    }
  };

  const handleBackToList = () => {
    // 关闭视频时保存画板状态
    if (currentVideo) {
      if (desmosCalculatorRef.current) {
        try {
          const state = desmosCalculatorRef.current.getState();
          setDesmosStates(prev => ({ ...prev, [currentVideo.id]: state }));
        } catch (e) {
          console.error('保存Desmos状态失败:', e);
        }
      }
      if (geogebraAppRef.current) {
        try {
          const state = geogebraAppRef.current.getBase64();
          setGeogebraStates(prev => ({ ...prev, [currentVideo.id]: state }));
        } catch (e) {
          console.error('保存GeoGebra状态失败:', e);
        }
      }
    }

    setViewMode('list');
    setCurrentVideo(null);
    setVideoUrl('');
    setPanelMode('chat-only');
    setShowAnnotation(false);

    // 清除URL参数
    window.history.pushState({}, '', '/');
  };

  const handleLogout = () => {
    // 清除登录信息
    localStorage.removeItem('token');
    localStorage.removeItem('user_id');
    localStorage.removeItem('username');

    // 跳转到登录页
    setIsLoggedIn(false);
    setViewMode('login');
  };

  // 快捷键支持
  useHotkeys('ctrl+b', () => {
    if (viewMode === 'detail') {
      setPanelMode(prev => prev === 'math-only' ? 'chat-only' : 'math-only');
    }
  });

  // 移除 Ctrl+A 快捷键，避免与空格键功能冲突
  // 用户可以直接点击 ✏️ 按钮控制画笔

  useHotkeys('esc', () => {
    setShowAnnotation(false);
  });

  // 切换画板模式
  const toggleMathBoard = () => {
    setPanelMode(prev => {
      if (prev === 'chat-only') return 'math-only';
      if (prev === 'math-only') return 'both';
      return 'chat-only';
    });
  };

  // 处理 AI 自动绘图请求
  const handleAutoDrawRequest = (drawData: any) => {
    const { action, board_type, expressions } = drawData;

    if (action === 'open_board') {
      console.log('🎨 收到自动绘图指令:', board_type, expressions);

      // 保存待执行的绘图指令
      pendingDrawCommandRef.current = { board_type, expressions };

      // 1. 切换到 both 模式（三栏）
      setPanelMode('both');

      // 2. 切换到对应画板类型
      setMathBoardType(board_type);

      // 3. 如果画板已经加载，立即执行绘图
      if (board_type === 'desmos' && desmosCalculatorRef.current) {
        console.log('🎨 Desmos画板已加载，立即绘制');
        setTimeout(() => executeDrawCommand('desmos', desmosCalculatorRef.current), 500);
      } else if (board_type === 'geogebra' && geogebraAppRef.current) {
        console.log('🎨 GeoGebra画板已加载，立即绘制');
        setTimeout(() => executeDrawCommand('geogebra', geogebraAppRef.current), 500);
      }
      // 否则等待画板 onReady 回调执行绘图
    }
  };

  // 执行绘图命令
  const executeDrawCommand = (boardType: MathBoardType, calculator: any) => {
    if (!pendingDrawCommandRef.current || pendingDrawCommandRef.current.board_type !== boardType) {
      console.log(`⚠️ 没有待执行的${boardType}绘图命令`);
      return;
    }

    const { expressions } = pendingDrawCommandRef.current;
    console.log(`🎨 执行绘图命令 (${boardType}):`, expressions);
    console.log('🎨 Calculator对象:', calculator);

    try {
      if (boardType === 'desmos' && calculator) {
        // Desmos: 使用 latex 字段
        expressions.forEach((expr: any, index: number) => {
          if (expr.latex) {
            const expressionObj = {
              id: expr.id,
              latex: expr.latex,
              color: expr.color
            };
            console.log(`📝 [${index + 1}/${expressions.length}] 准备绘制:`, expressionObj);

            try {
              calculator.setExpression(expressionObj);
              console.log(`✅ [${index + 1}/${expressions.length}] Desmos绘制成功:`, expr.latex);

              // 验证表达式是否真的添加了
              const state = calculator.getState();
              console.log('📊 Desmos当前状态:', state);
              console.log('📊 当前表达式数量:', state.expressions?.list?.length || 0);
            } catch (err) {
              console.error(`❌ [${index + 1}/${expressions.length}] 绘制失败:`, err);
            }
          } else {
            console.warn(`⚠️ 表达式${index}缺少latex字段:`, expr);
          }
        });

        console.log('✅ Desmos 绘制完成，共', expressions.length, '个表达式');

        // 尝试设置视图范围
        try {
          calculator.setMathBounds({
            left: -10,
            right: 10,
            bottom: -10,
            top: 10
          });
          console.log('📐 视图范围已设置为 [-10, 10]');
        } catch (err) {
          console.warn('⚠️ 设置视图范围失败:', err);
        }

      } else if (boardType === 'geogebra' && calculator) {
        // GeoGebra: 使用 command 字段
        expressions.forEach((expr: any, index: number) => {
          if (expr.command) {
            console.log(`📝 [${index + 1}/${expressions.length}] 执行命令:`, expr.command);
            try {
              const result = calculator.evalCommand(expr.command);
              console.log(`✅ [${index + 1}/${expressions.length}] GeoGebra执行结果:`, result);
            } catch (err) {
              console.error(`❌ [${index + 1}/${expressions.length}] 命令执行失败:`, err);
            }
          }
        });
        console.log('✅ GeoGebra 绘制完成，共', expressions.length, '个命令');
      }

      // 清除已执行的命令
      pendingDrawCommandRef.current = null;
      console.log('🧹 绘图命令已清除');
    } catch (error) {
      console.error('❌ 绘图失败:', error);
    }
  };

  return (
    <div className="app">
      {/* 登录页面 */}
      {viewMode === 'login' && <LoginPage />}

      {/* 已登录后的内容 */}
      {viewMode !== 'login' && (
        <>
          <header className="app-header">
            <div className="header-content">
              <div className="header-left">
                {viewMode !== 'list' && (
              <button className="back-button" onClick={handleBackToList}>
                ← 返回列表
              </button>
            )}
            <h1>📐 MathTalkTV</h1>
          </div>
          <div className="header-right">
            {viewMode === 'list' && (
              <>
                <button
                  className="report-button"
                  onClick={() => setViewMode('student-report')}
                >
                  📊 我的报告
                </button>
                <button
                  className="upload-button"
                  onClick={() => setViewMode('upload')}
                >
                  + 上传视频
                </button>
                <button
                  className="logout-button"
                  onClick={handleLogout}
                  title={`当前用户: ${localStorage.getItem('username')}`}
                >
                  🚪 退出
                </button>
              </>
            )}
            {viewMode === 'detail' && currentVideo && (
              <button
                className="report-button"
                onClick={() => setViewMode('video-report')}
              >
                📊 视频报告
              </button>
            )}
          </div>
        </div>
        <p className="header-subtitle">初中数学智能讲题平台</p>
      </header>

      <main className="app-main">
        {viewMode === 'list' && (
          <VideoList onVideoSelect={handleVideoSelect} />
        )}

        {viewMode === 'upload' && (
          <div className="upload-container">
            <VideoUploader onVideoUploaded={handleVideoUploaded} />
          </div>
        )}

        {viewMode === 'student-report' && (
          <StudentReportPage />
        )}

        {viewMode === 'video-report' && currentVideo && (
          <VideoReportPage
            videoId={currentVideo.id}
            onClose={() => setViewMode('detail')}
          />
        )}

        {viewMode === 'detail' && currentVideo && (
          <div className="main-content">
            <div className="video-section" style={{
              flex: panelMode === 'both' ? '0 0 40%' : panelMode === 'math-only' ? '0 0 50%' : '1'
            }}>
              <VideoPlayer
                videoUrl={videoUrl}
                videoId={currentVideo.id}
                videoRef={videoRef}
                nodes={currentVideo.nodes}
              />

              {/* 悬浮工具栏 */}
              <div className="floating-toolbar">
                <button
                  className={`floating-btn ${panelMode !== 'chat-only' ? 'active' : ''}`}
                  onClick={toggleMathBoard}
                  title="画板 (Ctrl+B)"
                >
                  📐
                </button>
                <button
                  className={`floating-btn ${panelMode !== 'math-only' ? 'active' : ''}`}
                  onClick={() => setPanelMode('both')}
                  title="三栏并行（显示聊天）"
                >
                  💬
                </button>
                <button
                  className={`floating-btn ${showAnnotation ? 'active' : ''}`}
                  onClick={(e) => {
                    e.stopPropagation(); // 防止事件冒泡
                    setShowAnnotation(!showAnnotation);
                  }}
                  title="标注 - 点击再次关闭"
                >
                  ✏️
                </button>
                {/* 画板类型切换 */}
                {panelMode !== 'chat-only' && (
                  <div className="board-type-switcher">
                    <button
                      className={`type-btn ${mathBoardType === 'desmos' ? 'active' : ''}`}
                      onClick={() => setMathBoardType('desmos')}
                      title="Desmos 函数画板"
                    >
                      ƒ(x)
                    </button>
                    <button
                      className={`type-btn ${mathBoardType === 'geogebra' ? 'active' : ''}`}
                      onClick={() => setMathBoardType('geogebra')}
                      title="GeoGebra 几何画板"
                    >
                      △
                    </button>
                  </div>
                )}
              </div>

              {/* 画中画标注 */}
              <QuickAnnotation
                videoRef={videoRef}
                isActive={showAnnotation}
                onClose={() => setShowAnnotation(false)}
              />
            </div>

            {/* 数学画板 */}
            {panelMode !== 'chat-only' && (
              <div className="math-section" style={{
                flex: panelMode === 'both' ? '0 0 30%' : '0 0 50%'
              }}>
                {mathBoardType === 'desmos' ? (
                  <DesmosBoard
                    onClose={() => {
                      // 收起画板时保存状态
                      if (currentVideo && desmosCalculatorRef.current) {
                        try {
                          const state = desmosCalculatorRef.current.getState();
                          setDesmosStates(prev => ({ ...prev, [currentVideo.id]: state }));
                          console.log('💾 保存Desmos状态:', currentVideo.id);
                        } catch (e) {
                          console.error('保存Desmos状态失败:', e);
                        }
                      }
                      setPanelMode('chat-only');
                    }}
                    onReady={(calc) => {
                      desmosCalculatorRef.current = calc;

                      // 恢复之前保存的状态
                      if (currentVideo && desmosStates[currentVideo.id]) {
                        try {
                          // 延迟恢复，确保画板已完全加载
                          setTimeout(() => {
                            calc.setState(desmosStates[currentVideo.id]);
                            console.log('✅ 恢复Desmos状态:', currentVideo.id);
                          }, 100);
                        } catch (e) {
                          console.error('恢复Desmos状态失败:', e);
                        }
                      }

                      // 只有当有待执行命令时才执行（避免覆盖恢复的状态）
                      if (pendingDrawCommandRef.current) {
                        setTimeout(() => {
                          executeDrawCommand('desmos', calc);
                        }, 200);
                      }
                    }}
                  />
                ) : (
                  <GeoGebraBoard
                    onClose={() => {
                      // 收起画板时保存状态
                      if (currentVideo && geogebraAppRef.current) {
                        try {
                          const state = geogebraAppRef.current.getBase64();
                          setGeogebraStates(prev => ({ ...prev, [currentVideo.id]: state }));
                          console.log('💾 保存GeoGebra状态:', currentVideo.id);
                        } catch (e) {
                          console.error('保存GeoGebra状态失败:', e);
                        }
                      }
                      setPanelMode('chat-only');
                    }}
                    onReady={(app) => {
                      geogebraAppRef.current = app;

                      // 恢复之前保存的状态
                      if (currentVideo && geogebraStates[currentVideo.id]) {
                        try {
                          // 延迟恢复，确保画板已完全加载
                          setTimeout(() => {
                            app.setBase64(geogebraStates[currentVideo.id]);
                            console.log('✅ 恢复GeoGebra状态:', currentVideo.id);
                          }, 100);
                        } catch (e) {
                          console.error('恢复GeoGebra状态失败:', e);
                        }
                      }

                      // 只有当有待执行命令时才执行（避免覆盖恢复的状态）
                      if (pendingDrawCommandRef.current) {
                        setTimeout(() => {
                          executeDrawCommand('geogebra', app);
                        }, 200);
                      }
                    }}
                  />
                )}
              </div>
            )}

            {/* 对话面板 */}
            {panelMode !== 'math-only' && (
              <div className="chat-section" style={{
                flex: panelMode === 'both' ? '0 0 30%' : '0 0 400px'
              }}>
                <ChatPanel
                  videoId={currentVideo.id}
                  videoRef={videoRef}
                  onAutoDrawRequest={handleAutoDrawRequest}
                  messages={videoMessages[currentVideo.id] || []}
                  onMessagesChange={(msgs) => {
                    setVideoMessages(prev => ({
                      ...prev,
                      [currentVideo.id]: msgs
                    }));
                  }}
                />
              </div>
            )}
          </div>
        )}
      </main>
      </>
      )}
    </div>
  );
}

export default App;
