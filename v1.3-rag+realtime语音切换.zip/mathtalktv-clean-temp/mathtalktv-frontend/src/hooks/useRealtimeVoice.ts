/**
 * OpenAI Realtime API Hook
 * 前端直接连接 OpenAI Realtime WebSocket
 * 参考: MathTalkTV-main/app/src/hooks/useRealtimeVoice.ts
 */
import { useState, useCallback, useRef, useEffect } from 'react';

const API_BASE = 'http://localhost:8000';

interface UseRealtimeVoiceOptions {
  videoContext?: string;
  videoId?: string;
  currentTime?: number;
  onTranscript?: (text: string, isFinal: boolean) => void;
  onAnswer?: (text: string) => void;
  onComplete?: () => void;
}

export function useRealtimeVoice(options: UseRealtimeVoiceOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const playbackContextRef = useRef<AudioContext | null>(null);
  const playbackQueueRef = useRef<ArrayBuffer[]>([]);
  const isPlayingRef = useRef(false);
  const optionsRef = useRef(options);

  useEffect(() => {
    optionsRef.current = options;
  }, [options]);

  // 播放音频队列
  const playNextAudio = useCallback(async () => {
    if (isPlayingRef.current || playbackQueueRef.current.length === 0) {
      return;
    }

    isPlayingRef.current = true;

    if (!playbackContextRef.current || playbackContextRef.current.state === 'closed') {
      playbackContextRef.current = new AudioContext({ sampleRate: 24000 });
    }

    const audioData = playbackQueueRef.current.shift();
    if (!audioData) {
      isPlayingRef.current = false;
      return;
    }

    try {
      // PCM 16-bit to Float32
      const pcmData = new Int16Array(audioData);
      const floatData = new Float32Array(pcmData.length);
      for (let i = 0; i < pcmData.length; i++) {
        floatData[i] = pcmData[i] / 32768;
      }

      const audioBuffer = playbackContextRef.current.createBuffer(
        1,
        floatData.length,
        24000
      );
      audioBuffer.getChannelData(0).set(floatData);

      const source = playbackContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(playbackContextRef.current.destination);
      source.onended = () => {
        isPlayingRef.current = false;
        playNextAudio();
      };
      source.start();
    } catch (e) {
      console.error('Audio playback error:', e);
      isPlayingRef.current = false;
      playNextAudio();
    }
  }, []);

  // 处理 Realtime 事件
  const handleRealtimeEvent = useCallback(
    (event: any) => {
      const opts = optionsRef.current;

      console.log('>>> Realtime Event:', event.type);

      switch (event.type) {
        case 'session.created':
          console.log('Session created');
          break;

        case 'input_audio_buffer.speech_started':
          console.log('Speech started');
          setIsSpeaking(true);
          // 清空播放队列
          playbackQueueRef.current = [];
          isPlayingRef.current = false;
          break;

        case 'input_audio_buffer.speech_stopped':
          console.log('Speech stopped');
          setIsSpeaking(false);
          break;

        case 'conversation.item.input_audio_transcription.completed':
          console.log('User transcript:', event.transcript);
          opts.onTranscript?.(event.transcript || '', true);
          break;

        case 'conversation.item.input_audio_transcription.failed':
          console.error('❌ ASR转写失败:', event.error);
          console.log('完整事件数据:', event);

          // 429 错误特殊处理
          if (event.error?.message?.includes('429')) {
            alert('⚠️ OpenAI API 请求频率过高，请稍后再试（1-2分钟）\n\n可能原因：\n1. 短时间内测试次数过多\n2. API key 达到速率限制\n3. 免费试用账号限制\n\n建议：等待1-2分钟后重试');
          }
          break;

        case 'response.audio_transcript.delta':
          console.log('AI text delta:', event.delta);
          opts.onAnswer?.(event.delta || '');
          break;

        case 'response.audio.delta':
          // AI 语音流
          if (event.delta) {
            const audioData = base64ToArrayBuffer(event.delta);
            playbackQueueRef.current.push(audioData);
            playNextAudio();
          }
          break;

        case 'response.done':
          console.log('Response done');
          opts.onComplete?.();
          break;

        case 'error':
          console.error('Realtime API error:', event.error);
          break;

        default:
          console.log('Unhandled event:', event.type);
      }
    },
    [playNextAudio]
  );

  // 获取 session token 并连接
  const connect = useCallback(async () => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      console.log('Already connected');
      return;
    }

    try {
      console.log('Creating Realtime session...');

      // 调用后端获取临时 token
      const response = await fetch(`${API_BASE}/api/realtime/session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          video_context: optionsRef.current.videoContext,
          video_id: optionsRef.current.videoId,
          current_time: optionsRef.current.currentTime,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        console.error('Failed to get session token:', error);
        throw new Error('Failed to create Realtime session');
      }

      const data = await response.json();
      const clientSecret = data.client_secret;

      console.log('Got client secret, connecting WebSocket...');

      // 连接 WebSocket
      const wsUrl = `wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-12-17`;
      const ws = new WebSocket(wsUrl, [
        'realtime',
        `openai-insecure-api-key.${clientSecret}`,
        'openai-beta.realtime-v1',
      ]);

      ws.onopen = () => {
        console.log('WebSocket connected!');
        setIsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleRealtimeEvent(data);
        } catch (e) {
          console.error('Failed to parse message:', e);
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setIsConnected(false);
      };

      ws.onclose = (event) => {
        console.log('WebSocket closed:', event.code, event.reason);
        setIsConnected(false);
        setIsListening(false);
      };

      wsRef.current = ws;
    } catch (error) {
      console.error('Failed to connect:', error);
      setIsConnected(false);
    }
  }, [handleRealtimeEvent]);

  // 开始录音
  const startListening = useCallback(async () => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      console.error('WebSocket not connected');
      return;
    }

    try {
      console.log('Requesting microphone...');
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 24000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      console.log('Microphone granted');
      mediaStreamRef.current = stream;

      const audioContext = new AudioContext({ sampleRate: 24000 });
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      processor.onaudioprocess = (e) => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          const inputData = e.inputBuffer.getChannelData(0);
          const pcmData = floatTo16BitPCM(inputData);
          const base64Data = arrayBufferToBase64(pcmData);

          wsRef.current.send(
            JSON.stringify({
              type: 'input_audio_buffer.append',
              audio: base64Data,
            })
          );
        }
      };

      source.connect(processor);
      processor.connect(audioContext.destination);

      setIsListening(true);
      console.log('Now listening...');
    } catch (error) {
      console.error('Failed to start recording:', error);
    }
  }, []);

  // 停止录音
  const stopListening = useCallback(() => {
    console.log('Stopping listening...');

    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    setIsListening(false);
    setIsSpeaking(false);
  }, []);

  // 断开连接
  const disconnect = useCallback(() => {
    console.log('Disconnecting...');

    stopListening();

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    playbackQueueRef.current = [];
    isPlayingRef.current = false;

    if (playbackContextRef.current && playbackContextRef.current.state !== 'closed') {
      playbackContextRef.current.close();
      playbackContextRef.current = null;
    }

    setIsConnected(false);
  }, [stopListening]);

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return {
    isConnected,
    isListening,
    isSpeaking,
    connect,
    startListening,
    stopListening,
    disconnect,
  };
}

// 工具函数
function floatTo16BitPCM(float32Array: Float32Array): ArrayBuffer {
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);
  for (let i = 0; i < float32Array.length; i++) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return buffer;
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}
