import { useState } from 'react';
import './LoginPage.css';

export function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const endpoint = isRegistering ? '/api/auth/register' : '/api/auth/login';
      const res = await fetch(`http://localhost:8000${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.detail || '操作失败');
      }

      // 保存token和user_id到localStorage
      localStorage.setItem('token', data.token);
      localStorage.setItem('user_id', data.user_id);
      localStorage.setItem('username', data.username);

      // 登录/注册成功，刷新页面
      window.location.reload();
    } catch (err: any) {
      setError(err.message || '操作失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const toggleMode = () => {
    setIsRegistering(!isRegistering);
    setError('');
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-header">
          <h1>📐 MathTalkTV</h1>
          <p>智能数学教学视频平台</p>
        </div>

        <div className="login-form-wrapper">
          <h2>{isRegistering ? '注册账号' : '登录'}</h2>

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label>用户名</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="请输入用户名（3-20个字符）"
                required
                disabled={loading}
                minLength={3}
                maxLength={20}
              />
            </div>

            <div className="form-group">
              <label>密码</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="请输入密码（至少6位）"
                required
                disabled={loading}
                minLength={6}
              />
            </div>

            {error && <div className="error-message">{error}</div>}

            <button type="submit" className="submit-btn" disabled={loading}>
              {loading ? '处理中...' : (isRegistering ? '注册' : '登录')}
            </button>
          </form>

          <div className="toggle-mode">
            <span>
              {isRegistering ? '已有账号？' : '还没有账号？'}
              <button type="button" onClick={toggleMode} disabled={loading}>
                {isRegistering ? '去登录' : '去注册'}
              </button>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
