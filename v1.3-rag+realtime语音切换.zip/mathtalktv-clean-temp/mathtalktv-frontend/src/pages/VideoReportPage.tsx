import { useState, useEffect } from 'react';
import { VideoReport } from '../types/report';
import './VideoReportPage.css';

interface Props {
  videoId: string;
  onClose: () => void;
}

const VideoReportPage = ({ videoId, onClose }: Props) => {
  const [report, setReport] = useState<VideoReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchVideoReport();
  }, [videoId]);

  const fetchVideoReport = async () => {
    try {
      setLoading(true);
      const response = await fetch(`http://localhost:8000/api/reports/video/${videoId}`);
      if (!response.ok) throw new Error('获取报告失败');

      const data = await response.json();
      setReport(data);
      setError(null);
    } catch (err: any) {
      setError(err.message);
      console.error('获取视频报告失败:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatPercentage = (rate: number): string => {
    return `${(rate * 100).toFixed(1)}%`;
  };

  if (loading) {
    return (
      <div className="video-report-container">
        <div className="loading">加载中...</div>
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="video-report-container">
        <div className="error">❌ {error || '暂无数据'}</div>
      </div>
    );
  }

  // 找到热力图中的热点时间段
  const maxHeatCount = Math.max(...report.question_heatmap.map(h => h.count), 1);

  return (
    <div className="video-report-container">
      <div className="video-report-header">
        <h2>📊 视频学习报告</h2>
        <button className="close-btn" onClick={onClose}>
          ✕
        </button>
      </div>

      {/* 基本统计 */}
      <div className="video-stats-grid">
        <div className="video-stat-card">
          <div className="stat-icon">👥</div>
          <div className="stat-info">
            <div className="stat-label">观看人次</div>
            <div className="stat-value">{report.total_views}</div>
          </div>
        </div>

        <div className="video-stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-info">
            <div className="stat-label">平均完成率</div>
            <div className="stat-value">{formatPercentage(report.avg_completion_rate)}</div>
          </div>
        </div>

        <div className="video-stat-card">
          <div className="stat-icon">❓</div>
          <div className="stat-info">
            <div className="stat-label">总提问数</div>
            <div className="stat-value">{report.total_questions}</div>
          </div>
        </div>

        <div className="video-stat-card">
          <div className="stat-icon">⭐</div>
          <div className="stat-info">
            <div className="stat-label">平均满意度</div>
            <div className="stat-value">
              {report.avg_satisfaction.toFixed(1)}/5.0
            </div>
          </div>
        </div>
      </div>

      {/* 提问时间轴热力图 */}
      <div className="section">
        <h3>🔥 提问热力图</h3>
        <p className="section-desc">显示学生在视频不同时间点的提问频率</p>
        <div className="heatmap-container">
          {report.question_heatmap.map((item, index) => {
            const intensity = item.count / maxHeatCount;
            const color = intensity === 0
              ? '#e9ecef'
              : `rgba(102, 126, 234, ${0.2 + intensity * 0.8})`;

            return (
              <div
                key={index}
                className="heatmap-bar"
                style={{ backgroundColor: color }}
                title={`${Math.floor(item.time / 60)}:${(item.time % 60).toString().padStart(2, '0')} - ${item.count}个问题`}
              >
                {item.count > 0 && (
                  <span className="heat-count">{item.count}</span>
                )}
              </div>
            );
          })}
        </div>
        <div className="heatmap-legend">
          <span>📍 时间轴（每格30秒）</span>
          <span>热度：低 ▪️▪️▪️ 高</span>
        </div>
      </div>

      {/* 高频问题词云 */}
      {report.question_wordcloud.length > 0 && (
        <div className="section">
          <h3>💬 高频问题关键词</h3>
          <p className="section-desc">学生最常问到的概念和问题</p>
          <div className="wordcloud-container">
            {report.question_wordcloud.map((word, index) => {
              const maxCount = Math.max(...report.question_wordcloud.map(w => w.count));
              const fontSize = 14 + (word.count / maxCount) * 32; // 14px - 46px
              const colors = ['#667eea', '#764ba2', '#f093fb', '#4facfe', '#43e97b'];
              const color = colors[index % colors.length];

              return (
                <div
                  key={index}
                  className="word-item"
                  style={{
                    fontSize: `${fontSize}px`,
                    color: color,
                  }}
                  title={`出现${word.count}次`}
                >
                  {word.word}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 满意度分布 */}
      <div className="section">
        <h3>😊 学生满意度</h3>
        <p className="section-desc">学生对AI回答的评分分布</p>
        <div className="satisfaction-container">
          {Object.entries(report.satisfaction_distribution)
            .sort(([a], [b]) => Number(b) - Number(a)) // 从5到1排序
            .map(([rating, count]) => {
              const total = Object.values(report.satisfaction_distribution).reduce((a, b) => a + b, 0);
              const percentage = (count / total) * 100;

              return (
                <div key={rating} className="satisfaction-row">
                  <div className="rating-label">
                    {'⭐'.repeat(Number(rating))}
                  </div>
                  <div className="satisfaction-bar-container">
                    <div
                      className="satisfaction-bar"
                      style={{ width: `${percentage}%` }}
                    >
                      <span className="count-label">{count}</span>
                    </div>
                  </div>
                  <div className="percentage-label">{percentage.toFixed(1)}%</div>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default VideoReportPage;
