# AI 自动绘图功能设计方案

## 📋 功能需求

### **场景 1: 视频内容分析自动绘图**
- AI 分析视频内容，识别到函数/几何知识点时
- 自动打开画板
- 边讲解边绘制图形

### **场景 2: 学生提问自动绘图**
- 学生询问函数、几何、公式推演等问题
- AI 判断需要绘图辅助讲解
- 自动打开画板并绘制

---

## 🔄 WebSocket 通信协议

### **1. 消息类型定义**

```typescript
// 前端 → 后端: 普通问答（已有）
{
  "command": "text_question",
  "data": {
    "text": "二次函数的顶点怎么求？"
  }
}

// 后端 → 前端: AI 自动绘图指令（新增）
{
  "type": "auto_draw",
  "data": {
    "action": "open_board",  // 操作类型
    "board_type": "desmos",  // 画板类型: desmos | geogebra
    "expressions": [         // 绘制表达式列表
      {
        "id": "func-1",
        "latex": "y=x^2-2x+1",
        "color": "#2d70b3",
        "animation": true     // 是否动画展示
      }
    ]
  }
}

// 后端 → 前端: AI 文本回答（已有，增强）
{
  "type": "text",
  "content": "二次函数的顶点公式是...",
  "need_drawing": true,     // 新增：是否需要配合绘图
  "draw_trigger": "auto"    // 新增：绘图触发时机 auto | manual
}
```

---

## 🎯 实现方案

### **阶段 1: 后端识别绘图场景 (LLM 智能判断)**

#### **方法 A: System Prompt 引导 (简单，推荐)**

```python
# app/services/rag_retriever.py 或 chat.py

SYSTEM_PROMPT_WITH_DRAW = """
你是一位初中数学AI老师。在回答问题时：

1. 如果问题涉及以下内容，你需要在回答**开头**添加特殊标记：
   - 函数图像 (二次函数、一次函数、反比例函数等) → 添加 [DRAW:DESMOS]
   - 几何图形 (三角形、圆、多边形等) → 添加 [DRAW:GEOGEBRA]
   - 公式推导 (需要图像辅助) → 添加 [DRAW:DESMOS]

2. 标记格式：
   [DRAW:DESMOS:y=x^2,y=2x+1]  (Desmos画板，绘制多个函数)
   [DRAW:GEOGEBRA:Circle((0,0),3)]  (GeoGebra画板，绘制圆)

3. 示例：
   - 学生问："二次函数 y=x^2 的图像是什么样的？"
   - 你的回答：
     [DRAW:DESMOS:y=x^2]
     二次函数 y=x^2 的图像是一个开口向上的抛物线，顶点在原点 (0,0)...

4. 如果不需要绘图，正常回答即可。
"""
```

#### **后端解析回答**

```python
# app/api/chat.py 新增解析函数

import re

def parse_draw_command(text: str):
    """
    解析 LLM 回答中的绘图指令
    返回: (clean_text, draw_command)
    """
    pattern = r'\[DRAW:(DESMOS|GEOGEBRA):([^\]]+)\]'
    match = re.search(pattern, text)

    if not match:
        return text, None

    board_type = match.group(1).lower()  # desmos | geogebra
    expressions_str = match.group(2)      # y=x^2,y=2x+1

    # 清理回答文本（移除标记）
    clean_text = re.sub(pattern, '', text).strip()

    # 构建绘图指令
    expressions = []
    for idx, expr in enumerate(expressions_str.split(',')):
        expressions.append({
            "id": f"auto-{idx}",
            "latex": expr.strip(),
            "color": ["#2d70b3", "#c74440", "#2ca02c"][idx % 3]
        })

    draw_command = {
        "type": "auto_draw",
        "data": {
            "action": "open_board",
            "board_type": board_type,
            "expressions": expressions
        }
    }

    return clean_text, draw_command


# 在 handle_text_question 中使用
async def handle_text_question(self, text: str):
    # ... 现有 RAG + LLM 逻辑 ...
    answer = await llm_generate(text, context)

    # 解析绘图指令
    clean_answer, draw_command = parse_draw_command(answer)

    # 如果有绘图指令，先发送绘图指令
    if draw_command:
        await websocket.send_json(draw_command)
        await asyncio.sleep(0.5)  # 给前端时间打开画板

    # 发送文本回答
    await websocket.send_json({
        "type": "text",
        "content": clean_answer
    })
```

---

### **阶段 2: 前端接收绘图指令**

#### **App.tsx 增加状态**

```typescript
// 新增自动绘图相关状态
const [autoDrawQueue, setAutoDrawQueue] = useState<any[]>([]);
const calculatorRef = useRef<any>(null);  // Desmos 实例引用
```

#### **ChatPanel.tsx 接收 WebSocket 消息**

```typescript
// src/components/ChatPanel.tsx

useEffect(() => {
  if (!ws) return;

  ws.onmessage = (event) => {
    const message = JSON.parse(event.data);

    switch (message.type) {
      case 'auto_draw':
        // 处理自动绘图指令
        handleAutoDraw(message.data);
        break;

      case 'text':
        // 现有文本消息处理
        setMessages(prev => [...prev, {
          type: 'text',
          content: message.content,
          role: 'assistant'
        }]);
        break;

      // ... 其他消息类型
    }
  };
}, [ws]);

const handleAutoDraw = (drawData: any) => {
  // 通知 App.tsx 打开画板并绘制
  if (onAutoDrawRequest) {
    onAutoDrawRequest(drawData);
  }
};
```

#### **App.tsx 处理绘图请求**

```typescript
const handleAutoDrawRequest = (drawData: any) => {
  const { action, board_type, expressions } = drawData;

  if (action === 'open_board') {
    // 1. 切换到 both 模式（三栏）
    setPanelMode('both');

    // 2. 切换到对应画板类型
    setMathBoardType(board_type);

    // 3. 等待画板加载后绘制
    setTimeout(() => {
      if (board_type === 'desmos' && calculatorRef.current) {
        expressions.forEach((expr: any) => {
          calculatorRef.current.setExpression({
            id: expr.id,
            latex: expr.latex,
            color: expr.color
          });
        });
      } else if (board_type === 'geogebra' && geogebraRef.current) {
        expressions.forEach((expr: any) => {
          geogebraRef.current.evalCommand(expr.latex);
        });
      }
    }, 1000);  // 等待画板完全加载
  }
};

// 传递给 ChatPanel
<ChatPanel
  videoId={currentVideo.id}
  videoRef={videoRef}
  onAutoDrawRequest={handleAutoDrawRequest}  // 新增回调
/>
```

---

## 🔍 识别绘图场景的规则

### **需要 Desmos 画板的场景**

| 关键词 | 示例问题 | 绘制内容 |
|--------|---------|---------|
| 函数图像 | "二次函数 y=x^2 的图像" | y=x^2 |
| 一次函数 | "直线 y=2x+1" | y=2x+1 |
| 反比例 | "反比例函数 y=k/x" | y=3/x |
| 参数变化 | "a 对 y=ax^2 的影响" | y=a*x^2 (带滑块) |
| 对称性 | "关于 y 轴对称的函数" | y=x^2 和 y=(-x)^2 |

### **需要 GeoGebra 画板的场景**

| 关键词 | 示例问题 | 绘制内容 |
|--------|---------|---------|
| 三角形 | "等腰三角形的性质" | 三角形 + 高线 |
| 圆 | "圆的切线定理" | 圆 + 切线 |
| 垂直平分线 | "线段的垂直平分线" | 线段 + 垂线 |
| 角度 | "角平分线的性质" | 角 + 角平分线 |
| 勾股定理 | "直角三角形验证" | 直角三角形 + 标注 |

---

## 📊 LLM Prompt 优化

### **完整 System Prompt**

```python
DRAW_ENABLED_SYSTEM_PROMPT = """
你是 MathTalkTV 的 AI 数学老师，专注于初中数学教学。

## 核心能力
1. 视频内容问答：基于视频字幕和知识点回答问题
2. 自动绘图辅助：在需要时自动调用画板绘制图形

## 绘图规则
当问题涉及以下内容时，你**必须**在回答开头添加绘图标记：

### Desmos 画板（函数类）
- **触发条件**：函数图像、坐标系、参数变化、方程求解
- **标记格式**：`[DRAW:DESMOS:latex表达式1,latex表达式2,...]`
- **示例**：
  - 问："二次函数 y=x^2 的图像？"
  - 答：`[DRAW:DESMOS:y=x^2]` 二次函数 y=x^2 的图像是...
  - 问："对比 y=x^2 和 y=2x^2"
  - 答：`[DRAW:DESMOS:y=x^2,y=2*x^2]` 我们可以看到...

### GeoGebra 画板（几何类）
- **触发条件**：几何图形、线段、角、圆、三角形
- **标记格式**：`[DRAW:GEOGEBRA:命令1,命令2,...]`
- **示例**：
  - 问："如何画半径为 3 的圆？"
  - 答：`[DRAW:GEOGEBRA:Circle((0,0),3)]` 以原点为圆心...
  - 问："等腰三角形的画法"
  - 答：`[DRAW:GEOGEBRA:Polygon((0,0),(2,0),(1,3))]` 等腰三角形...

## 不需要绘图的场景
- 纯概念解释（不涉及图形）
- 计算题步骤
- 公式记忆技巧

## 回答风格
- 温柔耐心，像老师一样
- 先画图，再讲解
- 结合视频内容回答
"""
```

---

## 🧪 测试用例

### **测试 1: 函数图像问题**
```
学生：二次函数 y=x^2-4x+3 的图像是什么样的？

预期流程：
1. 后端 LLM 生成：[DRAW:DESMOS:y=x^2-4*x+3] 这是一个...
2. 后端发送 auto_draw 指令
3. 前端切换到 both 模式
4. 前端在 Desmos 绘制 y=x^2-4x+3
5. 前端显示文本回答
```

### **测试 2: 几何图形问题**
```
学生：圆心在原点、半径为 5 的圆怎么画？

预期流程：
1. 后端生成：[DRAW:GEOGEBRA:Circle((0,0),5)]
2. 前端切换到 GeoGebra
3. 绘制圆
4. 显示讲解文本
```

### **测试 3: 不需要绘图**
```
学生：配方法的步骤是什么？

预期流程：
1. 后端生成：配方法的步骤是：1. 移项...
2. 直接显示文本，不触发绘图
```

---

## 📈 实现优先级

### **Phase 1 (本周): 基础自动绘图**
1. ✅ 后端添加 System Prompt 引导
2. ✅ 后端解析 [DRAW:...] 标记
3. ✅ 前端接收 auto_draw 消息
4. ✅ 前端自动打开画板并绘制

### **Phase 2 (下周): 智能优化**
1. ⏳ LLM 识别更复杂场景（多步骤绘图）
2. ⏳ 动画效果（逐步绘制）
3. ⏳ 绘图历史保存

### **Phase 3 (未来): 视频内容分析**
1. ⏳ 视频上传时 LLM 分析知识点类型
2. ⏳ 视频播放到特定时间点自动打开画板
3. ⏳ 预加载绘图内容

---

## 🎯 总结

**实现难度**: ⭐⭐⭐ (中等)
**开发时间**: 2-3 天
**核心技术**:
- LLM Prompt Engineering (System Prompt 引导)
- 正则表达式解析
- WebSocket 消息扩展
- 前端状态协调

**优势**:
- 无需训练模型，利用 LLM 智能判断
- 轻量级实现，易于调试
- 可扩展性强（支持更多绘图类型）
