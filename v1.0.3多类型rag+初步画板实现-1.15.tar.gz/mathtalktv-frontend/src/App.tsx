import { useState, useEffect, useRef } from 'react';
import { useHotkeys } from 'react-hotkeys-hook';
import VideoList from './components/VideoList';
import VideoUploader from './components/VideoUploader';
import VideoPlayer from './components/VideoPlayer';
import ChatPanel from './components/ChatPanel';
import { DesmosBoard } from './components/DesmosBoard';
import { GeoGebraBoard } from './components/GeoGebraBoard';
import { QuickAnnotation } from './components/QuickAnnotation';
import StudentReportPage from './pages/StudentReportPage';
import VideoReportPage from './pages/VideoReportPage';
import { Video } from './types';
import { videoApi } from './api';
import './App.css';

type ViewMode = 'list' | 'upload' | 'detail' | 'student-report' | 'video-report';
type PanelMode = 'chat-only' | 'math-only' | 'both';
type MathBoardType = 'desmos' | 'geogebra';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const videoRef = useRef<HTMLVideoElement>(null);

  // 画板相关状态
  const [panelMode, setPanelMode] = useState<PanelMode>('chat-only');  // 初始只显示聊天
  const [showAnnotation, setShowAnnotation] = useState(false);
  const [mathBoardType, setMathBoardType] = useState<MathBoardType>('desmos');
  const desmosCalculatorRef = useRef<any>(null);  // Desmos 实例引用
  const geogebraAppRef = useRef<any>(null);  // GeoGebra 实例引用
  const pendingDrawCommandRef = useRef<any>(null);  // 待执行的绘图指令

  // 页面加载时检查URL参数，恢复视频详情页
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const videoId = urlParams.get('videoId');

    if (videoId) {
      // 从URL恢复视频详情
      handleVideoSelect(videoId);
    }
  }, []);

  const handleVideoUploaded = async (videoId: string) => {
    // 上传成功后,获取视频详情并跳转到详情页
    console.log('📹 [App] handleVideoUploaded 被调用, videoId:', videoId);
    try {
      console.log('📹 [App] 开始获取视频详情...');
      const video = await videoApi.getVideoDetail(videoId);
      console.log('📹 [App] 视频详情获取成功:', video);

      setCurrentVideo(video);
      // 视频文件名固定为 {videoId}.mp4
      const url = `http://localhost:8000/static/videos/${videoId}.mp4`;
      console.log('📹 [App] 设置视频URL:', url);
      setVideoUrl(url);
      setViewMode('detail');
      console.log('📹 [App] 切换到详情页');

      // 更新URL参数
      window.history.pushState({}, '', `?videoId=${videoId}`);
    } catch (error) {
      console.error('❌ [App] 获取视频详情失败:', error);
    }
  };

  const handleVideoSelect = async (videoId: string) => {
    // 从列表选择视频,获取详情并跳转到详情页
    console.log('📹 [App] handleVideoSelect 被调用, videoId:', videoId);
    try {
      console.log('📹 [App] 开始获取视频详情...');
      const video = await videoApi.getVideoDetail(videoId);
      console.log('📹 [App] 视频详情获取成功:', video);

      setCurrentVideo(video);
      // 视频文件名固定为 {videoId}.mp4
      const url = `http://localhost:8000/static/videos/${videoId}.mp4`;
      console.log('📹 [App] 视频URL:', url);
      setVideoUrl(url);
      setViewMode('detail');
      console.log('📹 [App] 切换到详情页');

      // 更新URL参数
      window.history.pushState({}, '', `?videoId=${videoId}`);
    } catch (error) {
      console.error('❌ [App] 获取视频详情失败:', error);
    }
  };

  const handleBackToList = () => {
    setViewMode('list');
    setCurrentVideo(null);
    setVideoUrl('');
    setPanelMode('chat-only');
    setShowAnnotation(false);

    // 清除URL参数
    window.history.pushState({}, '', '/');
  };

  // 快捷键支持
  useHotkeys('ctrl+b', () => {
    if (viewMode === 'detail') {
      setPanelMode(prev => prev === 'math-only' ? 'chat-only' : 'math-only');
    }
  });

  useHotkeys('ctrl+a', () => {
    if (viewMode === 'detail') {
      setShowAnnotation(prev => !prev);
    }
  });

  useHotkeys('esc', () => {
    setShowAnnotation(false);
  });

  // 切换画板模式
  const toggleMathBoard = () => {
    setPanelMode(prev => {
      if (prev === 'chat-only') return 'math-only';
      if (prev === 'math-only') return 'both';
      return 'chat-only';
    });
  };

  // 处理 AI 自动绘图请求
  const handleAutoDrawRequest = (drawData: any) => {
    const { action, board_type, expressions } = drawData;

    if (action === 'open_board') {
      console.log('🎨 收到自动绘图指令:', board_type, expressions);

      // 保存待执行的绘图指令
      pendingDrawCommandRef.current = { board_type, expressions };

      // 1. 切换到 both 模式（三栏）
      setPanelMode('both');

      // 2. 切换到对应画板类型
      setMathBoardType(board_type);

      // 不在这里立即绘制，而是在画板 onReady 回调中绘制
    }
  };

  // 执行绘图命令
  const executeDrawCommand = (boardType: MathBoardType, calculator: any) => {
    if (!pendingDrawCommandRef.current || pendingDrawCommandRef.current.board_type !== boardType) {
      return;
    }

    const { expressions } = pendingDrawCommandRef.current;
    console.log(`🎨 执行绘图命令 (${boardType}):`, expressions);

    try {
      if (boardType === 'desmos' && calculator) {
        expressions.forEach((expr: any) => {
          calculator.setExpression({
            id: expr.id,
            latex: expr.latex,
            color: expr.color
          });
        });
        console.log('✅ Desmos 绘制完成');
      } else if (boardType === 'geogebra' && calculator) {
        expressions.forEach((expr: any) => {
          calculator.evalCommand(expr.latex);
        });
        console.log('✅ GeoGebra 绘制完成');
      }

      // 清除已执行的命令
      pendingDrawCommandRef.current = null;
    } catch (error) {
      console.error('❌ 绘图失败:', error);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <div className="header-left">
            {viewMode !== 'list' && (
              <button className="back-button" onClick={handleBackToList}>
                ← 返回列表
              </button>
            )}
            <h1>📐 MathTalkTV</h1>
          </div>
          <div className="header-right">
            {viewMode === 'list' && (
              <>
                <button
                  className="report-button"
                  onClick={() => setViewMode('student-report')}
                >
                  📊 我的报告
                </button>
                <button
                  className="upload-button"
                  onClick={() => setViewMode('upload')}
                >
                  + 上传视频
                </button>
              </>
            )}
            {viewMode === 'detail' && currentVideo && (
              <button
                className="report-button"
                onClick={() => setViewMode('video-report')}
              >
                📊 视频报告
              </button>
            )}
          </div>
        </div>
        <p className="header-subtitle">初中数学智能讲题平台</p>
      </header>

      <main className="app-main">
        {viewMode === 'list' && (
          <VideoList onVideoSelect={handleVideoSelect} />
        )}

        {viewMode === 'upload' && (
          <div className="upload-container">
            <VideoUploader onVideoUploaded={handleVideoUploaded} />
          </div>
        )}

        {viewMode === 'student-report' && (
          <StudentReportPage />
        )}

        {viewMode === 'video-report' && currentVideo && (
          <VideoReportPage
            videoId={currentVideo.id}
            onClose={() => setViewMode('detail')}
          />
        )}

        {viewMode === 'detail' && currentVideo && (
          <div className="main-content">
            <div className="video-section" style={{
              flex: panelMode === 'both' ? '0 0 40%' : panelMode === 'math-only' ? '0 0 50%' : '1'
            }}>
              <VideoPlayer
                videoUrl={videoUrl}
                videoId={currentVideo.id}
                videoRef={videoRef}
                nodes={currentVideo.nodes}
              />

              {/* 悬浮工具栏 */}
              <div className="floating-toolbar">
                <button
                  className={`floating-btn ${panelMode !== 'chat-only' ? 'active' : ''}`}
                  onClick={toggleMathBoard}
                  title="画板 (Ctrl+B)"
                >
                  📐
                </button>
                <button
                  className={`floating-btn ${panelMode !== 'math-only' ? 'active' : ''}`}
                  onClick={() => setPanelMode('both')}
                  title="三栏并行（显示聊天）"
                >
                  💬
                </button>
                <button
                  className={`floating-btn ${showAnnotation ? 'active' : ''}`}
                  onClick={() => setShowAnnotation(!showAnnotation)}
                  title="标注 (Ctrl+A) - 点击再次关闭"
                >
                  ✏️
                </button>
                {/* 画板类型切换 */}
                {panelMode !== 'chat-only' && (
                  <div className="board-type-switcher">
                    <button
                      className={`type-btn ${mathBoardType === 'desmos' ? 'active' : ''}`}
                      onClick={() => setMathBoardType('desmos')}
                      title="Desmos 函数画板"
                    >
                      ƒ(x)
                    </button>
                    <button
                      className={`type-btn ${mathBoardType === 'geogebra' ? 'active' : ''}`}
                      onClick={() => setMathBoardType('geogebra')}
                      title="GeoGebra 几何画板"
                    >
                      △
                    </button>
                  </div>
                )}
              </div>

              {/* 画中画标注 */}
              <QuickAnnotation
                videoRef={videoRef}
                isActive={showAnnotation}
                onClose={() => setShowAnnotation(false)}
              />
            </div>

            {/* 数学画板 */}
            {panelMode !== 'chat-only' && (
              <div className="math-section" style={{
                flex: panelMode === 'both' ? '0 0 30%' : '0 0 50%'
              }}>
                {mathBoardType === 'desmos' ? (
                  <DesmosBoard
                    onClose={() => setPanelMode('chat-only')}
                    showAnnotation={showAnnotation}
                    onAnnotationClose={() => setShowAnnotation(false)}
                    onReady={(calc) => {
                      desmosCalculatorRef.current = calc;
                      executeDrawCommand('desmos', calc);
                    }}
                  />
                ) : (
                  <GeoGebraBoard
                    onClose={() => setPanelMode('chat-only')}
                    showAnnotation={showAnnotation}
                    onAnnotationClose={() => setShowAnnotation(false)}
                    onReady={(app) => {
                      geogebraAppRef.current = app;
                      executeDrawCommand('geogebra', app);
                    }}
                  />
                )}
              </div>
            )}

            {/* 对话面板 */}
            {panelMode !== 'math-only' && (
              <div className="chat-section" style={{
                flex: panelMode === 'both' ? '0 0 30%' : '0 0 400px'
              }}>
                <ChatPanel
                  videoId={currentVideo.id}
                  videoRef={videoRef}
                  onAutoDrawRequest={handleAutoDrawRequest}
                />
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
