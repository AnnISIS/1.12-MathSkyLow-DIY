import { useState, useRef, useEffect, RefObject } from 'react';
import katex from 'katex';
import 'katex/dist/katex.min.css';
import { ChatMessage } from '../types';
import './ChatPanel.css';

interface Props {
  videoId: string;
  videoRef: RefObject<HTMLVideoElement | null>;
  onAutoDrawRequest?: (drawData: any) => void;  // AI自动绘图回调
}

const ChatPanel = ({ videoId, videoRef, onAutoDrawRequest }: Props) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [status, setStatus] = useState<string>('idle');
  const [ragEnabled, setRagEnabled] = useState<boolean>(true); // RAG开关状态
  const [textInput, setTextInput] = useState<string>(''); // 文字输入框内容
  const [currentModel, setCurrentModel] = useState<string>('gpt-4o-mini'); // 当前LLM模型
  const [availableModels, setAvailableModels] = useState<Array<{id: string, name: string, provider: string}>>([]);
  const [showModelSelector, setShowModelSelector] = useState<boolean>(false); // 模型选择器显示状态
  const [ragMode, setRagMode] = useState<string>('vector'); // RAG检索模式: vector/bm25/hybrid
  const [showRagModeSelector, setShowRagModeSelector] = useState<boolean>(false); // RAG模式选择器显示状态

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const audioChunksRef = useRef<Float32Array[]>([]);
  const processingTimeoutRef = useRef<number | null>(null);
  const receivedAudioChunksRef = useRef<ArrayBuffer[]>([]);
  const currentAudioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const progressIntervalRef = useRef<number | null>(null); // 进度更新定时器

  // 组件加载时初始化可用模型列表
  useEffect(() => {
    // 设置默认可用模型列表
    setAvailableModels([
      {"id": "gpt-4o-mini", "name": "GPT-4o Mini (主站)", "provider": "OpenAI"},
      {"id": "gpt-4o-mini-副站", "name": "GPT-4o Mini (副站)", "provider": "OpenAI"},
      {"id": "gpt-4o", "name": "GPT-4o", "provider": "OpenAI"},
      {"id": "claude-3-5-sonnet", "name": "Claude 3.5 Sonnet", "provider": "Anthropic"},
      {"id": "claude-3-5-haiku", "name": "Claude 3.5 Haiku", "provider": "Anthropic"},
      {"id": "deepseek-chat", "name": "DeepSeek Chat", "provider": "DeepSeek"},
      {"id": "deepseek-reasoner", "name": "DeepSeek Reasoner (推理)", "provider": "DeepSeek"}
    ]);
  }, []);

  // 自动滚动到底部
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // 监听视频播放事件，播放时停止AI音频
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleVideoPlay = () => {
      console.log('📹 视频开始播放，停止AI音频');
      stopAIAudio();
    };

    video.addEventListener('play', handleVideoPlay);

    return () => {
      video.removeEventListener('play', handleVideoPlay);
    };
  }, [videoRef]);

  // 发送观看进度（每10秒）
  useEffect(() => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && videoRef.current) {
      // 清除之前的定时器
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }

      // 每10秒发送一次进度
      progressIntervalRef.current = setInterval(() => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && videoRef.current) {
          const currentTime = videoRef.current.currentTime;
          const duration = videoRef.current.duration;

          wsRef.current.send(JSON.stringify({
            command: 'update_progress',
            data: {
              current_time: currentTime,
              duration: duration
            }
          }));

          console.log(`📊 发送进度: ${currentTime.toFixed(1)}s / ${duration.toFixed(1)}s`);
        }
      }, 10000); // 10秒
    }

    // 清理
    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
        progressIntervalRef.current = null;
      }
    };
  }, [videoRef]);

  // 停止AI音频播放
  const stopAIAudio = () => {
    if (currentAudioSourceRef.current) {
      try {
        currentAudioSourceRef.current.stop();
        console.log('🔇 AI音频已停止');
      } catch (e) {
        // 音频可能已经停止
      }
      currentAudioSourceRef.current = null;
    }
  };

  // 切换RAG模式
  const toggleRAG = () => {
    const newRagEnabled = !ragEnabled;
    setRagEnabled(newRagEnabled);

    // 发送切换命令到后端
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        command: 'set_rag',
        data: { enabled: newRagEnabled }
      }));
      console.log(`⚙️ 切换RAG模式: ${newRagEnabled ? '启用' : '禁用'}`);
    }
  };

  // 切换LLM模型
  const switchModel = (modelId: string) => {
    setCurrentModel(modelId);
    setShowModelSelector(false);

    // 发送切换命令到后端
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        command: 'set_model',
        data: { model: modelId }
      }));
      console.log(`🔄 切换LLM模型: ${modelId}`);
    }
  };

  // 切换RAG检索模式
  const switchRagMode = (mode: string) => {
    setRagMode(mode);
    setShowRagModeSelector(false);

    // 发送切换命令到后端
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        command: 'set_rag_mode',
        data: { mode: mode }
      }));
      console.log(`🔍 切换RAG检索模式: ${mode}`);
    }
  };

  // 连接WebSocket
  const connectWebSocket = () => {
    const ws = new WebSocket(`ws://localhost:8000/api/ws/chat/${videoId}`);

    ws.onopen = () => {
      console.log('✅ WebSocket连接成功');
      setStatus('connected');

      // 连接成功后立即请求可用模型列表
      ws.send(JSON.stringify({
        command: 'set_model',
        data: { model: currentModel }
      }));
    };

    ws.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        // JSON消息
        const msg = JSON.parse(event.data);
        console.log('收到消息:', msg);

        switch (msg.type) {
          case 'auto_draw':
            // AI自动绘图指令
            console.log('🎨 收到自动绘图指令:', msg.data);
            if (onAutoDrawRequest) {
              onAutoDrawRequest(msg.data);
            }
            break;

          case 'asr_result':
            // 清除超时
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示用户问题
            setMessages(prev => [...prev, {
              type: 'text',
              content: msg.data,
              role: 'user'
            }]);
            setStatus('thinking');
            // 清空之前的音频块
            receivedAudioChunksRef.current = [];
            break;

          case 'ai_response':
            // 清除超时
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示AI回答文本
            const text = msg.data;

            // 解析文本中的LaTeX公式（$$...$$）
            const parts = text.split(/(\$\$.*?\$\$)/g);

            parts.forEach((part: string) => {
              if (part.startsWith('$$') && part.endsWith('$$')) {
                // LaTeX公式
                const latex = part.slice(2, -2);
                setMessages(prev => [...prev, {
                  type: 'latex',
                  content: latex
                }]);
              } else if (part.trim()) {
                // 普通文本
                setMessages(prev => [...prev, {
                  type: 'text',
                  content: part,
                  role: 'assistant'
                }]);
              }
            });
            setStatus('playing');
            break;

          case 'text_response':
            // 文字问答回复（无音频）
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示AI回答文本
            const textResponse = msg.data;

            // 解析文本中的LaTeX公式（$$...$$）
            const textParts = textResponse.split(/(\$\$.*?\$\$)/g);

            textParts.forEach((part: string) => {
              if (part.startsWith('$$') && part.endsWith('$$')) {
                // LaTeX公式
                const latex = part.slice(2, -2);
                setMessages(prev => [...prev, {
                  type: 'latex',
                  content: latex
                }]);
              } else if (part.trim()) {
                // 普通文本
                setMessages(prev => [...prev, {
                  type: 'text',
                  content: part,
                  role: 'assistant'
                }]);
              }
            });
            setStatus('connected');
            break;

          case 'audio_complete':
            // 所有音频块接收完毕，开始播放
            console.log(`✅ 接收到${receivedAudioChunksRef.current.length}个音频块`);
            if (receivedAudioChunksRef.current.length > 0) {
              await playAllAudioChunks();
            }
            setStatus('connected');
            setIsListening(false);
            break;

          case 'error':
            console.error('错误:', msg.data);
            setMessages(prev => [...prev, {
              type: 'text',
              content: `❌ 错误: ${msg.data}`,
              role: 'assistant'
            }]);
            setStatus('error');
            setIsListening(false);
            break;

          case 'rag_status':
            // 接收RAG状态
            const ragStatus = msg.data;
            setRagEnabled(ragStatus.enabled);
            console.log(`🔍 RAG状态更新: ${ragStatus.enabled ? '启用' : '禁用'}`);
            break;

          case 'model_status':
            // 接收模型状态
            const modelStatus = msg.data;
            setCurrentModel(modelStatus.current_model);
            if (modelStatus.available_models) {
              setAvailableModels(modelStatus.available_models);
            }
            console.log(`🔄 模型已切换: ${modelStatus.current_model}`);
            break;

          case 'rag_mode_status':
            // 接收RAG模式状态
            const ragModeStatus = msg.data;
            setRagMode(ragModeStatus.mode);
            console.log(`🔍 RAG检索模式已切换: ${ragModeStatus.mode}`);
            break;
        }
      } else {
        // 音频数据（二进制）
        const audioData = await event.data.arrayBuffer();
        console.log(`收到音频块: ${audioData.byteLength} 字节`);
        // 收集音频块，不立即播放
        receivedAudioChunksRef.current.push(audioData);
      }
    };

    ws.onerror = (error) => {
      console.error('❌ WebSocket错误:', error);
      setStatus('error');
    };

    ws.onclose = () => {
      console.log('WebSocket连接关闭');
      setStatus('idle');
    };

    wsRef.current = ws;
  };

  // 播放所有音频块
  const playAllAudioChunks = async () => {
    if (receivedAudioChunksRef.current.length === 0) {
      console.warn('⚠️ 没有音频数据');
      return;
    }

    // 计算总长度
    const totalBytes = receivedAudioChunksRef.current.reduce((acc, chunk) => acc + chunk.byteLength, 0);
    console.log(`🎵 准备播放: ${receivedAudioChunksRef.current.length}个块, 总计${totalBytes}字节`);

    // 合并所有音频块
    const combined = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of receivedAudioChunksRef.current) {
      combined.set(new Uint8Array(chunk), offset);
      offset += chunk.byteLength;
    }

    // 创建AudioContext
    if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
      audioContextRef.current = new AudioContext({ sampleRate: 16000 });
    }
    const audioContext = audioContextRef.current;

    // 将PCM数据转换为AudioBuffer
    const audioBuffer = audioContext.createBuffer(1, combined.length / 2, 16000);
    const channelData = audioBuffer.getChannelData(0);
    const view = new DataView(combined.buffer);

    for (let i = 0; i < channelData.length; i++) {
      // PCM 16位有符号整数转换为浮点数
      channelData[i] = view.getInt16(i * 2, true) / 32768.0;
    }

    // 停止之前的音频（如果有）
    stopAIAudio();

    // 播放
    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContext.destination);

    // 保存引用以便后续停止
    currentAudioSourceRef.current = source;

    // 播放结束时清除引用
    source.onended = () => {
      currentAudioSourceRef.current = null;
      console.log('✅ AI音频播放完成');
    };

    source.start();

    console.log('▶️ 开始播放音频');
  };

  // 开始录音
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      mediaStreamRef.current = stream;

      // 创建AudioContext
      const audioContext = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      // 清空音频块
      audioChunksRef.current = [];

      // 处理音频数据
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        // 复制数据
        const chunk = new Float32Array(inputData.length);
        chunk.set(inputData);
        audioChunksRef.current.push(chunk);
      };

      source.connect(processor);
      processor.connect(audioContext.destination);

      console.log('🎤 开始录音(PCM格式)...');
      setStatus('recording');
    } catch (error) {
      console.error('麦克风访问失败:', error);
      alert('无法访问麦克风，请检查浏览器权限设置');
      setIsListening(false);
    }
  };

  // 停止录音
  const stopRecording = () => {
    console.log('🛑 停止录音');

    // 停止处理器
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }

    // 关闭AudioContext
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    // 停止媒体流
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    // 发送音频数据到服务器
    console.log('WebSocket状态:', wsRef.current?.readyState);
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      // 合并所有Float32数据
      const totalLength = audioChunksRef.current.reduce((acc, arr) => acc + arr.length, 0);
      console.log(`音频块数量: ${audioChunksRef.current.length}, 总长度: ${totalLength}`);

      const combined = new Float32Array(totalLength);
      let offset = 0;
      for (const chunk of audioChunksRef.current) {
        combined.set(chunk, offset);
        offset += chunk.length;
      }

      // 转换为16位PCM
      const pcm16 = new Int16Array(combined.length);
      for (let i = 0; i < combined.length; i++) {
        const s = Math.max(-1, Math.min(1, combined[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }

      console.log(`发送PCM音频: ${pcm16.byteLength} 字节`);

      // 发送音频数据
      try {
        wsRef.current.send(pcm16.buffer);
        console.log('✅ 音频数据发送成功');
        setStatus('processing');

        // 设置30秒超时
        if (processingTimeoutRef.current) {
          clearTimeout(processingTimeoutRef.current);
        }
        processingTimeoutRef.current = setTimeout(() => {
          console.warn('⏱️ 处理超时');
          setStatus('connected');
          setMessages(prev => [...prev, {
            type: 'text',
            content: '⏱️ 处理超时，请重试',
            role: 'assistant'
          }]);
        }, 30000);
      } catch (error) {
        console.error('❌ 发送音频失败:', error);
        setStatus('error');
      }
    } else {
      console.error('❌ WebSocket未连接或已关闭');
      setStatus('error');
    }
  };

  // 处理文字提交
  const handleTextSubmit = () => {
    if (!textInput.trim()) return;

    // 暂停视频
    if (videoRef.current && !videoRef.current.paused) {
      videoRef.current.pause();
      console.log('视频已暂停');
    }

    // 连接WebSocket（如果未连接）
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      connectWebSocket();
      // 等待连接后发送
      setTimeout(() => {
        sendTextQuestion();
      }, 500);
    } else {
      sendTextQuestion();
    }
  };

  // 发送文字问题
  const sendTextQuestion = () => {
    if (!textInput.trim() || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    try {
      // 显示用户问题
      setMessages(prev => [...prev, {
        type: 'text',
        content: textInput,
        role: 'user'
      }]);

      // 获取当前视频时间点
      const questionTime = videoRef.current ? videoRef.current.currentTime : null;

      // 发送文字问题到后端（包含视频时间点）
      wsRef.current.send(JSON.stringify({
        command: 'text_question',
        data: {
          question: textInput,
          question_time: questionTime
        }
      }));

      console.log('发送文字问题:', textInput, '时间点:', questionTime);
      setStatus('thinking');
      setTextInput(''); // 清空输入框

      // 设置超时
      if (processingTimeoutRef.current) {
        clearTimeout(processingTimeoutRef.current);
      }
      processingTimeoutRef.current = setTimeout(() => {
        console.warn('处理超时');
        setStatus('connected');
        setMessages(prev => [...prev, {
          type: 'text',
          content: '处理超时，请重试',
          role: 'assistant'
        }]);
      }, 60000);  // 增加到60秒
    } catch (error) {
      console.error('发送文字问题失败:', error);
      setStatus('error');
    }
  };

  // 处理提问按钮点击
  const handleAskClick = () => {
    if (!isListening) {
      // 开始提问 - 暂停视频
      if (videoRef.current && !videoRef.current.paused) {
        videoRef.current.pause();
        console.log('视频已暂停');
      }

      // 开始提问
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        connectWebSocket();
        // 等待连接成功后再开始录音
        setTimeout(() => {
          startRecording();
          setIsListening(true);
        }, 500);
      } else {
        startRecording();
        setIsListening(true);
      }
    } else {
      // 停止提问
      stopRecording();
      setIsListening(false);
    }
  };

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (processorRef.current) {
        processorRef.current.disconnect();
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (processingTimeoutRef.current) {
        clearTimeout(processingTimeoutRef.current);
      }
      // 停止AI音频
      stopAIAudio();
    };
  }, []);

  const renderLatex = (latex: string) => {
    try {
      const html = katex.renderToString(latex, {
        throwOnError: false,
        displayMode: true
      });
      return <div dangerouslySetInnerHTML={{ __html: html }} className="latex-block" />;
    } catch (e) {
      return <div className="latex-error">LaTeX渲染错误</div>;
    }
  };

  // 状态显示文本
  const getStatusText = () => {
    switch (status) {
      case 'recording':
        return '🎤 正在录音...';
      case 'processing':
        return '🔄 识别中...';
      case 'thinking':
        return '💭 AI思考中...';
      case 'playing':
        return '🔊 播放中...';
      case 'error':
        return '❌ 出错了';
      default:
        return '';
    }
  };

  return (
    <div className="chat-panel">
      <div className="chat-header">
        <div className="header-left">
          <h3>💬 问答区</h3>
          <span className="video-id">视频 ID: {videoId.slice(0, 8)}...</span>
        </div>
        <div className="header-right">
          {/* 模型选择器移到右上角 */}
          <div className="model-selector-container-header">
            <button
              className="model-selector-button-compact"
              onClick={() => setShowModelSelector(!showModelSelector)}
              disabled={status === 'processing' || status === 'thinking'}
            >
              🤖 {availableModels.find(m => m.id === currentModel)?.name || currentModel}
            </button>
            {showModelSelector && (
              <div className="model-dropdown-header">
                {availableModels.length > 0 ? (
                  availableModels.map(model => (
                    <div
                      key={model.id}
                      className={`model-option ${model.id === currentModel ? 'active' : ''}`}
                      onClick={() => switchModel(model.id)}
                    >
                      <span className="model-name">{model.name}</span>
                      <span className="model-provider">{model.provider}</span>
                    </div>
                  ))
                ) : (
                  <div className="model-option disabled">加载中...</div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {status !== 'idle' && status !== 'connected' && (
        <div className="status-indicator">{getStatusText()}</div>
      )}

      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="empty-state">
            <p>👋 点击下方"提问"按钮</p>
            <p>随时向AI老师提问！</p>
          </div>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`message ${msg.role || 'system'}`}>
              {msg.type === 'text' && (
                <div className="message-content">
                  <span className="message-role">
                    {msg.role === 'user' ? '👤 学生' : '🤖 AI老师'}
                  </span>
                  <p>{msg.content}</p>
                </div>
              )}
              {msg.type === 'latex' && renderLatex(msg.content || '')}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="chat-controls">
        <div className="rag-toggle">
          <label className="toggle-switch">
            <input
              type="checkbox"
              checked={ragEnabled}
              onChange={toggleRAG}
              disabled={status === 'processing' || status === 'thinking'}
            />
            <span className="toggle-slider"></span>
          </label>
          <span className="toggle-label">
            {ragEnabled ? '🔍 RAG语义检索' : '📄 简单截取'}
          </span>
        </div>

        {/* RAG检索模式选择器（仅在RAG启用时显示） */}
        {ragEnabled && (
          <div className="rag-mode-selector">
            <button
              className="rag-mode-button"
              onClick={() => setShowRagModeSelector(!showRagModeSelector)}
              disabled={status === 'processing' || status === 'thinking'}
            >
              {ragMode === 'vector' && '🔍 向量检索'}
              {ragMode === 'bm25' && '🔤 关键词检索'}
              {ragMode === 'hybrid' && '⚡ 混合检索'}
            </button>
            {showRagModeSelector && (
              <div className="rag-mode-dropdown">
                <div
                  className={`rag-mode-option ${ragMode === 'vector' ? 'active' : ''}`}
                  onClick={() => switchRagMode('vector')}
                >
                  🔍 向量检索
                  <span className="mode-desc">语义理解</span>
                </div>
                <div
                  className={`rag-mode-option ${ragMode === 'bm25' ? 'active' : ''}`}
                  onClick={() => switchRagMode('bm25')}
                >
                  🔤 关键词检索(BM25)
                  <span className="mode-desc">关键词匹配</span>
                </div>
                <div
                  className={`rag-mode-option ${ragMode === 'hybrid' ? 'active' : ''}`}
                  onClick={() => switchRagMode('hybrid')}
                >
                  ⚡ 混合检索
                  <span className="mode-desc">0.7向量 + 0.3关键词</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 文字输入区域 */}
        <div className="text-input-container">
          <input
            type="text"
            className="text-input"
            placeholder="输入问题..."
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && textInput.trim()) {
                handleTextSubmit();
              }
            }}
            disabled={status === 'processing' || status === 'thinking'}
          />
          <button
            className="text-submit-button"
            onClick={handleTextSubmit}
            disabled={!textInput.trim() || status === 'processing' || status === 'thinking'}
          >
            发送
          </button>
        </div>

        <button
          className={`ask-button ${isListening ? 'listening' : ''}`}
          onClick={handleAskClick}
          disabled={status === 'processing' || status === 'thinking'}
        >
          {isListening ? '🛑 停止提问' : '🎤 提问'}
        </button>
      </div>
    </div>
  );
};

export default ChatPanel;
