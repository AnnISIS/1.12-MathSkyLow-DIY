import { useEffect, useRef, useState } from 'react';
import { QuickAnnotation } from './QuickAnnotation';
import './DesmosBoard.css';

interface DesmosBoardProps {
  onReady?: (calculator: any) => void;
  onClose?: () => void;
  showAnnotation?: boolean;  // 新增：是否显示标注
  onAnnotationClose?: () => void;  // 新增：标注关闭回调
}

export function DesmosBoard({ onReady, onClose, showAnnotation = false, onAnnotationClose }: DesmosBoardProps) {
  const calculatorRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);  // 新增：容器引用
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // 检查Desmos是否已加载
    if ((window as any).Desmos) {
      initCalculator();
      return;
    }

    // 加载Desmos脚本
    const script = document.createElement('script');
    script.src = 'https://www.desmos.com/api/v1.8/calculator.js?apiKey=dcb31709b452b1cf9dc26972add0fda6';
    script.async = true;

    script.onload = () => {
      initCalculator();
    };

    script.onerror = () => {
      console.error('Failed to load Desmos API');
      setIsLoading(false);
    };

    document.body.appendChild(script);

    return () => {
      // 清理calculator实例
      if (calculatorRef.current) {
        try {
          calculatorRef.current.destroy();
        } catch (e) {
          console.error('Error destroying calculator:', e);
        }
      }
    };
  }, []);

  const initCalculator = () => {
    try {
      const elt = document.getElementById('desmos-calculator');
      if (!elt) return;

      calculatorRef.current = (window as any).Desmos.GraphingCalculator(elt, {
        keypad: false,
        expressions: false,
        settingsMenu: false,
        zoomButtons: true,
        expressionsTopbar: false,
        border: false,
        lockViewport: false
      });

      setIsLoading(false);
      onReady?.(calculatorRef.current);
    } catch (e) {
      console.error('Error initializing calculator:', e);
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    if (calculatorRef.current) {
      calculatorRef.current.setBlank();
    }
  };

  const handleScreenshot = () => {
    if (calculatorRef.current) {
      calculatorRef.current.screenshot({
        width: 1200,
        height: 800,
        targetPixelRatio: 2
      }, (data: string) => {
        // 下载截图
        const link = document.createElement('a');
        link.href = data;
        link.download = `desmos-${Date.now()}.png`;
        link.click();
      });
    }
  };

  const handleAddFunction = () => {
    if (calculatorRef.current) {
      const latex = prompt('输入函数表达式 (例如: y=x^2):');
      if (latex) {
        calculatorRef.current.setExpression({
          id: `func-${Date.now()}`,
          latex: latex
        });
      }
    }
  };

  return (
    <div className="desmos-board">
      <div className="desmos-header">
        <h3>📐 Desmos 画板</h3>
        <button className="close-button" onClick={onClose}>✕</button>
      </div>

      <div className="desmos-toolbar">
        <button className="toolbar-btn" onClick={handleAddFunction} title="添加函数">
          ƒ(x) 函数
        </button>
        <button className="toolbar-btn" onClick={handleClear} title="清空画板">
          🗑️ 清空
        </button>
        <button className="toolbar-btn" onClick={handleScreenshot} title="截图">
          📷 截图
        </button>
      </div>

      {isLoading && (
        <div className="desmos-loading">
          <div className="spinner"></div>
          <p>正在加载 Desmos...</p>
        </div>
      )}

      <div className="desmos-container-wrapper" style={{ position: 'relative' }}>
        <div
          ref={containerRef}
          id="desmos-calculator"
          className="desmos-calculator"
          style={{ display: isLoading ? 'none' : 'block' }}
        />

        {/* 画板标注 */}
        {showAnnotation && (
          <QuickAnnotation
            containerRef={containerRef}
            isActive={showAnnotation}
            onClose={() => onAnnotationClose?.()}
            pauseVideo={false}
          />
        )}
      </div>
    </div>
  );
}
