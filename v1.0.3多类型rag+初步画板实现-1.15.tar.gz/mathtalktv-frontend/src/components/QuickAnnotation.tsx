import { useRef, useState, useEffect, RefObject } from 'react';
import './QuickAnnotation.css';

interface QuickAnnotationProps {
  videoRef?: RefObject<HTMLVideoElement | null>;
  containerRef?: RefObject<HTMLDivElement | null>;  // 新增：支持画板容器
  isActive: boolean;
  onClose: () => void;
  pauseVideo?: boolean;  // 新增：是否需要暂停视频（默认 true）
}

interface Point {
  x: number;
  y: number;
}

export function QuickAnnotation({ videoRef, containerRef, isActive, onClose, pauseVideo = true }: QuickAnnotationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState('#FF0000');
  const [lineWidth, setLineWidth] = useState(3);
  const [tool, setTool] = useState<'pen' | 'eraser'>('pen');
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyStep, setHistoryStep] = useState(-1);

  useEffect(() => {
    if (!isActive || !canvasRef.current) return;

    const canvas = canvasRef.current;

    // 获取目标容器（视频或画板）
    const targetElement = videoRef?.current || containerRef?.current;
    if (!targetElement) return;

    // 设置canvas尺寸与目标容器相同
    const rect = targetElement.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;

    // 暂停视频（如果有且需要）
    if (pauseVideo && videoRef?.current && !videoRef.current.paused) {
      videoRef.current.pause();
    }

    // 初始化历史
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      setHistory([imageData]);
      setHistoryStep(0);
    }
  }, [isActive, videoRef, containerRef, pauseVideo]);

  const saveHistory = () => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
    const newHistory = history.slice(0, historyStep + 1);
    newHistory.push(imageData);
    setHistory(newHistory);
    setHistoryStep(newHistory.length - 1);
  };

  const undo = () => {
    if (historyStep > 0 && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;

      setHistoryStep(historyStep - 1);
      ctx.putImageData(history[historyStep - 1], 0, 0);
    }
  };

  const clearCanvas = () => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    saveHistory();
  };

  const getPointerPosition = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>): Point => {
    if (!canvasRef.current) return { x: 0, y: 0 };

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();

    // 获取Canvas的缩放比例
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if ('touches' in e) {
      const touch = e.touches[0];
      return {
        x: (touch.clientX - rect.left) * scaleX,
        y: (touch.clientY - rect.top) * scaleY
      };
    } else {
      return {
        x: (e.clientX - rect.left) * scaleX,
        y: (e.clientY - rect.top) * scaleY
      };
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    setIsDrawing(true);

    const pos = getPointerPosition(e);
    if (!canvasRef.current) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (!isDrawing || !canvasRef.current) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    const pos = getPointerPosition(e);

    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = tool === 'eraser' ? '#FFFFFF' : color;
    ctx.lineWidth = tool === 'eraser' ? lineWidth * 3 : lineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      saveHistory();
    }
  };

  if (!isActive) return null;

  return (
    <div className="quick-annotation-overlay">
      <div className="annotation-toolbar">
        <div className="toolbar-group">
          <button
            className={`tool-btn ${tool === 'pen' ? 'active' : ''}`}
            onClick={() => setTool('pen')}
            title="画笔"
          >
            ✏️ 画笔
          </button>
          <button
            className={`tool-btn ${tool === 'eraser' ? 'active' : ''}`}
            onClick={() => setTool('eraser')}
            title="橡皮擦"
          >
            🧹 橡皮
          </button>
        </div>

        <div className="toolbar-group">
          <label className="color-label">
            颜色:
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="color-picker"
            />
          </label>

          <label className="width-label">
            粗细:
            <input
              type="range"
              min="1"
              max="10"
              value={lineWidth}
              onChange={(e) => setLineWidth(Number(e.target.value))}
              className="width-slider"
            />
            <span>{lineWidth}</span>
          </label>
        </div>

        <div className="toolbar-group">
          <button
            className="tool-btn"
            onClick={undo}
            disabled={historyStep <= 0}
            title="撤销"
          >
            ↶ 撤销
          </button>
          <button
            className="tool-btn"
            onClick={clearCanvas}
            title="清空"
          >
            🗑️ 清空
          </button>
        </div>

        <button
          className="tool-btn done-btn"
          onClick={onClose}
        >
          ✓ 完成
        </button>
      </div>

      <canvas
        ref={canvasRef}
        className="annotation-canvas"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={stopDrawing}
      />

      <div className="annotation-hint">
        💡 提示: 在视频画面上绘制标注，完成后点击"完成"按钮
      </div>
    </div>
  );
}
