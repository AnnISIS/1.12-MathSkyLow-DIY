import { useState } from 'react';
import { videoApi } from '../api';
import './VideoUploader.css';

interface Props {
  onVideoUploaded: (videoId: string) => void;
}

const VideoUploader = ({ onVideoUploaded }: Props) => {
  const [uploading, setUploading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState('');
  const [error, setError] = useState('');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // 检查文件类型
    if (!file.type.startsWith('video/')) {
      setError('请选择视频文件');
      return;
    }

    // 检查文件大小（500MB）
    if (file.size > 500 * 1024 * 1024) {
      setError('视频文件不能超过500MB');
      return;
    }

    setError('');
    setUploading(true);
    setProgress('正在上传视频...');

    try {
      // 1. 上传视频
      const uploadResult = await videoApi.uploadVideo(file);
      console.log('上传成功:', uploadResult);

      setUploading(false);
      setProcessing(true);
      setProgress('视频已上传，正在提取字幕...');

      // 2. 等待字幕提取完成（已经在上传接口中同步处理）
      if (uploadResult.status === 'failed') {
        throw new Error('视频处理失败');
      }

      setProgress('字幕提取完成，正在识别知识点节点...');

      // 3. 提取节点
      try {
        const nodesResult = await videoApi.extractNodes(uploadResult.video_id);
        console.log('节点识别成功:', nodesResult);
        setProgress('知识点识别完成！');
      } catch (nodeError) {
        console.warn('节点识别失败，但可以继续使用:', nodeError);
        setProgress('知识点识别失败，将进入通用答疑模式');
      }

      // 4. 获取视频详情
      const videoDetail = await videoApi.getVideoDetail(uploadResult.video_id);
      console.log('视频详情:', videoDetail);

      setTimeout(() => {
        setProcessing(false);
        onVideoUploaded(uploadResult.video_id);
      }, 1000);

    } catch (err: any) {
      console.error('处理失败:', err);
      setError(err.response?.data?.detail || err.message || '视频处理失败');
      setUploading(false);
      setProcessing(false);
    }
  };

  return (
    <div className="video-uploader">
      <div className="uploader-card">
        <div className="uploader-icon">🎥</div>
        <h2>上传数学视频</h2>
        <p>支持 MP4 格式，最大 500MB</p>

        {!uploading && !processing && (
          <>
            <label htmlFor="video-input" className="upload-button">
              选择视频文件
            </label>
            <input
              id="video-input"
              type="file"
              accept="video/*"
              onChange={handleFileChange}
              style={{ display: 'none' }}
            />
          </>
        )}

        {(uploading || processing) && (
          <div className="progress-container">
            <div className="spinner"></div>
            <p className="progress-text">{progress}</p>
          </div>
        )}

        {error && (
          <div className="error-message">
            ❌ {error}
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoUploader;
