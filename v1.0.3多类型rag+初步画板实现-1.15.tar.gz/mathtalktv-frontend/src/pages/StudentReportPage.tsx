import { useState, useEffect } from 'react';
import { StudentReport } from '../types/report';
import './StudentReportPage.css';

const StudentReportPage = () => {
  const [report, setReport] = useState<StudentReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const studentId = 'demo_student'; // 暂时使用固定ID，后续接入登录系统

  useEffect(() => {
    fetchStudentReport();
  }, []);

  const fetchStudentReport = async () => {
    try {
      setLoading(true);
      const response = await fetch(`http://localhost:8000/api/reports/student/${studentId}`);
      if (!response.ok) throw new Error('获取报告失败');

      const data = await response.json();
      setReport(data);
      setError(null);
    } catch (err: any) {
      setError(err.message);
      console.error('获取学生报告失败:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) {
      return `${hours}小时${minutes}分钟`;
    }
    return `${minutes}分钟`;
  };

  const formatPercentage = (rate: number): string => {
    return `${(rate * 100).toFixed(1)}%`;
  };

  if (loading) {
    return (
      <div className="report-container">
        <div className="loading">加载中...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="report-container">
        <div className="error">❌ {error}</div>
      </div>
    );
  }

  if (!report) {
    return (
      <div className="report-container">
        <div className="empty-state">
          <p>📊 暂无学习数据</p>
          <p>开始观看视频并提问，就能生成你的学习报告！</p>
        </div>
      </div>
    );
  }

  return (
    <div className="report-container">
      <div className="report-header">
        <h1>📚 我的学习报告</h1>
        <button className="refresh-btn" onClick={fetchStudentReport}>
          🔄 刷新
        </button>
      </div>

      {/* 基本统计卡片 */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">⏱️</div>
          <div className="stat-content">
            <div className="stat-label">总学习时长</div>
            <div className="stat-value">{formatTime(report.total_watch_time)}</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon">📹</div>
          <div className="stat-content">
            <div className="stat-label">学习次数</div>
            <div className="stat-value">{report.total_sessions}次</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon">❓</div>
          <div className="stat-content">
            <div className="stat-label">提问总数</div>
            <div className="stat-value">{report.total_questions}个</div>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-content">
            <div className="stat-label">平均完成率</div>
            <div className="stat-value">{formatPercentage(report.avg_completion_rate)}</div>
          </div>
        </div>
      </div>

      {/* 学习偏好 */}
      <div className="section">
        <h2>🎯 学习偏好</h2>
        <div className="preferences-container">
          <div className="preference-item">
            <span className="pref-label">提问方式：</span>
            <span className="pref-value">
              {report.learning_preferences.question_style === 'voice' ? '🎤 语音提问' : '⌨️ 文字提问'}
            </span>
          </div>
          <div className="preference-item">
            <span className="pref-label">学习模式：</span>
            <span className="pref-value">{report.learning_preferences.learning_mode}</span>
          </div>
          <div className="preference-item">
            <span className="pref-label">活跃程度：</span>
            <span className="pref-value">{report.learning_preferences.active_level}</span>
          </div>
        </div>
      </div>

      {/* 薄弱知识点 */}
      {report.weak_concepts && report.weak_concepts.length > 0 && (
        <div className="section">
          <h2>⚠️ 薄弱知识点</h2>
          <div className="weak-concepts">
            {report.weak_concepts.map((concept, index) => (
              <div key={index} className="concept-tag weak">
                {concept}
              </div>
            ))}
          </div>
          <p className="hint">💡 建议重点复习这些知识点</p>
        </div>
      )}

      {/* 知识点掌握度 */}
      {Object.keys(report.mastery_distribution).length > 0 && (
        <div className="section">
          <h2>📊 知识点掌握度</h2>
          <div className="mastery-list">
            {Object.entries(report.mastery_distribution)
              .sort(([, a], [, b]) => a - b) // 按掌握度排序
              .map(([concept, mastery]) => (
                <div key={concept} className="mastery-item">
                  <div className="mastery-label">{concept}</div>
                  <div className="mastery-bar-container">
                    <div
                      className={`mastery-bar ${mastery >= 0.7 ? 'good' : mastery >= 0.5 ? 'medium' : 'low'}`}
                      style={{ width: `${mastery * 100}%` }}
                    >
                      <span className="mastery-percentage">{formatPercentage(mastery)}</span>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* 学习趋势 */}
      {report.learning_trend && report.learning_trend.length > 0 && (
        <div className="section">
          <h2>📈 最近学习趋势</h2>
          <div className="trend-container">
            {report.learning_trend.slice(0, 10).reverse().map((day, index) => {
              const maxTime = Math.max(...report.learning_trend.map(d => d.watch_time));
              const height = (day.watch_time / maxTime) * 100;

              return (
                <div key={index} className="trend-bar-wrapper">
                  <div className="trend-bar" style={{ height: `${height}%` }}>
                    <div className="trend-tooltip">
                      <div>{day.date}</div>
                      <div>{day.sessions}次学习</div>
                      <div>{formatTime(day.watch_time)}</div>
                    </div>
                  </div>
                  <div className="trend-label">{day.date.slice(5)}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentReportPage;
