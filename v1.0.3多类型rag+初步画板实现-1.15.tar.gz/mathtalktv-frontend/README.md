# MathTalkTV 前端

初中生数学智能讲题平台 - 前端应用

## 当前状态

✅ **已完成功能**：
- 视频上传界面
- 视频播放器
- 聊天对话界面
- LaTeX公式渲染
- 倾听按钮（UI）

🚧 **待完成功能**：
- WebSocket实时通信
- 语音采集
- 实时ASR/TTS

## 运行

```bash
npm install
npm run dev
```

访问：http://localhost:5173

## 测试步骤

1. **启动后端服务**（在 `mathtalktv-backend` 目录）
   ```bash
   source venv/bin/activate
   python run.py
   ```

2. **启动前端**（在当前目录）
   ```bash
   npm run dev
   ```

3. **测试上传功能**
   - 打开浏览器访问 http://localhost:5173
   - 点击"选择视频文件"
   - 选择一个数学教学视频（MP4格式，<500MB）
   - 等待处理完成（会自动提取字幕和识别节点）

4. **查看视频播放**
   - 上传完成后会自动跳转到播放页面
   - 左侧：视频播放器
   - 右侧：聊天对话面板

5. **测试对话界面**（目前是演示模式）
   - 点击"提问"按钮
   - 会显示模拟的问答对话和LaTeX公式

## 技术栈

- **React 18** - UI框架
- **TypeScript** - 类型安全
- **Vite** - 构建工具
- **React Player** - 视频播放
- **KaTeX** - LaTeX公式渲染
- **Axios** - HTTP客户端

## 项目结构

```
src/
├── api/              # API接口
├── components/       # React组件
│   ├── VideoUploader.tsx
│   ├── VideoPlayer.tsx
│   └── ChatPanel.tsx
├── types/            # TypeScript类型定义
├── App.tsx           # 主应用
└── main.tsx          # 入口文件
```

## API端点

- `POST /api/upload` - 上传视频
- `GET /api/videos/:id` - 获取视频详情
- `GET /api/videos/:id/subtitles` - 获取字幕
- `POST /api/videos/:id/extract-nodes` - 提取节点
