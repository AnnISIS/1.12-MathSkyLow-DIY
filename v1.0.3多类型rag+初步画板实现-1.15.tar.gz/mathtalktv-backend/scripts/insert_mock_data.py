"""
生成Mock数据用于测试报告功能
"""
import asyncio
import aiosqlite
import uuid
from datetime import datetime, timedelta
import random

DB_PATH = "data/mathtalktv.db"


async def insert_mock_data():
    """插入mock数据"""
    async with aiosqlite.connect(DB_PATH) as db:
        # 1. 创建几个学习会话
        student_id = "demo_student"

        # 获取第一个视频ID
        cursor = await db.execute("SELECT id FROM videos LIMIT 1")
        video = await cursor.fetchone()
        if not video:
            print("❌ 请先上传一个视频")
            return

        video_id = video[0]
        print(f"📹 使用视频ID: {video_id}")

        # 创建5个学习会话
        sessions = []
        for i in range(5):
            session_id = str(uuid.uuid4())
            sessions.append(session_id)

            start_time = datetime.now() - timedelta(days=i+1)
            end_time = start_time + timedelta(minutes=random.randint(10, 30))
            watch_duration = random.uniform(300, 1200)  # 5-20分钟
            completion_rate = random.uniform(0.5, 1.0)

            await db.execute("""
                INSERT INTO learning_sessions
                (id, student_id, video_id, start_time, end_time, watch_duration, completion_rate)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (session_id, student_id, video_id, start_time, end_time, watch_duration, completion_rate))

            print(f"✅ 创建会话 {i+1}: {session_id[:8]}... 完成率={completion_rate:.1%}")

        # 2. 为每个会话创建提问记录
        questions_data = [
            ("配方法怎么用？", "配方法是解一元二次方程的重要方法...", 0.75, 120.5, True),
            ("因式分解的步骤是什么？", "因式分解主要有提取公因式、平方差、完全平方...", 0.65, 240.3, True),
            ("这个方程怎么解？", "让我帮你分析这个方程...", 0.85, 360.8, True),
            ("为什么要配方？", "配方的目的是将二次项和一次项组合成完全平方式...", 0.55, 180.2, True),
            ("今天天气怎么样？", "同学，这个问题与数学课程关系不大...", 0.15, 90.5, False),
            ("函数的定义是什么？", "函数是描述两个变量之间对应关系的数学概念...", 0.70, 420.1, True),
            ("三角形的性质有哪些？", "三角形有很多重要性质，比如内角和180度...", 0.60, 500.3, True),
        ]

        for i, session_id in enumerate(sessions):
            # 每个会话2-3个问题
            num_questions = random.randint(2, 3)
            for j in range(num_questions):
                question_data = random.choice(questions_data)
                question_text, answer_text, confidence, q_time, is_relevant = question_data
                question_type = random.choice(["text", "voice"])
                satisfaction = random.randint(3, 5) if is_relevant else None

                await db.execute("""
                    INSERT INTO question_records
                    (session_id, student_id, video_id, question_text, answer_text,
                     confidence_score, question_time, question_type, rag_enabled, is_relevant, satisfaction_rating)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    session_id, student_id, video_id, question_text, answer_text,
                    confidence, q_time + j*60, question_type, True, is_relevant, satisfaction
                ))

        print(f"✅ 创建了 {len(sessions) * 2} 条提问记录")

        # 3. 创建节点交互记录
        cursor = await db.execute("SELECT id FROM nodes WHERE video_id = ? LIMIT 3", (video_id,))
        nodes = await cursor.fetchall()

        if nodes:
            for session_id in sessions[:3]:  # 前3个会话有节点交互
                for node in nodes:
                    if random.random() > 0.5:  # 50%概率点击
                        await db.execute("""
                            INSERT INTO node_interactions
                            (session_id, student_id, video_id, node_id, interaction_type)
                            VALUES (?, ?, ?, ?, ?)
                        """, (session_id, student_id, video_id, node[0], "click"))

            print(f"✅ 创建了节点交互记录")

        # 4. 创建知识点掌握度记录
        concepts = [
            ("配方法", 0.65),
            ("因式分解", 0.75),
            ("一元二次方程", 0.80),
            ("函数", 0.55),
            ("三角形", 0.70)
        ]

        for concept_name, mastery_level in concepts:
            question_count = random.randint(3, 8)
            correct_count = int(question_count * mastery_level)

            await db.execute("""
                INSERT INTO concept_mastery
                (student_id, concept_name, mastery_level, question_count, correct_count, last_reviewed)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (student_id, concept_name, mastery_level, question_count, correct_count, datetime.now()))

        print(f"✅ 创建了 {len(concepts)} 个知识点掌握度记录")

        await db.commit()
        print("\n🎉 Mock数据插入完成！")
        print(f"\n可以访问以下接口查看报告：")
        print(f"  - 视频报告: http://localhost:8000/api/reports/video/{video_id}")
        print(f"  - 学生报告: http://localhost:8000/api/reports/student/{student_id}")
        print(f"  - 热力图: http://localhost:8000/api/reports/video/{video_id}/heatmap")
        print(f"  - 词云: http://localhost:8000/api/reports/video/{video_id}/wordcloud")


if __name__ == "__main__":
    print("🚀 开始生成Mock数据...")
    asyncio.run(insert_mock_data())
