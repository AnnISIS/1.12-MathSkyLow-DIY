"""
为所有节点生成embedding向量
"""
import asyncio
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import aiosqlite
import json
from openai import AsyncOpenAI
from app.core.config import settings

client = AsyncOpenAI(
    api_key=settings.UIUIAPI_KEY,
    base_url=settings.UIUIAPI_BASE_URL
)

async def get_embedding(text: str):
    """获取文本的embedding向量"""
    try:
        response = await client.embeddings.create(
            model="text-embedding-ada-002",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        print(f"❌ Embedding生成失败: {e}")
        return None

async def generate_embeddings():
    """为所有没有embedding的节点生成embedding"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        # 查找所有没有embedding的节点
        cursor = await db.execute("""
            SELECT id, title, summary, transcript
            FROM nodes
            WHERE embedding IS NULL
        """)
        nodes = await cursor.fetchall()

        if not nodes:
            print("✅ 所有节点都已有embedding")
            return

        print(f"📊 找到 {len(nodes)} 个节点需要生成embedding")

        for i, (node_id, title, summary, transcript) in enumerate(nodes, 1):
            print(f"[{i}/{len(nodes)}] 处理节点: {title}")

            # 组合标题、摘要和字幕内容作为embedding输入
            # 优先级: 标题 > 摘要 > 字幕前500字
            transcript_part = (transcript or "")[:500]
            embedding_text = f"{title}\n{summary or ''}\n{transcript_part}"

            # 生成embedding
            embedding = await get_embedding(embedding_text)

            if embedding:
                # 保存到数据库
                await db.execute("""
                    UPDATE nodes
                    SET embedding = ?
                    WHERE id = ?
                """, (json.dumps(embedding), node_id))

                await db.commit()
                print(f"  ✅ Embedding已生成并保存")
            else:
                print(f"  ❌ Embedding生成失败")

            # 稍微延迟避免API限流
            await asyncio.sleep(0.5)

        print(f"\n🎉 完成! 已为 {len(nodes)} 个节点生成embedding")

if __name__ == "__main__":
    print("🚀 开始为节点生成embedding向量...\n")
    asyncio.run(generate_embeddings())
