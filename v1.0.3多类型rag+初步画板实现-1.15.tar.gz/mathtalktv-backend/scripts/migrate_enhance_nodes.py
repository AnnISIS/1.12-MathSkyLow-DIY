"""
节点数据迁移脚本
为现有视频的节点生成增强数据（title, summary, keyConcepts, embedding）
"""
import asyncio
import logging
import sys
import json
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

import aiosqlite
from app.core.config import settings
from app.services.node_enhancer import NodeEnhancer, generate_node_transcript
from app.services.node_embedding import NodeEmbeddingService

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def get_videos_with_nodes():
    """获取所有包含节点的视频"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT DISTINCT video_id
            FROM nodes
            ORDER BY video_id
        """)
        rows = await cursor.fetchall()
        return [row["video_id"] for row in rows]


async def get_video_nodes(video_id: str):
    """获取某个视频的所有节点"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT id, video_id, order_num, start_time, end_time,
                   title, summary, key_concepts, transcript, embedding
            FROM nodes
            WHERE video_id = ?
            ORDER BY order_num
        """, (video_id,))
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]


async def update_node_enhancement(node_id: str, title: str, summary: str, key_concepts: list, transcript: str):
    """更新节点的增强内容"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        await db.execute("""
            UPDATE nodes
            SET title = ?,
                summary = ?,
                key_concepts = ?,
                transcript = ?
            WHERE id = ?
        """, (title, summary, json.dumps(key_concepts, ensure_ascii=False), transcript, node_id))
        await db.commit()
        logger.info(f"  ✅ 已更新节点增强内容: {node_id}")


async def update_node_embedding(node_id: str, embedding: list):
    """更新节点的embedding"""
    async with aiosqlite.connect(settings.DB_PATH) as db:
        await db.execute("""
            UPDATE nodes
            SET embedding = ?
            WHERE id = ?
        """, (json.dumps(embedding), node_id))
        await db.commit()
        logger.info(f"  ✅ 已更新节点embedding: {node_id}")


async def migrate_video_nodes(video_id: str, enhancer: NodeEnhancer, embedding_service: NodeEmbeddingService):
    """迁移单个视频的所有节点"""
    logger.info(f"\n{'='*80}")
    logger.info(f"🎬 开始处理视频: {video_id}")
    logger.info(f"{'='*80}")

    # 1. 获取该视频的所有节点
    nodes = await get_video_nodes(video_id)
    logger.info(f"📦 找到 {len(nodes)} 个节点")

    if not nodes:
        logger.warning(f"⚠️ 视频 {video_id} 没有节点，跳过")
        return

    success_count = 0
    skip_count = 0
    error_count = 0

    for i, node in enumerate(nodes, 1):
        node_id = node["id"]
        logger.info(f"\n--- 节点 {i}/{len(nodes)}: {node_id} ---")

        try:
            # 检查是否已经有完整的增强数据
            if node.get("embedding") and node.get("summary") and node.get("key_concepts"):
                logger.info(f"⏭️ 节点已有完整数据，跳过")
                skip_count += 1
                continue

            # 2. 提取节点的字幕文本
            transcript = node.get("transcript")
            if not transcript or transcript.strip() == "":
                logger.info(f"🔍 提取节点字幕...")
                transcript = await generate_node_transcript(
                    video_id=node["video_id"],
                    node_id=node_id,
                    start_time=node["start_time"],
                    end_time=node["end_time"]
                )

                if not transcript:
                    logger.warning(f"⚠️ 节点 {node_id} 无字幕内容，跳过")
                    error_count += 1
                    continue

            # 3. 生成增强内容（title, summary, keyConcepts）
            logger.info(f"🤖 生成增强内容...")
            enhanced = await enhancer.enhance_node(transcript)

            title = enhanced.get("title", "未命名节点")
            summary = enhanced.get("summary", transcript[:100])
            key_concepts = enhanced.get("keyConcepts", [])

            logger.info(f"  标题: {title}")
            logger.info(f"  关键词: {', '.join(key_concepts)}")

            # 4. 更新增强内容到数据库
            await update_node_enhancement(
                node_id=node_id,
                title=title,
                summary=summary,
                key_concepts=key_concepts,
                transcript=transcript
            )

            # 5. 生成embedding
            logger.info(f"🔢 生成embedding...")
            embedding = await embedding_service.generate_node_embedding(
                summary=summary,
                key_concepts=key_concepts
            )

            # 6. 更新embedding到数据库
            await update_node_embedding(node_id, embedding)

            success_count += 1
            logger.info(f"✅ 节点 {node_id} 迁移完成")

        except Exception as e:
            logger.error(f"❌ 处理节点 {node_id} 时出错: {e}", exc_info=True)
            error_count += 1
            continue

    # 统计
    logger.info(f"\n{'='*80}")
    logger.info(f"📊 视频 {video_id} 迁移完成:")
    logger.info(f"  ✅ 成功: {success_count} 个")
    logger.info(f"  ⏭️ 跳过: {skip_count} 个")
    logger.info(f"  ❌ 失败: {error_count} 个")
    logger.info(f"{'='*80}\n")


async def main():
    """主函数"""
    logger.info("🚀 开始节点数据迁移...")

    # 初始化服务
    enhancer = NodeEnhancer()
    embedding_service = NodeEmbeddingService()

    # 获取所有有节点的视频
    video_ids = await get_videos_with_nodes()
    logger.info(f"📹 找到 {len(video_ids)} 个视频需要迁移")

    if not video_ids:
        logger.info("没有视频需要迁移，退出")
        return

    # 逐个处理视频
    total_success = 0
    total_error = 0

    for idx, video_id in enumerate(video_ids, 1):
        logger.info(f"\n{'#'*80}")
        logger.info(f"进度: {idx}/{len(video_ids)}")
        logger.info(f"{'#'*80}")

        try:
            await migrate_video_nodes(video_id, enhancer, embedding_service)
            total_success += 1
        except Exception as e:
            logger.error(f"❌ 视频 {video_id} 迁移失败: {e}", exc_info=True)
            total_error += 1
            continue

    # 最终统计
    logger.info(f"\n{'#'*80}")
    logger.info(f"🎉 迁移任务完成！")
    logger.info(f"{'#'*80}")
    logger.info(f"  ✅ 成功视频: {total_success}/{len(video_ids)}")
    logger.info(f"  ❌ 失败视频: {total_error}/{len(video_ids)}")
    logger.info(f"{'#'*80}\n")


if __name__ == "__main__":
    asyncio.run(main())
