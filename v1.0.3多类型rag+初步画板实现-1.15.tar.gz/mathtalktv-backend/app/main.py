from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.core.config import settings
from app.db.database import init_db
import os

# 创建FastAPI应用
app = FastAPI(
    title="MathTalkTV API",
    description="初中生数学讲题平台后端API",
    version="1.0.0",
    debug=settings.DEBUG
)

# 配置CORS（允许前端跨域访问）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境改为具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载静态文件服务（用于提供上传的视频）
# 确保uploads目录存在
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
app.mount("/static/videos", StaticFiles(directory=settings.UPLOAD_DIR), name="videos")


@app.on_event("startup")
async def startup_event():
    """应用启动时执行"""
    print("🚀 MathTalkTV 后端启动中...")
    await init_db()
    print(f"📡 服务运行在 http://{settings.HOST}:{settings.PORT}")


@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭时执行"""
    print("👋 MathTalkTV 后端关闭")


@app.get("/")
async def root():
    """健康检查接口"""
    return {
        "message": "MathTalkTV API is running",
        "version": "1.0.0",
        "status": "healthy"
    }


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "ok"}


# 注册API路由
from app.api.videos import router as video_router
from app.api.chat import router as chat_router
from app.api.reports import router as reports_router

app.include_router(video_router, prefix="/api", tags=["videos"])
app.include_router(chat_router, prefix="/api", tags=["chat"])
app.include_router(reports_router, prefix="/api", tags=["reports"])
