from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    """应用配置"""

    # API密钥
    OPENAI_API_KEY: str = ""
    OPENAI_BASE_URL: str = "https://api.openai.com/v1"

    # 讯飞配置
    XFYUN_APP_ID: str = ""
    XFYUN_API_KEY: str = ""
    XFYUN_API_SECRET: str = ""

    # LLM配置
    LLM_PROVIDER: str = "uiuiapi"  # uiuiapi 或 deepseek (旧配置,保留兼容)
    DEFAULT_LLM_MODEL: str = "gpt-4o-mini"  # 默认使用的模型

    # UIUIApi配置 (支持OpenAI/Claude/DeepSeek多模型)
    UIUIAPI_KEY: str = ""
    UIUIAPI_BASE_URL: str = "https://sg.uiuiapi.com/v1"  # 主站
    UIUIAPI_BASE_URL_BACKUP: str = "https://api1.uiuiapi.com/v1"  # 副站

    # 其他API配置 (预留)
    DEEPSEEK_API_KEY: str = ""

    # 服务配置
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG: bool = True

    # 文件路径
    UPLOAD_DIR: str = "./uploads/videos"
    DB_PATH: str = "./data/mathtalktv.db"

    # RAG配置
    ENABLE_RAG: bool = True  # 是否启用RAG（True=语义检索, False=简单截取）
    RAG_TOP_K: int = 3  # 检索返回的最相关片段数量
    RAG_CHUNK_SIZE: int = 200  # 字幕分块大小（字符数）
    RAG_CONFIDENCE_THRESHOLD: float = 0.55  # RAG置信度阈值（低于此值降级到通用LLM）
    RAG_RELEVANCE_THRESHOLD: float = 0.35  # 问题相关度阈值（低于此值判断为不相关问题）

    class Config:
        env_file = ".env"
        case_sensitive = True


# 创建全局配置实例
settings = Settings()

# 确保必要的目录存在
Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)
Path(settings.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
