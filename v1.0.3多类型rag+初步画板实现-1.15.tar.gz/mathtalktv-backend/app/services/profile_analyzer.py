"""
画像分析服务 (ProfileAnalyzer)
分析学习数据，构建和更新学生画像
"""
import logging
import json
from datetime import datetime
from typing import Dict, List, Optional
import aiosqlite

from app.core.config import settings

logger = logging.getLogger(__name__)


class ProfileAnalyzer:
    """学生画像分析服务"""

    @staticmethod
    async def update_profile(student_id: str) -> None:
        """
        更新学生画像（在会话结束后调用）

        Args:
            student_id: 学生ID
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 计算总体统计数据
                cursor = await db.execute("""
                    SELECT
                        COUNT(*) as total_sessions,
                        SUM(watch_duration) as total_watch_time,
                        AVG(completion_rate) as avg_completion_rate
                    FROM learning_sessions
                    WHERE student_id = ?
                """, (student_id,))
                stats = await cursor.fetchone()

                # 计算总提问数
                cursor = await db.execute("""
                    SELECT COUNT(*) as total_questions
                    FROM question_records
                    WHERE student_id = ?
                """, (student_id,))
                question_stats = await cursor.fetchone()

                # 分析薄弱概念
                weak_concepts = await ProfileAnalyzer.analyze_weak_concepts(student_id)

                # 分析学习偏好
                learning_preferences = await ProfileAnalyzer.analyze_learning_preferences(student_id)

                # 更新或插入画像
                await db.execute("""
                    INSERT INTO student_profiles
                    (student_id, total_watch_time, total_questions, total_sessions,
                     avg_completion_rate, weak_concepts, learning_preferences, last_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(student_id) DO UPDATE SET
                        total_watch_time = excluded.total_watch_time,
                        total_questions = excluded.total_questions,
                        total_sessions = excluded.total_sessions,
                        avg_completion_rate = excluded.avg_completion_rate,
                        weak_concepts = excluded.weak_concepts,
                        learning_preferences = excluded.learning_preferences,
                        last_active = excluded.last_active
                """, (
                    student_id,
                    stats[1] or 0,  # total_watch_time
                    question_stats[0] or 0,  # total_questions
                    stats[0] or 0,  # total_sessions
                    stats[2] or 0,  # avg_completion_rate
                    json.dumps(weak_concepts, ensure_ascii=False),
                    json.dumps(learning_preferences, ensure_ascii=False),
                    datetime.now()
                ))

                await db.commit()
                logger.info(f"✅ 更新学生画像: {student_id}")

        except Exception as e:
            logger.error(f"更新学生画像失败: {e}")

    @staticmethod
    async def analyze_weak_concepts(student_id: str) -> List[str]:
        """
        分析薄弱知识点
        - 基于低置信度提问
        - 基于重复提问的概念

        Args:
            student_id: 学生ID

        Returns:
            薄弱知识点列表
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 获取低置信度问题（<0.5）
                cursor = await db.execute("""
                    SELECT question_text, confidence_score
                    FROM question_records
                    WHERE student_id = ?
                    AND confidence_score < 0.5
                    AND is_relevant = 1
                    ORDER BY created_at DESC
                    LIMIT 20
                """, (student_id,))
                low_confidence_questions = await cursor.fetchall()

                # 简单的关键词提取（实际应该使用jieba等分词工具）
                # 这里使用mock数据示例
                weak_concepts = []
                for question, score in low_confidence_questions:
                    # 提取常见数学概念关键词
                    concepts = ["配方法", "因式分解", "一元二次方程", "函数", "几何", "三角形"]
                    for concept in concepts:
                        if concept in question and concept not in weak_concepts:
                            weak_concepts.append(concept)

                # 限制返回前5个
                return weak_concepts[:5]

        except Exception as e:
            logger.error(f"分析薄弱知识点失败: {e}")
            return []

    @staticmethod
    async def analyze_learning_preferences(student_id: str) -> Dict:
        """
        分析学习偏好

        Args:
            student_id: 学生ID

        Returns:
            学习偏好字典
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 统计提问类型偏好
                cursor = await db.execute("""
                    SELECT question_type, COUNT(*) as count
                    FROM question_records
                    WHERE student_id = ?
                    GROUP BY question_type
                """, (student_id,))
                question_types = await cursor.fetchall()

                # 计算平均完成率（判断学习模式）
                cursor = await db.execute("""
                    SELECT AVG(completion_rate) as avg_rate
                    FROM learning_sessions
                    WHERE student_id = ?
                """, (student_id,))
                avg_rate = await cursor.fetchone()

                preferences = {
                    "question_style": "voice" if (question_types and question_types[0][0] == "voice") else "text",
                    "learning_mode": "完整观看" if (avg_rate and avg_rate[0] > 0.7) else "跳跃式学习",
                    "active_level": "高频提问" if len(question_types) > 0 and sum(q[1] for q in question_types) > 10 else "较少提问"
                }

                return preferences

        except Exception as e:
            logger.error(f"分析学习偏好失败: {e}")
            return {}

    @staticmethod
    async def get_personalized_prompt(student_id: str) -> str:
        """
        生成个性化系统提示词（基于学生画像）

        Args:
            student_id: 学生ID

        Returns:
            个性化提示词补充
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                cursor = await db.execute("""
                    SELECT weak_concepts, learning_preferences
                    FROM student_profiles
                    WHERE student_id = ?
                """, (student_id,))
                profile = await cursor.fetchone()

                if not profile:
                    return ""

                weak_concepts = json.loads(profile[0]) if profile[0] else []
                preferences = json.loads(profile[1]) if profile[1] else {}

                # 构建个性化提示词
                prompt_parts = []

                if weak_concepts:
                    prompt_parts.append(f"该学生在以下知识点遇到过困难：{', '.join(weak_concepts)}。请在讲解时给予更详细的说明。")

                if preferences.get("learning_mode") == "跳跃式学习":
                    prompt_parts.append("该学生倾向于跳跃式学习，讲解时注重关键要点。")

                if preferences.get("active_level") == "高频提问":
                    prompt_parts.append("该学生喜欢提问，可以鼓励互动式讲解。")

                return "\n".join(prompt_parts)

        except Exception as e:
            logger.error(f"生成个性化提示词失败: {e}")
            return ""

    @staticmethod
    async def update_concept_mastery(
        student_id: str,
        concept_name: str,
        is_correct: bool
    ) -> None:
        """
        更新知识点掌握度

        Args:
            student_id: 学生ID
            concept_name: 知识点名称
            is_correct: 是否正确理解
        """
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                # 获取当前掌握度
                cursor = await db.execute("""
                    SELECT mastery_level, question_count, correct_count
                    FROM concept_mastery
                    WHERE student_id = ? AND concept_name = ?
                """, (student_id, concept_name))
                result = await cursor.fetchone()

                if result:
                    mastery_level, question_count, correct_count = result
                    question_count += 1
                    if is_correct:
                        correct_count += 1
                    # 重新计算掌握度
                    mastery_level = correct_count / question_count
                else:
                    question_count = 1
                    correct_count = 1 if is_correct else 0
                    mastery_level = correct_count / question_count

                # 更新或插入
                await db.execute("""
                    INSERT INTO concept_mastery
                    (student_id, concept_name, mastery_level, question_count, correct_count, last_reviewed)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(student_id, concept_name) DO UPDATE SET
                        mastery_level = excluded.mastery_level,
                        question_count = excluded.question_count,
                        correct_count = excluded.correct_count,
                        last_reviewed = excluded.last_reviewed
                """, (
                    student_id, concept_name, mastery_level,
                    question_count, correct_count, datetime.now()
                ))

                await db.commit()
                logger.info(f"📊 更新知识点掌握度: {concept_name} = {mastery_level:.2%}")

        except Exception as e:
            logger.error(f"更新知识点掌握度失败: {e}")
