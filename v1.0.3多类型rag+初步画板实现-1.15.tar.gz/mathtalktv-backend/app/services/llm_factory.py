"""
LLM提供商工厂类
支持: OpenAI (UIUIApi) / Claude / DeepSeek
统一接口,方便AB测试和模型切换
"""
import logging
from typing import List, Dict, Optional
from openai import AsyncOpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)


class LLMProvider:
    """LLM提供商基类"""

    def __init__(self, model: str):
        self.model = model
        self.total_input_tokens = 0
        self.total_output_tokens = 0

    async def generate(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 800
    ) -> Dict:
        """
        统一生成接口

        Returns:
            {
                "content": str,  # 生成的文本
                "reasoning": str,  # DeepSeek推理过程(可选)
                "input_tokens": int,
                "output_tokens": int,
                "model": str,
                "latency_ms": int
            }
        """
        raise NotImplementedError


class OpenAIProvider(LLMProvider):
    """OpenAI兼容接口 (UIUIApi主站/副站 + 原生OpenAI)"""

    def __init__(self, model: str, base_url: str, api_key: str):
        super().__init__(model)
        self.client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        self.base_url = base_url

    async def generate(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 800
    ) -> Dict:
        import time
        start_time = time.time()

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )

            latency = int((time.time() - start_time) * 1000)

            result = {
                "content": response.choices[0].message.content,
                "reasoning": "",  # OpenAI无推理过程
                "input_tokens": response.usage.prompt_tokens,
                "output_tokens": response.usage.completion_tokens,
                "model": response.model,
                "latency_ms": latency,
                "provider": "openai"
            }

            self.total_input_tokens += result["input_tokens"]
            self.total_output_tokens += result["output_tokens"]

            logger.info(f"[OpenAI] {self.model} | Latency: {latency}ms | Tokens: {result['input_tokens']}→{result['output_tokens']}")
            return result

        except Exception as e:
            logger.error(f"[OpenAI] 调用失败: {e}")
            raise


class ClaudeProvider(LLMProvider):
    """Anthropic Claude (通过UIUIApi的OpenAI兼容接口)"""

    def __init__(self, model: str, base_url: str, api_key: str):
        super().__init__(model)
        # 使用OpenAI客户端,因为UIUIApi是OpenAI兼容接口
        self.client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    async def generate(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 800
    ) -> Dict:
        import time
        start_time = time.time()

        try:
            # UIUIApi的Claude使用OpenAI格式调用
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )

            latency = int((time.time() - start_time) * 1000)

            result = {
                "content": response.choices[0].message.content,
                "reasoning": "",
                "input_tokens": response.usage.prompt_tokens,
                "output_tokens": response.usage.completion_tokens,
                "model": response.model,
                "latency_ms": latency,
                "provider": "claude"
            }

            self.total_input_tokens += result["input_tokens"]
            self.total_output_tokens += result["output_tokens"]

            logger.info(f"[Claude] {self.model} | Latency: {latency}ms | Tokens: {result['input_tokens']}→{result['output_tokens']}")
            return result

        except Exception as e:
            logger.error(f"[Claude] 调用失败: {e}")
            raise


class DeepSeekProvider(LLMProvider):
    """DeepSeek (支持推理模型 deepseek-reasoner)"""

    def __init__(self, model: str, base_url: str, api_key: str):
        super().__init__(model)
        self.client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    async def generate(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 800
    ) -> Dict:
        import time
        start_time = time.time()

        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )

            latency = int((time.time() - start_time) * 1000)

            # DeepSeek Reasoner有推理过程
            reasoning = ""
            if hasattr(response.choices[0].message, "reasoning_content"):
                reasoning = response.choices[0].message.reasoning_content or ""

            result = {
                "content": response.choices[0].message.content,
                "reasoning": reasoning,
                "input_tokens": response.usage.prompt_tokens,
                "output_tokens": response.usage.completion_tokens,
                "model": response.model,
                "latency_ms": latency,
                "provider": "deepseek"
            }

            self.total_input_tokens += result["input_tokens"]
            self.total_output_tokens += result["output_tokens"]

            logger.info(f"[DeepSeek] {self.model} | Latency: {latency}ms | Tokens: {result['input_tokens']}→{result['output_tokens']}")
            return result

        except Exception as e:
            logger.error(f"[DeepSeek] 调用失败: {e}")
            raise


class LLMFactory:
    """LLM工厂类 - 根据配置创建对应的Provider"""

    # 模型配置映射
    MODEL_CONFIGS = {
        "gpt-4o": {
            "provider_class": OpenAIProvider,
            "base_url": "https://sg.uiuiapi.com/v1",  # UIUIApi主站
            "api_key_setting": "UIUIAPI_KEY"
        },
        "gpt-4o-mini": {
            "provider_class": OpenAIProvider,
            "base_url": "https://sg.uiuiapi.com/v1",
            "api_key_setting": "UIUIAPI_KEY"
        },
        "gpt-4o-mini-副站": {
            "provider_class": OpenAIProvider,
            "base_url": "https://api1.uiuiapi.com/v1",  # UIUIApi副站
            "api_key_setting": "UIUIAPI_KEY"
        },
        "claude-3-5-sonnet": {
            "provider_class": ClaudeProvider,
            "base_url": "https://sg.uiuiapi.com/v1",
            "api_key_setting": "UIUIAPI_KEY",
            "model_id": "claude-3-5-sonnet-20241022"
        },
        "claude-3-5-haiku": {
            "provider_class": ClaudeProvider,
            "base_url": "https://sg.uiuiapi.com/v1",
            "api_key_setting": "UIUIAPI_KEY",
            "model_id": "claude-3-5-haiku-20241022"
        },
        "deepseek-chat": {
            "provider_class": DeepSeekProvider,
            "base_url": "https://sg.uiuiapi.com/v1",
            "api_key_setting": "UIUIAPI_KEY"
        },
        "deepseek-reasoner": {
            "provider_class": DeepSeekProvider,
            "base_url": "https://sg.uiuiapi.com/v1",
            "api_key_setting": "UIUIAPI_KEY"
        }
    }

    @classmethod
    def create(cls, model_name: str) -> LLMProvider:
        """
        创建LLM Provider

        Args:
            model_name: 模型名称 (如 "gpt-4o-mini", "claude-3-5-sonnet", "deepseek-reasoner")

        Returns:
            对应的Provider实例
        """
        config = cls.MODEL_CONFIGS.get(model_name)

        if not config:
            # 默认fallback到gpt-4o-mini
            logger.warning(f"未知模型 {model_name}, 使用默认 gpt-4o-mini")
            model_name = "gpt-4o-mini"
            config = cls.MODEL_CONFIGS[model_name]

        # 获取API Key
        api_key = getattr(settings, config["api_key_setting"], "")
        if not api_key:
            raise ValueError(f"未配置 {config['api_key_setting']}, 请检查.env文件")

        # 创建Provider实例
        provider_class = config["provider_class"]
        model_id = config.get("model_id", model_name)  # Claude需要完整model_id

        return provider_class(
            model=model_id,
            base_url=config["base_url"],
            api_key=api_key
        )

    @classmethod
    def get_available_models(cls) -> List[Dict[str, str]]:
        """获取所有可用模型列表 (供前端展示)"""
        return [
            {"id": "gpt-4o-mini", "name": "GPT-4o Mini (主站)", "provider": "OpenAI"},
            {"id": "gpt-4o-mini-副站", "name": "GPT-4o Mini (副站)", "provider": "OpenAI"},
            {"id": "gpt-4o", "name": "GPT-4o", "provider": "OpenAI"},
            {"id": "claude-3-5-sonnet", "name": "Claude 3.5 Sonnet", "provider": "Anthropic"},
            {"id": "claude-3-5-haiku", "name": "Claude 3.5 Haiku", "provider": "Anthropic"},
            {"id": "deepseek-chat", "name": "DeepSeek Chat", "provider": "DeepSeek"},
            {"id": "deepseek-reasoner", "name": "DeepSeek Reasoner (推理)", "provider": "DeepSeek"}
        ]


# 便捷函数
async def generate_completion(
    messages: List[Dict[str, str]],
    model: Optional[str] = None,
    temperature: float = 0.7,
    max_tokens: int = 800
) -> Dict:
    """
    便捷的生成函数

    Args:
        messages: 对话消息列表
        model: 模型名称 (None则使用配置默认值)
        temperature: 温度参数
        max_tokens: 最大token数

    Returns:
        生成结果字典
    """
    if model is None:
        model = getattr(settings, "DEFAULT_LLM_MODEL", "gpt-4o-mini")

    provider = LLMFactory.create(model)
    return await provider.generate(messages, temperature, max_tokens)
