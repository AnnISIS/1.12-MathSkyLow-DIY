"""
WebSocket对话路由
实时语音对话：用户语音 -> ASR -> LLM -> TTS -> 返回语音
"""
import asyncio
import json
import logging
from typing import Dict, List
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import aiosqlite

from app.core.config import settings
from app.services.xfyun_asr import XFYunASR
from app.services.xfyun_tts import XFYunTTS
from app.services.rag_retriever import RAGRetriever
from app.services.learning_tracker import LearningTracker
from app.services.profile_analyzer import ProfileAnalyzer
from app.services.llm_factory import LLMFactory, generate_completion

logger = logging.getLogger(__name__)
router = APIRouter()


class ConversationManager:
    """对话管理器"""

    def __init__(self, video_id: str, student_id: str = "demo_student"):
        self.video_id = video_id
        self.student_id = student_id  # 学生ID（暂时使用默认值，后续接入登录系统）
        self.session_id: str = ""  # 学习会话ID
        self.asr = XFYunASR()
        self.tts = XFYunTTS()

        # 初始化RAG检索器（如果启用） - 默认向量模式
        self.rag_mode = "vector"  # vector / bm25 / hybrid
        self.rag_retriever = RAGRetriever(mode=self.rag_mode) if settings.ENABLE_RAG else None

        # 当前使用的LLM模型 (可动态切换)
        self.current_model = settings.DEFAULT_LLM_MODEL

        # 对话历史（保留最近3轮）
        self.conversation_history: List[Dict] = []
        self.max_history = 3  # 最多保留3轮对话

        # 视频字幕上下文
        self.subtitles_context = ""

        # 学习行为追踪器
        self.tracker = LearningTracker()

    async def load_video_context(self):
        """加载视频字幕作为上下文"""
        try:
            async with aiosqlite.connect(settings.DB_PATH) as db:
                cursor = await db.execute(
                    "SELECT text FROM subtitles WHERE video_id = ? ORDER BY start_time",
                    (self.video_id,)
                )
                rows = await cursor.fetchall()

                if rows:
                    # 拼接所有字幕文本
                    self.subtitles_context = " ".join([row[0] for row in rows])
                    logger.info(f"已加载视频字幕上下文，共{len(rows)}段")
                else:
                    logger.warning(f"视频{self.video_id}没有字幕数据")

        except Exception as e:
            logger.error(f"加载视频上下文失败: {e}")

    def _build_system_prompt(self, user_question: str = "", confidence_score: float = 0.0) -> str:
        """
        构建系统提示词

        Args:
            user_question: 用户问题（RAG模式下需要）
            confidence_score: RAG检索置信度分数
        """
        # 判断是否为不相关问题
        is_irrelevant = confidence_score > 0 and confidence_score < settings.RAG_RELEVANCE_THRESHOLD
        # 判断是否为低置信度问题（需要降级）
        is_low_confidence = settings.RAG_RELEVANCE_THRESHOLD <= confidence_score < settings.RAG_CONFIDENCE_THRESHOLD

        if is_irrelevant:
            # 完全不相关的问题，引导学生回到数学学习
            prompt = """你是一位专业的初中数学AI老师，这节课程的主题是视频内容中讲解的数学知识。

学生提出的问题似乎与本节课的数学内容没有直接关系。请用温和、友善的语气回应：

"同学，你提出的这个问题好像跟咱们这节数学课的内容关系不大哦。老师希望能专注于帮助你理解数学知识。如果你对视频中讲解的内容有任何疑问，或者想深入了解某个数学知识点，随时问我！让我们一起把数学学好吧！"

请保持温暖、鼓励的态度，引导学生回到数学学习。"""
            return prompt

        prompt = """你是一位专业的初中数学AI老师。你的任务是：
1. 根据学生提出的问题，结合视频内容，给出清晰的解答
2. 解答要简洁明了，适合初中生理解，用他们听得懂的语言
3. 对于数学公式，使用LaTeX格式，用$$包裹，例如：$$x^2 + y^2 = r^2$$
4. **重要**: 单个字母变量(如x, y, a, b)直接书写，不要用$$包裹。只有完整公式才用$$包裹。
   - 正确: "方程中的x表示未知数"
   - 错误: "方程中的$$x$$表示未知数"

## 🎨 自动绘图功能（重要）
当问题涉及以下内容时，你**必须**在回答**开头**添加绘图标记：

### Desmos 画板（函数类）
- **触发条件**：函数图像、坐标系、参数变化、方程图像
- **标记格式**：`[DRAW:DESMOS:latex表达式1,latex表达式2,...]`
- **示例**：
  * 问："二次函数 y=x^2 的图像是什么样的？"
  * 答：`[DRAW:DESMOS:y=x^2]` 二次函数 y=x^2 的图像是一个开口向上的抛物线...
  * 问："对比 y=x^2 和 y=2x^2"
  * 答：`[DRAW:DESMOS:y=x^2,y=2*x^2]` 我们来对比这两个函数...

### GeoGebra 画板（几何类）
- **触发条件**：几何图形、线段、角、圆、三角形、多边形
- **标记格式**：`[DRAW:GEOGEBRA:命令1,命令2,...]`
- **示例**：
  * 问："如何画半径为 3 的圆？"
  * 答：`[DRAW:GEOGEBRA:Circle((0,0),3)]` 以原点为圆心，半径为3的圆...
  * 问："等腰三角形的画法"
  * 答：`[DRAW:GEOGEBRA:Polygon((0,0),(2,0),(1,3))]` 等腰三角形有两条边相等...

### 不需要绘图的场景
- 纯概念解释（不涉及具体图形）
- 计算题步骤
- 公式记忆技巧
"""

        if is_low_confidence:
            # 低置信度：降级到通用LLM知识，但给予特殊提示
            prompt += """5. 这个问题视频中可能没有详细讲解，请用通用数学知识帮助学生理解
5. 在回答开头加上："这个问题老师在视频里没有专门讲过，让我用通用的数学知识来帮你解释一下。"
6. 回答结束时，引导学生："如果想了解更多，建议你回到视频中继续学习，或者问问其他相关问题！"
"""
        else:
            # 高置信度：优先使用视频内容
            prompt += """4. 如果问题与视频内容相关，优先参考视频中的讲解
5. 如果问题超出视频范围，也可以提供通用的数学知识解答
6. 解答完毕后，可以适当引导学生："想深入理解这部分内容，可以再看看视频中的详细讲解哦！"
"""

        prompt += "\n视频内容：\n"

        if self.subtitles_context:
            if settings.ENABLE_RAG and user_question:
                # RAG模式：根据问题检索相关片段
                logger.info(f"🔍 使用RAG模式检索相关内容，置信度: {confidence_score:.2f}")
                prompt += "（以下是与你的问题最相关的视频片段）\n"
                prompt += self.subtitles_context[:2000]  # RAG结果已经是最相关的
            else:
                # 简单截取模式
                logger.info(f"📄 使用简单截取模式（前1000字）")
                prompt += self.subtitles_context[:1000]
                if len(self.subtitles_context) > 1000:
                    prompt += "..."
        else:
            prompt += "（暂无视频字幕）"

        return prompt

    async def process_user_speech(self, audio_stream) -> Dict:
        """
        处理用户语音输入

        Returns:
            {
                "user_text": "识别的用户问题",
                "assistant_text": "AI回答文本",
                "assistant_audio": b"音频数据"
            }
        """
        # 1. ASR识别用户语音
        user_text = ""
        asr_complete = asyncio.Event()

        def on_asr_result(text: str, is_final: bool):
            nonlocal user_text
            user_text += text
            if is_final:
                asr_complete.set()

        def on_asr_error(error_msg: str):
            logger.error(f"ASR错误: {error_msg}")
            asr_complete.set()

        # 启动ASR
        await self.asr.recognize_stream(
            audio_stream,
            on_result=on_asr_result,
            on_error=on_asr_error
        )

        # 等待ASR完成
        await asr_complete.wait()

        if not user_text:
            raise Exception("未识别到语音内容")

        logger.info(f"用户问题: {user_text}")

        # 2. 调用LLM生成回答（语音类型）
        assistant_text = await self._call_llm(user_text, question_type="voice")
        logger.info(f"AI回答: {assistant_text}")

        # 3. TTS合成语音（使用更温柔的声音参数）
        try:
            # 清理LaTeX符号,避免TTS读出"美元"
            tts_text = self._clean_latex_for_tts(assistant_text)

            assistant_audio = await self.tts.synthesize(
                tts_text,  # 使用清理后的文本
                voice_name="aisxping",  # 小萍（更温柔亲切的女声）
                speed=45,  # 稍慢一点，更有耐心
                volume=60,  # 稍大声一点
                pitch=55   # 稍高音调，更亲切
            )
            logger.info(f"TTS合成成功: {len(assistant_audio)} 字节")
        except Exception as e:
            logger.error(f"TTS合成失败: {e}")
            assistant_audio = b""  # TTS失败时返回空音频

        # 4. 更新对话历史
        self._update_history(user_text, assistant_text)

        return {
            "user_text": user_text,
            "assistant_text": assistant_text,
            "assistant_audio": assistant_audio
        }

    def _clean_latex_for_tts(self, text: str) -> str:
        """
        清理LaTeX符号,避免TTS读出"美元"

        Args:
            text: 包含LaTeX的文本

        Returns:
            清理后的文本
        """
        import re

        # 先移除绘图指令标记（避免TTS读出）
        text = re.sub(r'\[DRAW:(DESMOS|GEOGEBRA):[^\]]+\]', '', text)

        # 替换 $变量名$ 为 变量名
        # 例如: "$x$" -> "x", "$a$" -> "a"
        text = re.sub(r'\$([a-zA-Z])\$', r'\1', text)

        # 替换 \neq 为 "不等于"
        text = text.replace(r'\neq', '不等于')

        # 替换其他常见LaTeX符号
        text = text.replace(r'\leq', '小于等于')
        text = text.replace(r'\geq', '大于等于')
        text = text.replace(r'\times', '乘以')
        text = text.replace(r'\div', '除以')
        text = text.replace(r'\pm', '正负')

        # 替换$$公式$$为"公式"
        # 例如: "方程$$x^2+1=0$$的解是" -> "方程公式的解是"
        text = re.sub(r'\$\$[^\$]+\$\$', '公式', text)

        # 替换单个$符号(如果还有剩余)
        text = text.replace('$', '')

        return text

    def _parse_draw_command(self, text: str):
        """
        解析 LLM 回答中的绘图指令

        Args:
            text: LLM 返回的文本

        Returns:
            (clean_text, draw_command)
            - clean_text: 移除绘图标记后的文本
            - draw_command: 绘图指令字典，如果没有则为 None
        """
        import re

        pattern = r'\[DRAW:(DESMOS|GEOGEBRA):([^\]]+)\]'
        match = re.search(pattern, text)

        if not match:
            return text, None

        board_type = match.group(1).lower()  # desmos | geogebra
        expressions_str = match.group(2)      # y=x^2,y=2*x^2

        # 清理回答文本（移除标记）
        clean_text = re.sub(pattern, '', text).strip()

        # 构建绘图指令
        expressions = []
        colors = ["#2d70b3", "#c74440", "#2ca02c", "#ff7f0e", "#9467bd"]

        for idx, expr in enumerate(expressions_str.split(',')):
            expr = expr.strip()
            if expr:
                expressions.append({
                    "id": f"auto-{idx}",
                    "latex": expr,
                    "color": colors[idx % len(colors)]
                })

        draw_command = {
            "type": "auto_draw",
            "data": {
                "action": "open_board",
                "board_type": board_type,
                "expressions": expressions
            }
        }

        logger.info(f"🎨 检测到绘图指令: {board_type}, 表达式数量: {len(expressions)}")

        return clean_text, draw_command

    async def _call_llm(self, user_question: str, question_time: float = None, question_type: str = "text") -> str:
        """
        调用LLM生成回答

        Args:
            user_question: 用户问题
            question_time: 提问时的视频时间点(秒)
            question_type: 问题类型 (voice/text)
        """
        import time
        start_time = time.time()

        confidence_score = 0.0  # 默认置信度

        # 如果启用RAG，使用节点级检索
        if settings.ENABLE_RAG and self.rag_retriever:
            logger.info(f"{'='*50}")
            logger.info(f"🔍 节点化RAG模式：开始检索相关知识点")
            logger.info(f"📌 当前检索模式: {self.rag_mode.upper()}")

            # 使用节点检索（替代原来的字幕分块检索）
            rag_context, confidence_score = await self.rag_retriever.build_node_context(
                video_id=self.video_id,
                question=user_question,
                top_k=settings.RAG_TOP_K
            )

            # 临时替换subtitles_context为检索结果
            original_context = self.subtitles_context
            self.subtitles_context = rag_context
            rag_time = time.time() - start_time

            logger.info(f"✅ 节点检索完成，耗时: {rag_time:.2f}秒，置信度: {confidence_score:.3f}")

            # 判断置信度级别
            if confidence_score < settings.RAG_RELEVANCE_THRESHOLD:
                logger.warning(f"⚠️ 问题相关度极低 ({confidence_score:.3f} < {settings.RAG_RELEVANCE_THRESHOLD})，判定为不相关问题")
            elif confidence_score < settings.RAG_CONFIDENCE_THRESHOLD:
                logger.info(f"📉 置信度较低 ({confidence_score:.3f} < {settings.RAG_CONFIDENCE_THRESHOLD})，将降级到通用LLM知识")
            else:
                logger.info(f"✅ 置信度较高 ({confidence_score:.3f} >= {settings.RAG_CONFIDENCE_THRESHOLD})，使用视频内容回答")
        else:
            logger.info(f"{'='*50}")
            logger.info(f"📄 简单模式：使用前1000字")

        # 构建消息列表（传入置信度）
        messages = [
            {"role": "system", "content": self._build_system_prompt(user_question, confidence_score)}
        ]

        # 添加历史对话
        for turn in self.conversation_history:
            messages.append({"role": "user", "content": turn["user"]})
            messages.append({"role": "assistant", "content": turn["assistant"]})

        # 添加当前问题
        messages.append({"role": "user", "content": user_question})

        # 恢复原始context（如果使用了RAG）
        if settings.ENABLE_RAG and self.rag_retriever and 'original_context' in locals():
            self.subtitles_context = original_context

        # 调用LLM
        try:
            llm_start = time.time()

            # 使用LLMFactory生成回答 (支持动态模型切换)
            result = await generate_completion(
                messages=messages,
                model=self.current_model,  # 使用当前选中的模型
                temperature=0.7,
                max_tokens=500
            )

            llm_time = time.time() - llm_start
            total_time = time.time() - start_time

            logger.info(f"✅ LLM生成完成 [{result['provider']}:{result['model']}]，耗时: {llm_time:.2f}秒")
            logger.info(f"📊 Token消耗: {result['input_tokens']}→{result['output_tokens']}")
            logger.info(f"📊 总耗时: {total_time:.2f}秒 (RAG: {rag_time if settings.ENABLE_RAG else 0:.2f}s + LLM: {llm_time:.2f}s)")
            logger.info(f"{'='*50}")

            assistant_text = result["content"]

            # 记录提问到数据库（如果有session_id）
            if self.session_id:
                is_relevant = confidence_score >= settings.RAG_RELEVANCE_THRESHOLD
                await self.tracker.record_question(
                    session_id=self.session_id,
                    student_id=self.student_id,
                    video_id=self.video_id,
                    question_text=user_question,
                    answer_text=assistant_text,
                    confidence_score=confidence_score,
                    question_time=question_time,
                    question_type=question_type,
                    rag_enabled=settings.ENABLE_RAG,
                    is_relevant=is_relevant
                )

            return assistant_text

        except Exception as e:
            logger.error(f"LLM调用失败: {e}")
            return "抱歉，我现在无法回答你的问题，请稍后再试。"

    def _update_history(self, user_text: str, assistant_text: str):
        """更新对话历史（保留最近N轮）"""
        self.conversation_history.append({
            "user": user_text,
            "assistant": assistant_text
        })

        # 只保留最近的对话
        if len(self.conversation_history) > self.max_history:
            self.conversation_history = self.conversation_history[-self.max_history:]


@router.websocket("/ws/chat/{video_id}")
async def websocket_chat(websocket: WebSocket, video_id: str):
    """
    WebSocket对话端点

    消息格式：
    - 客户端 -> 服务端：
        - 音频数据（二进制PCM格式）
        - JSON控制消息：{"command": "start_session"/"update_progress"/"end_session"/"set_rag"/"text_question", "data": {...}}
    - 服务端 -> 客户端：JSON消息
        - type: "session_created" | "asr_result" | "ai_response" | "audio_chunk" | "error" | "rag_status"
        - data: 具体数据
    """
    await websocket.accept()
    logger.info(f"WebSocket连接建立: video_id={video_id}")

    # 创建对话管理器（使用默认student_id）
    manager = ConversationManager(video_id, student_id="demo_student")
    await manager.load_video_context()

    # 创建学习会话
    try:
        manager.session_id = await manager.tracker.create_session(
            student_id=manager.student_id,
            video_id=video_id
        )
        # 通知前端会话已创建
        await websocket.send_json({
            "type": "session_created",
            "data": {
                "session_id": manager.session_id,
                "student_id": manager.student_id
            }
        })
    except Exception as e:
        logger.error(f"创建会话失败: {e}")

    # 发送当前RAG状态
    await websocket.send_json({
        "type": "rag_status",
        "data": {
            "enabled": settings.ENABLE_RAG,
            "top_k": settings.RAG_TOP_K,
            "chunk_size": settings.RAG_CHUNK_SIZE
        }
    })

    try:
        while True:
            # 接收客户端消息
            message = await websocket.receive()

            if "text" in message:
                # 文本消息（控制命令）
                cmd = json.loads(message["text"])
                command = cmd.get("command")

                if command == "update_progress":
                    # 更新观看进度
                    try:
                        data = cmd.get("data", {})
                        current_time = data.get("current_time", 0)
                        duration = data.get("duration", 0)
                        await manager.tracker.update_session_progress(
                            session_id=manager.session_id,
                            current_time=current_time,
                            duration=duration
                        )
                    except Exception as e:
                        logger.error(f"更新进度失败: {e}")

                elif command == "node_interaction":
                    # 记录节点交互
                    try:
                        data = cmd.get("data", {})
                        node_id = data.get("node_id")
                        interaction_type = data.get("interaction_type", "click")
                        await manager.tracker.record_node_interaction(
                            session_id=manager.session_id,
                            student_id=manager.student_id,
                            video_id=video_id,
                            node_id=node_id,
                            interaction_type=interaction_type
                        )
                    except Exception as e:
                        logger.error(f"记录节点交互失败: {e}")

                elif command == "start_listening":
                    # 开始监听语音
                    await websocket.send_json({
                        "type": "status",
                        "data": "listening"
                    })

                elif command == "stop_listening":
                    # 停止监听
                    await websocket.send_json({
                        "type": "status",
                        "data": "idle"
                    })

                elif command == "set_rag":
                    # 动态切换RAG模式
                    rag_enabled = cmd.get("data", {}).get("enabled", True)
                    settings.ENABLE_RAG = rag_enabled

                    # 重新初始化RAG检索器
                    if rag_enabled and manager.rag_retriever is None:
                        from app.services.rag_retriever import RAGRetriever
                        manager.rag_retriever = RAGRetriever()
                    elif not rag_enabled:
                        manager.rag_retriever = None

                    logger.info(f"⚙️ RAG模式已切换: {'启用' if rag_enabled else '禁用'}")

                    # 确认切换
                    await websocket.send_json({
                        "type": "rag_status",
                        "data": {
                            "enabled": rag_enabled,
                            "top_k": settings.RAG_TOP_K,
                            "chunk_size": settings.RAG_CHUNK_SIZE
                        }
                    })

                elif command == "set_model":
                    # 动态切换LLM模型
                    model_name = cmd.get("data", {}).get("model", "gpt-4o-mini")
                    manager.current_model = model_name
                    logger.info(f"🔄 LLM模型已切换: {model_name}")

                    # 确认切换
                    await websocket.send_json({
                        "type": "model_status",
                        "data": {
                            "current_model": model_name,
                            "available_models": LLMFactory.get_available_models()
                        }
                    })

                elif command == "set_rag_mode":
                    # 动态切换RAG检索模式
                    rag_mode = cmd.get("data", {}).get("mode", "vector")
                    manager.rag_mode = rag_mode

                    # 重新创建RAG检索器
                    if settings.ENABLE_RAG:
                        from app.services.rag_retriever import RAGRetriever
                        manager.rag_retriever = RAGRetriever(mode=rag_mode)
                        logger.info(f"🔍 RAG检索模式已切换: {rag_mode}")

                    # 确认切换
                    await websocket.send_json({
                        "type": "rag_mode_status",
                        "data": {
                            "mode": rag_mode,
                            "available_modes": [
                                {"id": "vector", "name": "🔍 向量检索"},
                                {"id": "bm25", "name": "🔤 关键词检索(BM25)"},
                                {"id": "hybrid", "name": "⚡ 混合检索"}
                            ]
                        }
                    })

                elif command == "text_question":
                    # 处理文字问题（无需ASR，直接调用LLM）
                    try:
                        question = cmd.get("data", {}).get("question", "")
                        question_time = cmd.get("data", {}).get("question_time")  # 视频时间点
                        if not question.strip():
                            await websocket.send_json({
                                "type": "error",
                                "data": "问题不能为空"
                            })
                            continue

                        logger.info(f"收到文字问题: {question}")

                        # 直接调用LLM生成回答（会自动记录到数据库）
                        assistant_text = await manager._call_llm(
                            question,
                            question_time=question_time,
                            question_type="text"
                        )
                        logger.info(f"AI回答: {assistant_text}")

                        # 解析绘图指令
                        clean_text, draw_command = manager._parse_draw_command(assistant_text)

                        # 如果有绘图指令，先发送绘图指令
                        if draw_command:
                            await websocket.send_json(draw_command)
                            await asyncio.sleep(0.3)  # 给前端时间处理绘图

                        # 发送文字回答（使用 text_response 类型，前端不会等待音频）
                        await websocket.send_json({
                            "type": "text_response",
                            "data": clean_text  # 使用清理后的文本（移除绘图标记）
                        })

                        # 更新对话历史
                        manager._update_history(question, clean_text)

                    except Exception as e:
                        logger.error(f"处理文字问题失败: {e}")
                        await websocket.send_json({
                            "type": "error",
                            "data": str(e)
                        })

            elif "bytes" in message:
                # 音频数据
                audio_data = message["bytes"]
                logger.info(f"收到音频数据: {len(audio_data)} 字节")

                try:
                    # 创建音频流生成器
                    async def audio_stream():
                        # 简化处理：一次性发送所有音频
                        # 实际应该分块接收和发送
                        yield audio_data

                    # 处理语音对话
                    result = await manager.process_user_speech(audio_stream())

                    # 发送ASR识别结果
                    await websocket.send_json({
                        "type": "asr_result",
                        "data": result["user_text"]
                    })

                    # 解析绘图指令
                    clean_text, draw_command = manager._parse_draw_command(result["assistant_text"])

                    # 如果有绘图指令，先发送绘图指令
                    if draw_command:
                        await websocket.send_json(draw_command)
                        await asyncio.sleep(0.3)  # 给前端时间处理绘图

                    # 发送AI回答文本（使用清理后的文本）
                    await websocket.send_json({
                        "type": "ai_response",
                        "data": clean_text
                    })

                    # 发送音频数据（分块）
                    audio = result["assistant_audio"]
                    if audio and len(audio) > 0:
                        logger.info(f"开始发送音频: {len(audio)} 字节")
                        chunk_size = 3200  # 每次发送3200字节（约200ms）
                        for i in range(0, len(audio), chunk_size):
                            chunk = audio[i:i + chunk_size]
                            await websocket.send_bytes(chunk)
                        logger.info("音频发送完成")
                    else:
                        logger.info("无音频数据，跳过音频发送")

                    # 发送完成标志
                    await websocket.send_json({
                        "type": "audio_complete",
                        "data": None
                    })

                except Exception as e:
                    logger.error(f"处理语音失败: {e}")
                    await websocket.send_json({
                        "type": "error",
                        "data": str(e)
                    })

    except WebSocketDisconnect:
        logger.info(f"WebSocket连接断开: video_id={video_id}")
        # 结束学习会话并更新画像
        if manager.session_id:
            await manager.tracker.end_session(manager.session_id)
            # 异步更新学生画像
            try:
                await ProfileAnalyzer.update_profile(manager.student_id)
            except Exception as e:
                logger.error(f"更新学生画像失败: {e}")
    except Exception as e:
        logger.error(f"WebSocket错误: {e}")
        # 结束学习会话并更新画像
        if manager.session_id:
            await manager.tracker.end_session(manager.session_id)
            try:
                await ProfileAnalyzer.update_profile(manager.student_id)
            except Exception as ex:
                logger.error(f"更新学生画像失败: {ex}")
        try:
            await websocket.send_json({
                "type": "error",
                "data": str(e)
            })
        except:
            pass
