"""
视频相关的API路由
"""
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
import aiosqlite

from app.core.config import settings
from app.models.schemas import VideoUploadResponse, VideoDetailResponse, Node
from app.services.video_processor import VideoProcessor
from app.services.node_extractor import NodeExtractor

router = APIRouter()


@router.get("/videos")
async def get_videos_list():
    """
    获取所有视频列表

    - 返回视频基本信息列表
    - 按创建时间倒序排列
    """
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        cursor = await db.execute("""
            SELECT v.id, v.filename, v.duration, v.status, v.created_at,
                   COUNT(n.id) as nodes_count
            FROM videos v
            LEFT JOIN nodes n ON v.id = n.video_id
            WHERE v.status != 'failed'
            GROUP BY v.id
            ORDER BY v.created_at DESC
        """)
        rows = await cursor.fetchall()

        videos = [
            {
                "id": row["id"],
                "filename": row["filename"],
                "duration": row["duration"],
                "status": row["status"],
                "nodes_count": row["nodes_count"],
                "created_at": row["created_at"]
            }
            for row in rows
        ]

        return {"videos": videos}


@router.post("/upload", response_model=VideoUploadResponse)
async def upload_video(file: UploadFile = File(...)):
    """
    上传视频并处理（提取字幕）

    - 支持MP4等常见格式
    - 同步处理：调用Whisper提取字幕
    - 返回视频ID和处理状态
    """
    # 检查文件类型
    if not file.content_type.startswith("video/"):
        raise HTTPException(status_code=400, detail="只支持视频文件")

    # 检查文件大小（500MB限制）
    content = await file.read()
    if len(content) > 500 * 1024 * 1024:  # 500MB
        raise HTTPException(status_code=400, detail="视频文件不能超过500MB")

    try:
        # 处理视频
        processor = VideoProcessor()
        result = await processor.process_video(content, file.filename)

        return VideoUploadResponse(
            video_id=result["video_id"],
            status=result["status"],
            nodes_count=result["nodes_count"],
            duration=result["duration"]
        )

    except Exception as e:
        print(f"❌ 视频上传处理失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"视频处理失败: {str(e)}")


@router.get("/videos/{video_id}", response_model=VideoDetailResponse)
async def get_video_detail(video_id: str):
    """
    获取视频详情（包含节点信息）

    - 返回视频基本信息
    - 返回所有知识点节点
    """
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        # 查询视频信息
        cursor = await db.execute(
            "SELECT * FROM videos WHERE id = ?",
            (video_id,)
        )
        video_row = await cursor.fetchone()

        if not video_row:
            raise HTTPException(status_code=404, detail="视频不存在")

        # 查询节点信息
        cursor = await db.execute(
            "SELECT * FROM nodes WHERE video_id = ? ORDER BY order_num",
            (video_id,)
        )
        node_rows = await cursor.fetchall()

        nodes = [
            Node(
                id=row["id"],
                order_num=row["order_num"],
                start_time=row["start_time"],
                end_time=row["end_time"],
                title=row["title"] or "未命名节点",
                summary=row["summary"] or ""
            )
            for row in node_rows
        ]

        return VideoDetailResponse(
            id=video_row["id"],
            filename=video_row["filename"],
            duration=video_row["duration"],
            nodes=nodes
        )


@router.get("/videos/{video_id}/subtitles")
async def get_video_subtitles(video_id: str):
    """
    获取视频字幕（调试用）

    - 返回所有字幕段落
    """
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        cursor = await db.execute(
            "SELECT * FROM subtitles WHERE video_id = ? ORDER BY start_time",
            (video_id,)
        )
        rows = await cursor.fetchall()

        if not rows:
            raise HTTPException(status_code=404, detail="未找到字幕")

        subtitles = [
            {
                "text": row["text"],
                "start_time": row["start_time"],
                "end_time": row["end_time"]
            }
            for row in rows
        ]

        return {"video_id": video_id, "subtitles": subtitles}


@router.post("/videos/{video_id}/extract-nodes")
async def extract_video_nodes(video_id: str):
    """
    为已上传的视频提取知识点节点

    - 使用LLM分析字幕
    - 识别知识点边界
    - 保存节点到数据库
    """
    # 检查视频是否存在
    async with aiosqlite.connect(settings.DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM videos WHERE id = ?",
            (video_id,)
        )
        video_row = await cursor.fetchone()

        if not video_row:
            raise HTTPException(status_code=404, detail="视频不存在")

        if video_row["status"] == "failed":
            raise HTTPException(status_code=400, detail="视频处理失败，无法提取节点")

    try:
        # 提取节点
        extractor = NodeExtractor()
        nodes = await extractor.process_video_nodes(video_id)

        return {
            "video_id": video_id,
            "status": "ready",
            "nodes_count": len(nodes),
            "nodes": [
                {
                    "id": node.id,
                    "order": node.order_num,
                    "start_time": node.start_time,
                    "end_time": node.end_time,
                    "title": node.title,
                    "summary": node.summary
                }
                for node in nodes
            ]
        }

    except Exception as e:
        print(f"❌ 节点提取失败: {str(e)}")
        raise HTTPException(status_code=500, detail=f"节点提取失败: {str(e)}")
