from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class Subtitle(BaseModel):
    """字幕条目"""
    text: str
    start_time: float
    end_time: float


class Node(BaseModel):
    """视频知识点节点"""
    id: str
    order_num: int
    start_time: float
    end_time: float
    title: str
    summary: str


class Video(BaseModel):
    """视频信息"""
    id: str
    filename: str
    filepath: str
    duration: Optional[float] = None
    status: str  # 'processing' | 'ready' | 'ready_no_nodes' | 'failed'
    created_at: Optional[datetime] = None


class VideoUploadResponse(BaseModel):
    """视频上传响应"""
    video_id: str
    status: str
    nodes_count: int = 0
    duration: Optional[float] = None


class VideoDetailResponse(BaseModel):
    """视频详情响应"""
    id: str
    filename: str
    duration: Optional[float]
    nodes: List[Node] = []


class ChatMessage(BaseModel):
    """聊天消息"""
    type: str  # 'text' | 'latex'
    content: str
    role: Optional[str] = None  # 'user' | 'assistant'
