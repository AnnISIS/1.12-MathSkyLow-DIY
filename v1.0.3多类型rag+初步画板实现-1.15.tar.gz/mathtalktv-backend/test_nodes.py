"""
简单的API测试脚本
"""
import asyncio
from app.services.node_extractor import NodeExtractor
from app.models.schemas import Subtitle


async def test_node_extraction():
    """测试节点提取功能"""
    # 创建测试字幕
    test_subtitles = [
        Subtitle(text="大家好，今天我们来学习一元二次方程", start_time=0.0, end_time=5.0),
        Subtitle(text="首先，什么是一元二次方程呢？", start_time=5.0, end_time=10.0),
        Subtitle(text="一元二次方程的一般形式是 ax² + bx + c = 0", start_time=10.0, end_time=18.0),
        Subtitle(text="其中a、b、c是常数，且a不等于0", start_time=18.0, end_time=25.0),
        Subtitle(text="接下来我们看看如何解一元二次方程", start_time=25.0, end_time=30.0),
        Subtitle(text="第一种方法是配方法", start_time=30.0, end_time=35.0),
        Subtitle(text="我们通过配方可以把方程化为 (x-h)² = k 的形式", start_time=35.0, end_time=45.0),
    ]

    # 测试节点提取
    extractor = NodeExtractor()
    nodes = await extractor.extract_nodes(test_subtitles)

    print("\n=== 提取的节点 ===")
    for node in nodes:
        print(f"\n节点 {node.order_num}:")
        print(f"  时间: {node.start_time}s - {node.end_time}s")
        print(f"  标题: {node.title}")
        print(f"  摘要: {node.summary}")


if __name__ == "__main__":
    print("🧪 开始测试节点提取功能...")
    asyncio.run(test_node_extraction())
