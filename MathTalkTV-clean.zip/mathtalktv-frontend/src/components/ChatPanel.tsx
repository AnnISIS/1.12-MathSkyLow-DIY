import { useState, useRef, useEffect, RefObject } from 'react';
import katex from 'katex';
import 'katex/dist/katex.min.css';
import { ChatMessage } from '../types';
import './ChatPanel.css';

interface Props {
  videoId: string;
  videoRef: RefObject<HTMLVideoElement>;
}

const ChatPanel = ({ videoId, videoRef }: Props) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [status, setStatus] = useState<string>('idle');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const audioChunksRef = useRef<Float32Array[]>([]);
  const processingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const receivedAudioChunksRef = useRef<ArrayBuffer[]>([]);
  const currentAudioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  // 自动滚动到底部
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // 监听视频播放事件，播放时停止AI音频
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleVideoPlay = () => {
      console.log('📹 视频开始播放，停止AI音频');
      stopAIAudio();
    };

    video.addEventListener('play', handleVideoPlay);

    return () => {
      video.removeEventListener('play', handleVideoPlay);
    };
  }, [videoRef]);

  // 停止AI音频播放
  const stopAIAudio = () => {
    if (currentAudioSourceRef.current) {
      try {
        currentAudioSourceRef.current.stop();
        console.log('🔇 AI音频已停止');
      } catch (e) {
        // 音频可能已经停止
      }
      currentAudioSourceRef.current = null;
    }
  };

  // 连接WebSocket
  const connectWebSocket = () => {
    const ws = new WebSocket(`ws://localhost:8000/api/ws/chat/${videoId}`);

    ws.onopen = () => {
      console.log('✅ WebSocket连接成功');
      setStatus('connected');
    };

    ws.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        // JSON消息
        const msg = JSON.parse(event.data);
        console.log('收到消息:', msg);

        switch (msg.type) {
          case 'asr_result':
            // 清除超时
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示用户问题
            setMessages(prev => [...prev, {
              type: 'text',
              content: msg.data,
              role: 'user'
            }]);
            setStatus('thinking');
            // 清空之前的音频块
            receivedAudioChunksRef.current = [];
            break;

          case 'ai_response':
            // 清除超时
            if (processingTimeoutRef.current) {
              clearTimeout(processingTimeoutRef.current);
              processingTimeoutRef.current = null;
            }
            // 显示AI回答文本
            const text = msg.data;

            // 解析文本中的LaTeX公式（$$...$$）
            const parts = text.split(/(\$\$.*?\$\$)/g);

            parts.forEach((part: string) => {
              if (part.startsWith('$$') && part.endsWith('$$')) {
                // LaTeX公式
                const latex = part.slice(2, -2);
                setMessages(prev => [...prev, {
                  type: 'latex',
                  content: latex
                }]);
              } else if (part.trim()) {
                // 普通文本
                setMessages(prev => [...prev, {
                  type: 'text',
                  content: part,
                  role: 'assistant'
                }]);
              }
            });
            setStatus('playing');
            break;

          case 'audio_complete':
            // 所有音频块接收完毕，开始播放
            console.log(`✅ 接收到${receivedAudioChunksRef.current.length}个音频块`);
            if (receivedAudioChunksRef.current.length > 0) {
              await playAllAudioChunks();
            }
            setStatus('connected');
            setIsListening(false);
            break;

          case 'error':
            console.error('错误:', msg.data);
            setMessages(prev => [...prev, {
              type: 'text',
              content: `❌ 错误: ${msg.data}`,
              role: 'assistant'
            }]);
            setStatus('error');
            setIsListening(false);
            break;
        }
      } else {
        // 音频数据（二进制）
        const audioData = await event.data.arrayBuffer();
        console.log(`收到音频块: ${audioData.byteLength} 字节`);
        // 收集音频块，不立即播放
        receivedAudioChunksRef.current.push(audioData);
      }
    };

    ws.onerror = (error) => {
      console.error('❌ WebSocket错误:', error);
      setStatus('error');
    };

    ws.onclose = () => {
      console.log('WebSocket连接关闭');
      setStatus('idle');
    };

    wsRef.current = ws;
  };

  // 播放所有音频块
  const playAllAudioChunks = async () => {
    if (receivedAudioChunksRef.current.length === 0) {
      console.warn('⚠️ 没有音频数据');
      return;
    }

    // 计算总长度
    const totalBytes = receivedAudioChunksRef.current.reduce((acc, chunk) => acc + chunk.byteLength, 0);
    console.log(`🎵 准备播放: ${receivedAudioChunksRef.current.length}个块, 总计${totalBytes}字节`);

    // 合并所有音频块
    const combined = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of receivedAudioChunksRef.current) {
      combined.set(new Uint8Array(chunk), offset);
      offset += chunk.byteLength;
    }

    // 创建AudioContext
    if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
      audioContextRef.current = new AudioContext({ sampleRate: 16000 });
    }
    const audioContext = audioContextRef.current;

    // 将PCM数据转换为AudioBuffer
    const audioBuffer = audioContext.createBuffer(1, combined.length / 2, 16000);
    const channelData = audioBuffer.getChannelData(0);
    const view = new DataView(combined.buffer);

    for (let i = 0; i < channelData.length; i++) {
      // PCM 16位有符号整数转换为浮点数
      channelData[i] = view.getInt16(i * 2, true) / 32768.0;
    }

    // 停止之前的音频（如果有）
    stopAIAudio();

    // 播放
    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContext.destination);

    // 保存引用以便后续停止
    currentAudioSourceRef.current = source;

    // 播放结束时清除引用
    source.onended = () => {
      currentAudioSourceRef.current = null;
      console.log('✅ AI音频播放完成');
    };

    source.start();

    console.log('▶️ 开始播放音频');
  };

  // 开始录音
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      mediaStreamRef.current = stream;

      // 创建AudioContext
      const audioContext = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      // 清空音频块
      audioChunksRef.current = [];

      // 处理音频数据
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        // 复制数据
        const chunk = new Float32Array(inputData.length);
        chunk.set(inputData);
        audioChunksRef.current.push(chunk);
      };

      source.connect(processor);
      processor.connect(audioContext.destination);

      console.log('🎤 开始录音(PCM格式)...');
      setStatus('recording');
    } catch (error) {
      console.error('麦克风访问失败:', error);
      alert('无法访问麦克风，请检查浏览器权限设置');
      setIsListening(false);
    }
  };

  // 停止录音
  const stopRecording = () => {
    console.log('🛑 停止录音');

    // 停止处理器
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }

    // 关闭AudioContext
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    // 停止媒体流
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    // 发送音频数据到服务器
    console.log('WebSocket状态:', wsRef.current?.readyState);
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      // 合并所有Float32数据
      const totalLength = audioChunksRef.current.reduce((acc, arr) => acc + arr.length, 0);
      console.log(`音频块数量: ${audioChunksRef.current.length}, 总长度: ${totalLength}`);

      const combined = new Float32Array(totalLength);
      let offset = 0;
      for (const chunk of audioChunksRef.current) {
        combined.set(chunk, offset);
        offset += chunk.length;
      }

      // 转换为16位PCM
      const pcm16 = new Int16Array(combined.length);
      for (let i = 0; i < combined.length; i++) {
        const s = Math.max(-1, Math.min(1, combined[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }

      console.log(`发送PCM音频: ${pcm16.byteLength} 字节`);

      // 发送音频数据
      try {
        wsRef.current.send(pcm16.buffer);
        console.log('✅ 音频数据发送成功');
        setStatus('processing');

        // 设置30秒超时
        if (processingTimeoutRef.current) {
          clearTimeout(processingTimeoutRef.current);
        }
        processingTimeoutRef.current = setTimeout(() => {
          console.warn('⏱️ 处理超时');
          setStatus('connected');
          setMessages(prev => [...prev, {
            type: 'text',
            content: '⏱️ 处理超时，请重试',
            role: 'assistant'
          }]);
        }, 30000);
      } catch (error) {
        console.error('❌ 发送音频失败:', error);
        setStatus('error');
      }
    } else {
      console.error('❌ WebSocket未连接或已关闭');
      setStatus('error');
    }
  };

  // 处理提问按钮点击
  const handleAskClick = () => {
    if (!isListening) {
      // 开始提问 - 暂停视频
      if (videoRef.current && !videoRef.current.paused) {
        videoRef.current.pause();
        console.log('视频已暂停');
      }

      // 开始提问
      if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
        connectWebSocket();
        // 等待连接成功后再开始录音
        setTimeout(() => {
          startRecording();
          setIsListening(true);
        }, 500);
      } else {
        startRecording();
        setIsListening(true);
      }
    } else {
      // 停止提问
      stopRecording();
      setIsListening(false);
    }
  };

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (processorRef.current) {
        processorRef.current.disconnect();
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
      if (processingTimeoutRef.current) {
        clearTimeout(processingTimeoutRef.current);
      }
      // 停止AI音频
      stopAIAudio();
    };
  }, []);

  const renderLatex = (latex: string) => {
    try {
      const html = katex.renderToString(latex, {
        throwOnError: false,
        displayMode: true
      });
      return <div dangerouslySetInnerHTML={{ __html: html }} className="latex-block" />;
    } catch (e) {
      return <div className="latex-error">LaTeX渲染错误</div>;
    }
  };

  // 状态显示文本
  const getStatusText = () => {
    switch (status) {
      case 'recording':
        return '🎤 正在录音...';
      case 'processing':
        return '🔄 识别中...';
      case 'thinking':
        return '💭 AI思考中...';
      case 'playing':
        return '🔊 播放中...';
      case 'error':
        return '❌ 出错了';
      default:
        return '';
    }
  };

  return (
    <div className="chat-panel">
      <div className="chat-header">
        <h3>💬 问答区</h3>
        <span className="video-id">视频 ID: {videoId.slice(0, 8)}...</span>
      </div>

      {status !== 'idle' && status !== 'connected' && (
        <div className="status-indicator">{getStatusText()}</div>
      )}

      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="empty-state">
            <p>👋 点击下方"提问"按钮</p>
            <p>随时向AI老师提问！</p>
          </div>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`message ${msg.role || 'system'}`}>
              {msg.type === 'text' && (
                <div className="message-content">
                  <span className="message-role">
                    {msg.role === 'user' ? '👤 学生' : '🤖 AI老师'}
                  </span>
                  <p>{msg.content}</p>
                </div>
              )}
              {msg.type === 'latex' && renderLatex(msg.content || '')}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="chat-controls">
        <button
          className={`ask-button ${isListening ? 'listening' : ''}`}
          onClick={handleAskClick}
          disabled={status === 'processing' || status === 'thinking'}
        >
          {isListening ? '🛑 停止提问' : '🎤 提问'}
        </button>
      </div>
    </div>
  );
};

export default ChatPanel;
