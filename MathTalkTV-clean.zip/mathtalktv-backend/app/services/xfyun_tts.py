"""
讯飞语音合成（TTS）服务
使用讯飞在线语音合成API
"""
import asyncio
import websockets
import json
import base64
import hmac
import hashlib
from datetime import datetime
from time import mktime
from wsgiref.handlers import format_date_time
from urllib.parse import urlencode
from typing import AsyncIterator, Optional
import logging

from app.core.config import settings

logger = logging.getLogger(__name__)


class XFYunTTS:
    """讯飞语音合成"""

    # API配置
    HOST = "tts-api.xfyun.cn"
    URL = "wss://tts-api.xfyun.cn/v2/tts"

    # 状态码
    STATUS_FIRST_FRAME = 0
    STATUS_CONTINUE_FRAME = 1
    STATUS_LAST_FRAME = 2

    def __init__(self):
        self.app_id = settings.XFYUN_APP_ID
        self.api_key = settings.XFYUN_API_KEY
        self.api_secret = settings.XFYUN_API_SECRET

    def _generate_auth_url(self) -> str:
        """生成带鉴权参数的WebSocket URL"""
        # 生成RFC1123格式的时间戳
        now = datetime.now()
        date = format_date_time(mktime(now.timetuple()))

        # 拼接签名原文
        signature_origin = f"host: {self.HOST}\n"
        signature_origin += f"date: {date}\n"
        signature_origin += f"GET /v2/tts HTTP/1.1"

        # 使用hmac-sha256进行加密
        signature_sha = hmac.new(
            self.api_secret.encode('utf-8'),
            signature_origin.encode('utf-8'),
            digestmod=hashlib.sha256
        ).digest()

        # Base64编码
        signature_sha_base64 = base64.b64encode(signature_sha).decode('utf-8')

        # 拼接authorization
        authorization_origin = (
            f'api_key="{self.api_key}", '
            f'algorithm="hmac-sha256", '
            f'headers="host date request-line", '
            f'signature="{signature_sha_base64}"'
        )
        authorization = base64.b64encode(authorization_origin.encode('utf-8')).decode('utf-8')

        # 拼接URL参数
        params = {
            "authorization": authorization,
            "date": date,
            "host": self.HOST
        }

        return f"{self.URL}?{urlencode(params)}"

    async def synthesize_stream(
        self,
        text: str,
        voice_name: str = "xiaoyan",  # 发音人：晓燕（温柔女声）
        speed: int = 50,  # 语速：0-100，默认50
        volume: int = 50,  # 音量：0-100，默认50
        pitch: int = 50  # 音高：0-100，默认50
    ) -> AsyncIterator[bytes]:
        """
        流式语音合成

        Args:
            text: 要合成的文本
            voice_name: 发音人（xiaoyan-晓燕, aisjiuxu-许久等）
            speed: 语速
            volume: 音量
            pitch: 音高

        Yields:
            音频数据块（PCM格式，16k采样率，16bit，单声道）
        """
        url = self._generate_auth_url()
        logger.info(f"TTS开始合成: text_length={len(text)}, voice={voice_name}")

        try:
            async with websockets.connect(url, timeout=10) as ws:
                logger.info("TTS WebSocket连接成功")

                # 发送合成请求
                await self._send_synthesis_request(
                    ws, text, voice_name, speed, volume, pitch
                )
                logger.info("TTS请求已发送")

                # 接收音频数据
                chunk_count = 0
                async for audio_chunk in self._receive_audio_stream(ws):
                    chunk_count += 1
                    yield audio_chunk

                logger.info(f"TTS合成完成: 收到{chunk_count}个音频块")

        except Exception as e:
            logger.error(f"TTS合成失败: {e}", exc_info=True)
            raise Exception(f"语音合成失败: {str(e)}")

    async def synthesize(
        self,
        text: str,
        voice_name: str = "xiaoyan",
        speed: int = 50,
        volume: int = 50,
        pitch: int = 50
    ) -> bytes:
        """
        一次性语音合成（返回完整音频）

        Returns:
            完整的音频数据（PCM格式）
        """
        audio_data = b""
        async for chunk in self.synthesize_stream(text, voice_name, speed, volume, pitch):
            audio_data += chunk
        return audio_data

    async def _send_synthesis_request(
        self,
        ws,
        text: str,
        voice_name: str,
        speed: int,
        volume: int,
        pitch: int
    ):
        """发送合成请求"""
        frame = {
            "common": {
                "app_id": self.app_id
            },
            "business": {
                "aue": "raw",  # 音频编码：raw（PCM）
                "auf": "audio/L16;rate=16000",  # 音频格式
                "vcn": voice_name,  # 发音人
                "speed": speed,  # 语速
                "volume": volume,  # 音量
                "pitch": pitch,  # 音高
                "bgs": 0,  # 背景音乐：0-无
                "tte": "UTF8"  # 文本编码
            },
            "data": {
                "status": self.STATUS_LAST_FRAME,  # TTS只需要发送一帧
                "text": base64.b64encode(text.encode('utf-8')).decode('utf-8')
            }
        }

        await ws.send(json.dumps(frame))

    async def _receive_audio_stream(self, ws) -> AsyncIterator[bytes]:
        """接收音频流"""
        try:
            while True:
                message = await ws.recv()
                result = json.loads(message)

                code = result.get("code")
                if code != 0:
                    error_msg = f"TTS错误: code={code}, message={result.get('message')}"
                    logger.error(error_msg)
                    raise Exception(error_msg)

                # 获取音频数据
                data = result.get("data", {})
                audio_base64 = data.get("audio")

                if audio_base64:
                    # Base64解码音频数据
                    audio_chunk = base64.b64decode(audio_base64)
                    yield audio_chunk

                # status=2表示合成结束
                status = data.get("status")
                if status == 2:
                    break

        except websockets.exceptions.ConnectionClosed:
            logger.info("TTS WebSocket连接已关闭")
        except Exception as e:
            logger.error(f"接收TTS音频失败: {e}")
            raise


# 简单的测试函数
async def test_tts():
    """测试TTS功能"""
    tts = XFYunTTS()

    text = "你好，我是AI数学老师，有什么数学问题可以问我。"

    print(f"正在合成: {text}")

    # 测试流式合成
    total_bytes = 0
    async for chunk in tts.synthesize_stream(text):
        total_bytes += len(chunk)
        print(f"接收音频数据: {len(chunk)} 字节")

    print(f"✅ 合成完成，总计: {total_bytes} 字节")


if __name__ == "__main__":
    # 测试
    asyncio.run(test_tts())
