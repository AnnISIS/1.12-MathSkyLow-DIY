# MathTalkTV - 智能数学教学视频平台

一个基于AI的互动式数学教学视频平台，支持实时语音问答、知识点识别和个性化学习。

## 项目结构

```
.
├── MathTalkTV-PRD.md           # 产品需求文档
├── mathtalktv-backend/         # 后端服务 (FastAPI)
│   ├── app/                    # 应用代码
│   │   ├── api/               # API路由
│   │   ├── services/          # 业务服务
│   │   ├── models/            # 数据模型
│   │   └── core/              # 核心配置
│   ├── uploads/               # 视频上传目录
│   ├── data/                  # 数据库目录
│   ├── requirements.txt       # Python依赖
│   └── run.py                 # 启动脚本
│
└── mathtalktv-frontend/        # 前端应用 (React + TypeScript)
    ├── src/
    │   ├── components/        # React组件
    │   ├── pages/            # 页面
    │   └── types/            # TypeScript类型
    ├── package.json
    └── vite.config.ts
```

## 核心功能

### 1. 视频处理
- ✅ 视频上传与转码
- ✅ 自动提取字幕（基于Whisper API）
- ✅ AI识别知识点节点（基于GPT-4o-mini）
- ✅ 视频列表展示与管理

### 2. 语音问答
- ✅ 实时语音识别（讯飞ASR）
- ✅ AI教师回答（GPT-4o-mini）
- ✅ 语音合成播报（讯飞TTS）
- ✅ LaTeX公式渲染
- ✅ 上下文关联对话

### 3. 交互优化
- ✅ 提问时自动暂停视频
- ✅ 播放视频时自动停止AI语音
- ✅ 温柔亲切的AI声音
- ✅ 流畅的音视频切换

## 技术栈

### 后端
- **框架**: FastAPI + WebSocket
- **AI服务**:
  - OpenAI Whisper (字幕提取)
  - GPT-4o-mini (知识点识别、问答)
  - 讯飞语音识别 (ASR)
  - 讯飞语音合成 (TTS)
- **数据库**: SQLite + aiosqlite
- **工具**: FFmpeg (音视频处理)

### 前端
- **框架**: React 18 + TypeScript
- **构建**: Vite
- **样式**: CSS Modules
- **音频**: Web Audio API
- **公式**: KaTeX

## 快速开始

### 环境要求
- Python 3.9+
- Node.js 16+
- FFmpeg

### 后端启动

```bash
cd mathtalktv-backend

# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 配置环境变量
cp .env.example .env
# 编辑.env填入API密钥

# 启动服务
python run.py
```

后端将运行在 http://localhost:8000

### 前端启动

```bash
cd mathtalktv-frontend

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端将运行在 http://localhost:5173

## API文档

启动后端后访问：http://localhost:8000/docs

## 环境变量配置

后端需要配置以下环境变量（`.env`文件）：

```env
# 讯飞语音服务
XFYUN_APP_ID=your_app_id
XFYUN_API_KEY=your_api_key
XFYUN_API_SECRET=your_api_secret

# OpenAI API（用于Whisper和GPT）
OPENAI_API_KEY=your_openai_key

# LLM提供商（或第三方代理）
UIUIAPI_KEY=your_uiuiapi_key
UIUIAPI_BASE_URL=https://api.uiuiapi.com/v1
```

## 开发进度

- [x] 视频上传与处理
- [x] 字幕自动提取
- [x] 知识点AI识别
- [x] 实时语音问答
- [x] 音视频冲突处理
- [x] TTS声音优化
- [ ] RAG语义检索优化
- [ ] 知识图谱构建
- [ ] 学习进度追踪

## 贡献指南

欢迎提交Issue和Pull Request！

## 许可证

MIT License

## 联系方式

如有问题请提Issue或联系开发团队。

---

🤖 Generated with [Claude Code](https://claude.com/claude-code)
